//
//  HFXMLYCommon.swift
//  HFWYYProject
//
//  Created by Chen on 2021/3/3.
//  Copyright © 2021 CH. All rights reserved.
//

import Foundation
import UIKit
import SnapKit
import Moya
import SwiftyJSON
import SwiftMessages
import SVProgressHUD
 
import KingfisherWebP


let HFFMScreen_Width = UIScreen.main.bounds.size.width
let HFFMScreen_Height = UIScreen.main.bounds.size.height

// iphone X
let isPhoneX  = HFFMScreen_Height == 812 ? true : false
let HFFMNavBarHeight : CGFloat = isPhoneX ? 88 : 64
let HFFMtabbarHeight : CGFloat = isPhoneX ? 49 + 34 : 49

let HFFMThemeColor = UIColor.colorWithHexString("#FF8247")


let HFFMEBookItem_Width = (HFFMScreen_Width - 15 * 4) / 3


let newRecommendButton_Width = (HFFMScreen_Width - 60) / 4

extension UIView {
       func addCorner(conrners: UIRectCorner , radius: CGFloat) {
         let maskPath = UIBezierPath(roundedRect: self.bounds, byRoundingCorners: conrners, cornerRadii: CGSize(width: radius, height: radius))
         let maskLayer = CAShapeLayer()
         maskLayer.frame = self.bounds
         maskLayer.path = maskPath.cgPath
         self.layer.mask = maskLayer
     }
}


extension UIView{
    //Colors：渐变色色值数组
    func setLayerColors(_ colors:[CGColor])  {
            let layer = CAGradientLayer()
            layer.frame = bounds
            layer.colors = colors
            layer.startPoint = CGPoint(x: 0, y: 0)
            layer.endPoint = CGPoint(x: 1, y: 0)
            self.layer.addSublayer(layer)
        }
}
 


extension String {
    func roundingModel(roundingModel : NumberFormatter.RoundingMode ,
                          valueNumber : Double ,
                          formatterStyle : NumberFormatter.Style ,
                          minimumFractionDigits: Int ,
                          maximumFractionDigits : Int ,
                          positivePrefix : String ,
                          negativePrefix : String) -> String {
           
           let formatter = NumberFormatter.init()
           formatter.numberStyle = formatterStyle
           formatter.roundingMode = roundingModel
           formatter.minimumIntegerDigits = minimumFractionDigits
           formatter.minimumFractionDigits = maximumFractionDigits
           formatter.positivePrefix = positivePrefix
           formatter.negativePrefix = negativePrefix
           let string = formatter.string(from: NSNumber(value: valueNumber))
           return string!
       }
       
       
       func roundUpReleaseZeroWithValue(doubleValue : Double , scale : Int , decimalStyle : Bool) -> String {
        return self.roundingModel(roundingModel: NumberFormatter.RoundingMode.halfUp, valueNumber: doubleValue / 10000.0, formatterStyle: NumberFormatter.Style.none, minimumFractionDigits: 0, maximumFractionDigits: scale, positivePrefix: "", negativePrefix: "")
       }
}

extension UIView {
    public func customViewController()->UIViewController? {
          var nextResponder: UIResponder? = self
          repeat {
              nextResponder = nextResponder?.next
              if let viewController = nextResponder as? UIViewController {
                  return viewController
              }
          } while nextResponder != nil
          return nil
      }
}
