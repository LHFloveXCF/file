//
//  UIButton+Extension.swift
//  HFXMLYProject
//
//  Created by Chen on 2020/7/31.
//  Copyright © 2020 CH. All rights reserved.
//

import Foundation
import UIKit


enum HFButtonEdgeInsetsStyle {
    case HFButtonEdgeInsetsStyleTop //image在上，label在下
    case HFButtonEdgeInsetsStyleLeft // image在左，label在右
    case HFButtonEdgeInsetsStyleBottom // image在下，label在上
    case HFButtonEdgeInsetsStyleRight // image在右，label在左
}



//MARK: -定义button相对label的位置
enum HFButtonImagePosition {
    case top          //图片在上，文字在下，垂直居中对齐
    case bottom       //图片在下，文字在上，垂直居中对齐
    case left         //图片在左，文字在右，水平居中对齐
    case right        //图片在右，文字在左，水平居中对齐
}


extension UIButton {
    func hf_layoutButtonEdgInsets(_ position : HFButtonEdgeInsetsStyle ,  spaceNumber: CGFloat = 0) {
        var labelWidth: CGFloat = 0.0
        var labelHeight: CGFloat = 0.0
        var imageViewEdgInset  = UIEdgeInsets.zero
        var labelEdgInser  = UIEdgeInsets.zero
        let imageWith   = self.imageView?.frame.size.width
        let imageHeight  = self.imageView?.frame.size.height
        if #available(iOS 8.0, *) {
            labelWidth  = (self.titleLabel?.intrinsicContentSize.width)!
            labelHeight = ( self.titleLabel?.intrinsicContentSize.height)!
            
        }else{
            labelWidth  = (self.titleLabel?.frame.size.width)!
            labelHeight = (self.titleLabel?.frame.size.height)!
        }
        switch position {
        case .HFButtonEdgeInsetsStyleTop:
            imageViewEdgInset = UIEdgeInsets(top: -labelHeight - spaceNumber / 2.0, left: 0, bottom: 0, right: -labelWidth)
            labelEdgInser = UIEdgeInsets(top: 0, left: -imageWith!, bottom: -imageHeight! - spaceNumber / 2.0, right: 0)
            
        case .HFButtonEdgeInsetsStyleLeft:
            imageViewEdgInset = UIEdgeInsets(top: 0, left: -spaceNumber / 2.0, bottom: 0, right: spaceNumber / 2.0)
            labelEdgInser = UIEdgeInsets(top: 0, left: spaceNumber / 2.0, bottom: 0, right: -spaceNumber / 2.0)
        case .HFButtonEdgeInsetsStyleBottom:
            imageViewEdgInset = UIEdgeInsets(top: 0, left: 0, bottom: -labelHeight - spaceNumber / 2.0, right: -labelWidth)
            labelEdgInser = UIEdgeInsets(top: -imageHeight! - spaceNumber / 2.0, left: -imageWith!, bottom: 0, right: 0)
        case .HFButtonEdgeInsetsStyleRight:
            imageViewEdgInset = UIEdgeInsets(top: 0, left: labelWidth + spaceNumber / 2.0, bottom: 0, right: -labelWidth - spaceNumber / 2.0)
            labelEdgInser = UIEdgeInsets(top: 0, left: -imageWith! - spaceNumber / 2.0, bottom: 0, right: imageWith! + spaceNumber / 2.0)
        }
        titleEdgeInsets = labelEdgInser
        imageEdgeInsets = imageViewEdgInset
    }
    
    func imagePosition(style: HFButtonImagePosition , spacing : CGFloat)  {
        //得到imageView和titleLabel的宽高
        let imageWidth = self.imageView?.frame.size.width
        let imageHeight = self.imageView?.frame.size.height
        
        var labelWidth: CGFloat! = 0.0
        var labelHeight: CGFloat! = 0.0
        
        labelWidth = self.titleLabel?.intrinsicContentSize.width
        labelHeight = self.titleLabel?.intrinsicContentSize.height
        
        //初始化imageEdgeInsets和labelEdgeInsets
        var imageEdgeInsets = UIEdgeInsets.zero
        var labelEdgeInsets = UIEdgeInsets.zero
        
        //根据style和space得到imageEdgeInsets和labelEdgeInsets的值
        switch style {
        case .top:
            //上 左 下 右
            imageEdgeInsets = UIEdgeInsets(top: -labelHeight-spacing/2, left: 0, bottom: 0, right: -labelWidth)
            labelEdgeInsets = UIEdgeInsets(top: 0, left: -imageWidth!, bottom: -imageHeight!-spacing/2, right: 0)
            break;
            
        case .left:
            imageEdgeInsets = UIEdgeInsets(top: 0, left: -spacing/2, bottom: 0, right: spacing)
            labelEdgeInsets = UIEdgeInsets(top: 0, left: spacing/2, bottom: 0, right: -spacing/2)
            break;
            
        case .bottom:
            imageEdgeInsets = UIEdgeInsets(top: 0, left: 0, bottom: -labelHeight!-spacing/2, right: -labelWidth)
            labelEdgeInsets = UIEdgeInsets(top: -imageHeight!-spacing/2, left: -imageWidth!, bottom: 0, right: 0)
            break;
            
        case .right:
            imageEdgeInsets = UIEdgeInsets(top: 0, left: labelWidth+spacing/2, bottom: 0, right: -labelWidth-spacing/2)
            labelEdgeInsets = UIEdgeInsets(top: 0, left: -imageWidth!-spacing/2, bottom: 0, right: imageWidth!+spacing/2)
            break;
            
        }
        
        self.titleEdgeInsets = labelEdgeInsets
        self.imageEdgeInsets = imageEdgeInsets;
    }
}

