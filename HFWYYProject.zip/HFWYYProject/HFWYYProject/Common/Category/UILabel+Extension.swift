//
//  UILabel+Extension.swift
//  HFWYYProject
//
//  Created by Chen on 2021/3/4.
//  Copyright © 2021 CH. All rights reserved.
//

import Foundation
import UIKit

public extension UILabel {
    
    
    
   // MARK:获取第一行内容
//    var firstLabelString : String?{
////        return self.lineco
//    }
//
    
    
    //MARK: 改变行间距
    func changeLineSpace(space: CGFloat) {
        if self.text == nil || self.text == ""{
            return
        }
        
        let  text = self.text
        let  attributedString = NSMutableAttributedString(string: text!)
        let  paragrahStyle = NSMutableParagraphStyle() //行艰巨
        paragrahStyle.lineSpacing = space
        attributedString.addAttribute(NSAttributedString.Key.paragraphStyle, value: paragrahStyle, range: .init(location: 0, length: text!.count))
        self.attributedText = attributedString
        self.sizeToFit()
    }
    
    //MARK: 改变字之间的间距
    func changeWordSapce(space: CGFloat) {
        if self.text == nil || self.text == ""{
            return
        }
        let  text = self.text
        let  attributedString = NSMutableAttributedString(string: text!, attributes: [NSAttributedString.Key.kern: space])
        let  paragrahStyle = NSMutableParagraphStyle() //字间距
        paragrahStyle.lineSpacing = space
        attributedString.addAttribute(NSAttributedString.Key.paragraphStyle, value: paragrahStyle, range: .init(location: 0, length: text!.count))
        self.attributedText = attributedString
        self.sizeToFit()
    }
    
    //MARK:改变字和行之间的间距
    /// - Parameters:
    ///   - lineSpace: 行间距
    ///   - wordSpace: 字间距
    func changeLineAndWordSpace(lineSpace: CGFloat , wordSapce: CGFloat) {
         if self.text == nil || self.text == ""{
             return
        }
        let  text = self.text
        let  attributedString = NSMutableAttributedString(string: text!, attributes: [NSAttributedString.Key.kern: wordSapce])
        let  paragraphStyle = NSMutableParagraphStyle() //字间距
        paragraphStyle.lineSpacing = lineSpace
        attributedString.addAttribute(NSAttributedString.Key.paragraphStyle, value: paragraphStyle, range: .init(location: 0, length: text!.count))
        self.attributedText = attributedString;
        self.sizeToFit()
    }
    
    
    convenience  init(titleString : String , textColorString:String , fontNumber : CGFloat , textAlignments : NSTextAlignment, numberLines : NSInteger) {
        self.init()
        text  = titleString;
        font = UIFont.systemFont(ofSize: fontNumber)
        textAlignment = textAlignments;
        numberOfLines = numberLines;
        textColor = UIColor.colorWithHexString(textColorString)
    }
    
    
}
