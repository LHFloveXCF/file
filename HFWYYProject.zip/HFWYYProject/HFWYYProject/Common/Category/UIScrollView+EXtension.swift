//
//  UIScrollView+EXtension.swift
//  HFXMLYProject
//
//  Created by Chen on 2020/8/11.
//  Copyright © 2020 CH. All rights reserved.
//

import Foundation
import MJRefresh

extension UIScrollView {
    open func initRefreshView() {
        let header = MJRefreshNormalHeader()
        header.lastUpdatedTimeLabel?.isHidden = true
        header.stateLabel?.isHidden = true
        self.mj_header = header
        
        let footer = MJRefreshBackNormalFooter()
        footer.stateLabel!.isHidden = true
        self.mj_footer = footer
    }
}
