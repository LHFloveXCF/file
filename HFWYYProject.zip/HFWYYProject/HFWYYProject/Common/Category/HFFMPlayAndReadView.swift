//
//  HFFMPlayAndReadView.swift
//  HFWYYProject
//
//  Created by Chen on 2021/3/22.
//  Copyright © 2021 CH. All rights reserved.
//

import UIKit

class HFFMPlayAndReadView: UIView {
    
    var  delegate : HFFMPlayAndReadViewDelegate?
    
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        
        self.addSubview(addButton)
        self.addSubview(historyButton)

        
    }
    override func layoutSubviews() {
        super.layoutSubviews()
        self.addButton.snp.makeConstraints { (make ) in
            make.right.equalTo(-10)
            make.centerY.equalTo(self.snp_centerY)
            make.size.equalTo(CGSize(width: 30, height: 30))
        }
        self.historyButton.snp.makeConstraints { (make ) in
            make.right.equalTo(addButton.snp_left).offset(-20)
            make.centerY.equalTo(self.snp_centerY)
            make.size.equalTo(CGSize(width: 30, height: 30))
        }
    }
    lazy var historyButton : UIButton = {
        let button = UIButton.init(type: .custom)
        button.setImage(UIImage(named: "HistoryImage"), for: .normal)
        button.addTarget(self, action: #selector(historyButtonClickCallBack), for: .touchUpInside)
        return button
    }()
    
    lazy var addButton : UIButton = {
        let button = UIButton.init(type: .custom)
        button.setImage(UIImage(named: "addImageName"), for: .normal)
        button.addTarget(self, action: #selector(addButtonClickCallBack), for: .touchUpInside)
        return button
    }()
    
    @objc func addButtonClickCallBack(){
        if self.delegate != nil && ((self.delegate?.responds(to: Selector.init(("addButtonClick")))) != nil) {
            self.delegate?.addButtonClick()
        }
    }
    
    @objc func historyButtonClickCallBack(){
        if self.delegate != nil && ((self.delegate?.responds(to: Selector.init(("historyButtonClick")))) != nil) {
            self.delegate?.historyButtonClick()
        }
    }
    
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
}


protocol HFFMPlayAndReadViewDelegate  : NSObjectProtocol {
    func addButtonClick()
    func historyButtonClick()
}
