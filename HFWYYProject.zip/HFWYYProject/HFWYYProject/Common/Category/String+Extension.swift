//
//  String+Extension.swift
//  HFWYYProject
//
//  Created by Chen on 2021/3/22.
//  Copyright © 2021 CH. All rights reserved.
//

import Foundation
import UIKit

extension String {
    
    
    func heightWithConstrainedWidth(width: CGFloat, font: UIFont) -> CGFloat {
        let constraintRect = CGSize(width: width, height: CGFloat.greatestFiniteMagnitude)
        
        let boundingBox = self.boundingRect(with: constraintRect, options: NSStringDrawingOptions.usesLineFragmentOrigin, attributes: [NSAttributedString.Key.font: font], context: nil)
        
        return boundingBox.height
    }
    
    
    func stringValueDic(_ str: String) -> [String : Any]?{

        let data = str.data(using: String.Encoding.utf8)

        if let dict = try? JSONSerialization.jsonObject(with: data!, options: JSONSerialization.ReadingOptions.mutableContainers) as? [String : Any] {

        return dict

        }

        return nil

    }
    
}



//extension String {
//    
//    func roundingModel(roundingModel : NumberFormatter.RoundingMode ,
//                       valueNumber : Double ,
//                       formatterStyle : NumberFormatter.Style ,
//                       minimumFractionDigits: Int ,
//                       maximumFractionDigits : Int ,
//                       positivePrefix : String ,
//                       negativePrefix : String) -> String {
//        
//        let formatter = NumberFormatter.init()
//        formatter.numberStyle = formatterStyle
//        formatter.roundingMode = roundingModel
//        formatter.minimumIntegerDigits = minimumFractionDigits
//        formatter.minimumFractionDigits = maximumFractionDigits
//        formatter.positivePrefix = positivePrefix
//        formatter.negativePrefix = negativePrefix
//        let string = formatter.string(from: NSNumber(value: valueNumber))
//        return string!
//    }
//    
//    
//    func roundUpReleaseZeroWithValue(doubleValue : Double , scale : Int , decimalStyle : Bool) -> String {
//        return self.roundingModel(roundingModel: NumberFormatter.RoundingMode.halfUp, valueNumber: doubleValue, formatterStyle: NumberFormatter.Style.none, minimumFractionDigits: 0, maximumFractionDigits: scale, positivePrefix: "", negativePrefix: "")
//    }
//}
