//
//  HFFMSearchView.swift
//  HFWYYProject
//
//  Created by Chen on 2021/3/9.
//  Copyright © 2021 CH. All rights reserved.
//

import UIKit

class HFFMSearchView: UIView {

    override init(frame: CGRect) {
        super.init(frame: frame)
//        self.backgroundColor = .randomColor()
        
        self.addSubview(searchButton)
        searchButton.addSubview(searchImageView)
        searchImageView.addSubview(vioceImageView)
        
        
    }
    
    
    @objc func searchButtonClick(){
        
    }
    
   
    override func layoutSubviews() {
        super.layoutSubviews()
        
        searchButton.snp.makeConstraints { (make ) in
            make.left.equalTo(self).offset(15)
            make.top.equalTo(self).offset(5)
            make.size.equalTo(CGSize(width: HFFMScreen_Width  - 150, height: 30))
        }
        
        searchImageView.snp.makeConstraints { (make ) in
            make.left.equalTo(searchButton).offset(10)
            make.centerY.equalTo(searchButton.snp_centerY)
            make.size.equalTo(CGSize(width: 15, height: 15))
        }
        
//        vioceImageView.snp.makeConstraints { (make ) in
//            make.left.equalTo(searchButton).offset(3)
//            make.centerY.equalTo(searchButton.snp_centerY)
//            make.size.equalTo(CGSize(width: 13, height: 13))
//        }
    }
    
    lazy var searchButton: UIButton = {
        let button = UIButton.init(type: .custom)
        button.backgroundColor = UIColor.colorWithHexString("#EBEBEB")
        button.layer.cornerRadius = 15
        button.layer.masksToBounds = true
        button.addTarget(self, action: #selector(searchButtonClick), for: .touchUpInside)
        return button
    }()
    

    lazy var searchImageView: UIImageView = {
        let imageView = UIImageView()
        imageView.image = UIImage(named: "Search_image")
        imageView.contentMode = .scaleAspectFit
        return imageView
    }()
    
    lazy var vioceImageView: UIImageView = {
        let imageView = UIImageView()
        imageView.image = UIImage(named: "voice_image")
        imageView.contentMode = .scaleToFill
        return imageView
    }()
    
    lazy var searchRightImageView: UIImageView = {
        let imageView = UIImageView()
        imageView.image = UIImage(named: "Search_image")
        imageView.contentMode = .scaleAspectFit
        return imageView
    }()

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}
