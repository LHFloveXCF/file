//
//  HFFMTabBarViewController.swift
//  HFWYYProject
//
//  Created by Chen on 2021/3/17.
//  Copyright © 2021 CH. All rights reserved.
//

import UIKit
 

class HFFMTabBarViewController: UITabBarController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        self.addChildViewController(HFHomeViewController(), title: "首页", normalImageName: "channleMore_ImafeName", selectedImageName: "channleMore_ImafeName")
        self.addChildViewController(HFListenViewController(), title: "我听", normalImageName: "channleMore_ImafeName", selectedImageName: "channleMore_ImafeName")
        self.addChildViewController(HFFindViewController(), title: "发现", normalImageName: "channleMore_ImafeName", selectedImageName: "channleMore_ImafeName")
        self.addChildViewController(HFMineViewController(), title: "我的", normalImageName: "channleMore_ImafeName", selectedImageName: "channleMore_ImafeName")
        
    }
    
    func addChildViewController(_ viewController: UIViewController ,title: String, normalImageName: String , selectedImageName: String) {
        viewController.title = title
        viewController.tabBarItem.image = UIImage(named: normalImageName)?.withRenderingMode(.alwaysOriginal)
        viewController.tabBarItem.selectedImage = UIImage(named: selectedImageName)?.withRenderingMode(.alwaysOriginal)
        
        let nav =  HFFMNavigationViewController(rootViewController: viewController)
        nav.title = title
        self.addChild(nav)
    }

}
