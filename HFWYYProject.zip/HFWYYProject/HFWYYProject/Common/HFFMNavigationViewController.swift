//
//  HFFMNavigationViewController.swift
//  HFWYYProject
//
//  Created by Chen on 2021/3/3.
//  Copyright © 2021 CH. All rights reserved.
//

import UIKit

class HFFMNavigationViewController: UINavigationController {

    override func viewDidLoad() {
        super.viewDidLoad()

//        //隐藏导航栏
        self.isNavigationBarHidden = true

    }
    override func pushViewController(_ viewController: UIViewController, animated: Bool) {
        if viewControllers.count > 0 {
            viewController.hidesBottomBarWhenPushed = true
            
            let  backButton  = UIBarButtonItem.init(image: UIImage(named: "backImageName"), style: .plain, target: self, action: #selector(backButtonClick))
            self.navigationItem.leftBarButtonItem = backButton
        }
        super.pushViewController(viewController, animated: animated)
    }
    
    @objc func backButtonClick(){
        self.navigationController?.popViewController(animated: true)
    }
    
}
