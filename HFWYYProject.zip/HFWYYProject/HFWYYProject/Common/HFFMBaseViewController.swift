//
//  HFFMBaseViewController.swift
//  HFWYYProject
//
//  Created by Chen on 2021/3/3.
//  Copyright © 2021 CH. All rights reserved.
//

import UIKit

class HFFMBaseViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
 
        self.view.backgroundColor = .white
    }
    
    override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.view.endEditing(true)
    }
     

}
