//
//  HFPlayerHistoryTableViewCell.swift
//  HFWYYProject
//
//  Created by Chen on 2021/3/22.
//  Copyright © 2021 CH. All rights reserved.
//

import UIKit
import KingfisherWebP

class HFPlayerHistoryTableViewCell: UITableViewCell {
    
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        contentView.addSubview(coverImageView)
        contentView.addSubview(titleLabel)
        contentView.addSubview(subtitleLabel)
        contentView.addSubview(timeButton)
//        contentView.addSubview(similarityButton)

    }
    
    var model  : HFFMPlayHistoryDataModel? {
        didSet{
            guard  model != nil else {
                return
            }
            self.titleLabel.text = model?.itemTitle
            self.subtitleLabel.text = model?.childTitle
            self.coverImageView.kf.setImage(with: URL(string: model!.itemCoverUrl!), placeholder: nil, options: [.processor(WebPProcessor.default),.cacheSerializer(WebPSerializer.default)], progressBlock: nil) { (result) in
            }
        }
    }
    
    
    
    override func layoutSubviews() {
        super.layoutSubviews()
        coverImageView.snp.makeConstraints { (make ) in
            make.left.top.equalTo(contentView).offset(20)
            make.size.equalTo(CGSize(width: 70, height: 70))
        }
        titleLabel.snp.makeConstraints { (make ) in
            make.left.equalTo(coverImageView.snp_right).offset(15)
            make.top.equalTo(coverImageView)
            make.right.equalTo(contentView).offset(-20)
        }
        subtitleLabel.snp.makeConstraints { (make ) in
            make.left.equalTo(titleLabel)
            make.top.equalTo(titleLabel.snp_bottom).offset(15)
            make.right.equalTo(contentView).offset(-20)
        }
        timeButton.snp.makeConstraints { (make ) in
            make.left.equalTo(titleLabel)
            make.top.equalTo(subtitleLabel.snp_bottom).offset(20)
            make.size.equalTo(CGSize(width: 100, height: 15))
        }
        
//        similarityButton.snp.makeConstraints(<#T##closure: (ConstraintMaker) -> Void##(ConstraintMaker) -> Void#>)
    }
    lazy var coverImageView: UIImageView = {
        let imageView = UIImageView.init()
        imageView.layer.cornerRadius = 5
        imageView.layer.masksToBounds = true
        imageView.backgroundColor = HFFMThemeColor
        return imageView
    }()
    lazy var titleLabel : UILabel = {
        let label = UILabel.init(titleString: "私人FM", textColorString: "#1C1C1C", fontNumber: 17, textAlignments: .left, numberLines: 1)
        label.font = UIFont.boldSystemFont(ofSize: 17)
        return label
    }()
    lazy var subtitleLabel : UILabel = {
        let label = UILabel.init(titleString: "热门", textColorString: "#CFCFCF", fontNumber: 15, textAlignments: .left, numberLines:1)
        return label
    }()
    lazy var timeButton  : UIButton  =  {
        let button = UIButton.init(type: .custom)
        button.setTitle("27:05", for: .normal)
        button.setImage(UIImage(named: "timeImage"), for: .normal)
        button.setTitleColor(UIColor.colorWithHexString("#B5B5B5"), for: .normal)
        button.titleLabel?.font = UIFont.systemFont(ofSize: 13)
        button.contentHorizontalAlignment = .left
        button.imagePosition(style: .left, spacing: 8)
        return button
    }()
    lazy var similarityButton  : UIButton  =  {
        let button = UIButton.init(type: .custom)
        button.setTitle("找相似", for: .normal)
        button.titleLabel?.font = UIFont.systemFont(ofSize: 13)
        button.layer.borderColor = UIColor.colorWithHexString("#B5B5B5").cgColor
        button.layer.borderWidth = 0.5
        button.layer.cornerRadius = 10
        button.layer.masksToBounds = true
        return button
    }()
    
    lazy var youxuanImageView: UIImageView = {
        let imageView = UIImageView()
        imageView.contentMode = .scaleAspectFit
        return imageView
    }()
       
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}
