//
//  HFFMPlayHistoryModel.swift
//  HFWYYProject
//
//  Created by Chen on 2021/3/22.
//  Copyright © 2021 CH. All rights reserved.
//

import UIKit
import HandyJSON
 


struct HFFMPlayHistoryModel : HandyJSON {
    var ret : Int = 0
    var data:HFFMPlayHistoryDataListModel?
    
}
struct HFFMPlayHistoryDataListModel: HandyJSON {
    var syncPoint : Int = 0
    var listenModels: [HFFMPlayHistoryDataModel]?
}



struct HFFMPlayHistoryDataModel: HandyJSON {
    var albumSubscript: String?
    
    var breakSecond : Int = 0
    var childId : Int = 0
    var childTitle : String?
    var deviceType : Int = 0
    var direction : Int = 0
    var endedAt : Int = 0
    var itemCoverUrl : String?

    var itemId : Int = 0
    var itemTitle : String?
    var length : Int = 0
    var platform : Int = 0
    var startedAt : Int = 0
    var type : Int = 0
    var uid : Int = 0
    
    var isPaid : Bool = false
    var vipFreeType : Int = 0
    var isVipFree : Bool = false
    
}
