//
//  HFPlayHostoryViewModel.swift
//  HFWYYProject
//
//  Created by Chen on 2021/3/22.
//  Copyright © 2021 CH. All rights reserved.
//

import UIKit
import Moya
import SwiftyJSON
import HandyJSON

class HFPlayHostoryViewModel: NSObject {

    var playHistoryModel : HFFMPlayHistoryModel?
    
    
    typealias getDatablock = ()->Void
}


extension  HFPlayHostoryViewModel {
    func getPlayHistoryList(updataBlock : @escaping getDatablock)  {
        //获得json的路径
        let path = Bundle.main.path(forResource: "HFPlayHistory", ofType: "json")
        //获得json文件里面的内容,NSData格式
        let jsonData = NSData(contentsOfFile: path!)
        //解析书库
        let json = JSON(jsonData!)
        
        if let mappObject = JSONDeserializer<HFFMPlayHistoryModel>.deserializeFrom(json: json.description) {
            self.playHistoryModel = mappObject
             updataBlock()
        }
        
    }
    
    
}
