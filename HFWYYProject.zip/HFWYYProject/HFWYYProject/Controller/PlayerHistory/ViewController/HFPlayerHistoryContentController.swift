//
//  HFPlayerHistoryContentController.swift
//  HFWYYProject
//
//  Created by Chen on 2021/3/22.
//  Copyright © 2021 CH. All rights reserved.
//

import UIKit
import DNSPageView


class HFPlayerHistoryContentController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.navigationController?.setNavigationBarHidden(false, animated: false)
        self.view.backgroundColor = .white
        
        // 单独设置 titleView 的 frame
        navigationItem.titleView = pageViewManager.titleView
//        pageViewManager.titleView.backgroundColor = .red
        pageViewManager.titleView.frame = CGRect(x: 0, y:0, width: HFFMScreen_Width - 100, height: 50)
        // 单独设置 contentView 的大小和位置，可以使用 autolayout 或者 frame
        let contentView = pageViewManager.contentView
        view.addSubview(pageViewManager.contentView)
        
        contentView.snp.makeConstraints { (maker) in
            maker.edges.equalToSuperview()
        }
        
        if #available(iOS 11, *) {
            contentView.collectionView.contentInsetAdjustmentBehavior = .never
        } else {
            automaticallyAdjustsScrollViewInsets = false
        }

    }
    
    lazy var pageViewManager: PageViewManager = {
        let style = PageStyle()
        style.isShowBottomLine = true
        style.bottomLineColor = HFFMThemeColor
        style.bottomLineWidth = 30
        style.bottomLineHeight = 4
        style.titleSelectedColor = HFFMThemeColor
        style.isTitleScaleEnabled = true
        style.titleFont = UIFont.systemFont(ofSize: 15)
        style.titleMaximumScaleFactor = 1.0
        style.titleSelectedFont = UIFont.boldSystemFont(ofSize: 17)
        style.titleViewBackgroundColor = .clear
        
        let titles =  ["播放历史","阅读历史" ]
        let VCArray = [HFFMPlayerHostoryListViewController(), HFFMReadListViewController()]
        
        for (index , vc) in  VCArray.enumerated(){
            vc.view.backgroundColor = .white
            addChild(vc)
        }
        
        return   PageViewManager(style: style, titles: titles, childViewControllers: children)
    }()
 
}
