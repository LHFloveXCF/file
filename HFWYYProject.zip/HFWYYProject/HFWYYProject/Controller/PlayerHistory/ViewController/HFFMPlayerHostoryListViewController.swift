//
//  HFFMPlayerHostoryListViewController.swift
//  HFWYYProject
//
//  Created by Chen on 2021/3/22.
//  Copyright © 2021 CH. All rights reserved.
//

import UIKit

class HFFMPlayerHostoryListViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        
        weak var weakSelf = self
        viewModel.getPlayHistoryList {
            weakSelf?.playHistoryTableView.reloadData()
        }
        self.view.addSubview(playHistoryTableView)
    }

    lazy var playHistoryTableView: UITableView = {
        let tableView = UITableView.init(frame: self.view.bounds, style: .plain)
        tableView.register(HFPlayerHistoryTableViewCell.self, forCellReuseIdentifier: "PlayerHistoryCell")
        tableView.delegate = self
        tableView.dataSource = self
        return tableView
    }()
    lazy var viewModel : HFPlayHostoryViewModel = {
        return HFPlayHostoryViewModel()
    }()
}

extension HFFMPlayerHostoryListViewController: UITableViewDelegate{
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 120
    }
}
extension HFFMPlayerHostoryListViewController: UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return (self.viewModel.playHistoryModel?.data?.listenModels!.count)!
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "PlayerHistoryCell", for: indexPath) as!HFPlayerHistoryTableViewCell
        cell.model = self.viewModel.playHistoryModel?.data?.listenModels![indexPath.row]
        return cell
    }
    
    
}


