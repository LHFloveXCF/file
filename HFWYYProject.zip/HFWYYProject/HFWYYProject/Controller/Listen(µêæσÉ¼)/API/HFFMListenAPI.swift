//
//  HFFMListenAPI.swift
//  HFWYYProject
//
//  Created by Chen on 2021/3/5.
//  Copyright © 2021 CH. All rights reserved.
//

import Foundation
import UIKit
import Moya
import HandyJSON
import SwiftyJSON


let HFFMListenModelProvider = MoyaProvider<HFFMListenModelAPI>()


enum HFFMListenModelAPI {
    case listenFirstPage
    case listenSubscribeRecommend
}



extension  HFFMListenModelAPI : TargetType{
    var baseURL: URL {
        return URL(string: "https://mobile.ximalaya.com")!
    }
    
    var path: String {
        switch self {
        case .listenSubscribeRecommend:
            return "/subscribe/v2/subscribe/recommend/unlogin"
            
        case .listenFirstPage:
            return "/discovery-firstpage/squares/query/ts-1614931118371"
        }
    }
    
    var method:Moya.Method {
        return .get
    }
    
    var sampleData: Data {
          return "".data(using: String.Encoding.utf8)!
    }
    
    var task: Task {
        var parmeters = ["pageId":1] as [String : Any]
        switch self {
        case .listenSubscribeRecommend:
            parmeters = ["pageId":1,
                         "pageSize":30]
            
        case .listenFirstPage :
            parmeters = ["squareType" : 12]
        }
        return .requestParameters(parameters: parmeters, encoding: URLEncoding.default)
    }
    
    var headers: [String : String]? {
        return nil
    }
    
    
}
