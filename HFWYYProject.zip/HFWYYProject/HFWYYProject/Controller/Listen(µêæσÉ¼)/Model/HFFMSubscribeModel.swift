//
//  HFFMSubscribeModel.swift
//  HFWYYProject
//
//  Created by Chen on 2021/3/5.
//  Copyright © 2021 CH. All rights reserved.
//

import UIKit
import HandyJSON
 
struct HFFMSubscribeModel : HandyJSON {
     
    var hasMore: Bool = true
    var totalSize: Int = 0
    var albums: [HFFMSubscribeDataModel]?    
}

struct HFFMSubscribeDataModel : HandyJSON {
    var albumId : Int = 0
    var coverMiddle :String?
    var coverSmall :String?
    var isDraft :Bool = false
    var isFinished :Int = 0
    var isPaid :Bool = false
    
    var lastUpdateAt :Int = 0
    var nickna :String?
    var playsCounts :Int = 0
    var preferredType :Int = 0
    var recReason :String?
    
    var recSrc :String?
    var recTrack :String?
    var refundSupportType :Int = 0
    var title: String?
    var tracks: Int = 0
}


//MARK: 我听页面的四个按钮
struct HFFMListenFourModel: HandyJSON {
    var msg: String?
    var ret : Int = 0
    var data : [HFFMListenFourDataModel]?
}
struct HFFMListenFourDataModel: HandyJSON {
    var bubbleText: String?
    var bucketId: Int = 0
    var contentType: String?
    var contentUpdatedAt: Int = 0
    var coverPath: String?
    var darkCoverPath: String?
    var displayClass: String?
    var enableShare: Bool = false
    var id:Int = 0
    var isExternalUrl:Bool = false
    var orderNum: Int = 0

    var subtitle: String?
    var title: String?
    var url: String?
    var versionId : Int = 0
    var properties : HFFMListenFourDataPropertiesModel?
    
    
}
struct HFFMListenFourDataPropertiesModel : HandyJSON {
     var isPaid:Bool = false
    var subTitle : String?
    var myListenType : Int = 0
    var type: String?
    var uri : String?
}
