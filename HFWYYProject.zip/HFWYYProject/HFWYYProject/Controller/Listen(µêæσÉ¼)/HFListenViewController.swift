//
//  HFListenViewController.swift
//  HFWYYProject
//
//  Created by Chen on 2021/3/3.
//  Copyright © 2021 CH. All rights reserved.
//

import UIKit
import DNSPageView


class HFListenViewController: UIViewController {

    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
         
        self.navigationController?.setNavigationBarHidden(false, animated: false)
        
        self.title = "我听"
        
        
        self.view.addSubview(headerView)
        
        viewModel.getListenFourModelBlock = { [unowned self] in
            self.headerView.dataArray = self.viewModel.listenFourModel!.data
        }
        viewModel.listenFirstPage()

        
        //先设置style
        let  style  = PageStyle()
        style.bottomLineColor = HFFMThemeColor
        style.isShowBottomLine = true
        style.bottomLineHeight = 2
        style.titleSelectedColor = .black
        style.titleColor = .lightGray
        style.isTitleViewScrollEnabled = true
        style.isTitleScaleEnabled = true
        style.titleViewBackgroundColor = UIColor.colorWithHexString("#E5E5E5")

        
        let  titles  = ["订阅" , "听更新" , "电子书"]
        let viewControllers = [HFFMSubscribeViewController() , HFFMUpdateViewController() , HFFMEBookViewController()]
        for vc  in viewControllers {
            self.addChild(vc)
        }
        
        let pageView = PageView.init(frame: CGRect(x: 0, y: 200, width: HFFMScreen_Width, height: HFFMScreen_Height - 200), style: style, titles: titles, childViewControllers: viewControllers)
        view.addSubview(pageView)
    }
    
    lazy var headerView: ListenHeaderView = {
        let view = ListenHeaderView.init(frame: CGRect(x: 0, y: HFFMNavBarHeight, width: HFFMScreen_Width, height: 200))
        return view
    }()
    
    lazy var viewModel : HFFMSubscribeViewModel = {
        return HFFMSubscribeViewModel()
    }()
 
}
