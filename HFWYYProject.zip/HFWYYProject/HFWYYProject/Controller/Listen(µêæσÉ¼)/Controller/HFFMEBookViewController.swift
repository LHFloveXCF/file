//
//  HFFMEBookViewController.swift
//  HFWYYProject
//
//  Created by Chen on 2021/3/5.
//  Copyright © 2021 CH. All rights reserved.
//

import UIKit

class HFFMEBookViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        self.view.addSubview(mainCollectionView)
        mainCollectionView.backgroundColor = .white
    }
    
    lazy var mainCollectionView: UICollectionView = {
        let flowLayout = UICollectionViewFlowLayout()
        flowLayout.itemSize = CGSize(width:HFFMEBookItem_Width, height: 150)
        flowLayout.sectionInset = UIEdgeInsets(top: 15, left: 15, bottom: 15, right: 15)
        flowLayout.minimumLineSpacing = 40
        let collectionView = UICollectionView.init(frame: CGRect(x: 0, y: 0, width: HFFMScreen_Width, height: HFFMScreen_Height), collectionViewLayout: flowLayout)
        collectionView.delegate = self
        collectionView.dataSource = self
        collectionView.register(HFFMEBookCollectionViewCell.self, forCellWithReuseIdentifier: "normalCell")
        collectionView.register(HFFMEBookAddCollectionViewCell.self, forCellWithReuseIdentifier: "addCell")
        return collectionView
    }()
    
}


extension HFFMEBookViewController :  UICollectionViewDelegate {
    
}

extension HFFMEBookViewController : UICollectionViewDataSource{
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return 5
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        if indexPath.row == 4 {
            
            let  cell  = collectionView.dequeueReusableCell(withReuseIdentifier: "addCell", for: indexPath) as! HFFMEBookAddCollectionViewCell
            return cell
            
        }else{
            let  cell  = collectionView.dequeueReusableCell(withReuseIdentifier: "normalCell", for: indexPath) as! HFFMEBookCollectionViewCell
            return cell
        }
    }
}
