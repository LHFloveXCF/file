//
//  HFFMSubscribeViewController.swift
//  HFWYYProject
//
//  Created by Chen on 2021/3/5.
//  Copyright © 2021 CH. All rights reserved.
//

import UIKit

class HFFMSubscribeViewController: UIViewController  {

    override func viewDidLoad() {
        super.viewDidLoad()

        self.loadData()
        
        self.view.addSubview(mainTableView)
        
    }
    
    func loadData() {
        viewModel.updateBlock = { [unowned self] in
            //更新数据列表
            self.mainTableView.reloadData()
        }
        viewModel.listenSubscribeRecommend()
        
    }
    lazy var mainTableView: UITableView = {
        let tableView = UITableView.init(frame: CGRect(x: 0, y: 0, width: HFFMScreen_Width, height: HFFMScreen_Height - 200 - 64), style: .plain)
        tableView.delegate = self
        tableView.dataSource = self
        tableView.tableHeaderView = headerView
        tableView.separatorStyle = .none
        tableView.register(HFFMSubscribeTableViewCell.self, forCellReuseIdentifier: "SubscribeTableViewCell")
        return tableView
    }()
    
    lazy var headerView: HFFMSubscribeHeaderView = {
        let view = HFFMSubscribeHeaderView.init(frame: CGRect(x: 0, y: 0, width: HFFMScreen_Width, height: 130))
        return view
    }()

    lazy var viewModel: HFFMSubscribeViewModel = {
        return HFFMSubscribeViewModel()
    }()
}

extension HFFMSubscribeViewController : UITableViewDelegate{
    
}

extension HFFMSubscribeViewController: UITableViewDataSource{
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return viewModel.numberOfRowsInSection(section: section)
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let  cell  = tableView.dequeueReusableCell(withIdentifier: "SubscribeTableViewCell", for: indexPath) as! HFFMSubscribeTableViewCell
        cell.albumResults = viewModel.subscribeMoel?.albums![indexPath.row]
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return  100
    }
}
