//
//  HFFMSubscribeViewModel.swift
//  HFWYYProject
//
//  Created by Chen on 2021/3/5.
//  Copyright © 2021 CH. All rights reserved.
//

import UIKit
import Moya
import SwiftyJSON
import HandyJSON

class HFFMSubscribeViewModel: NSObject {

    //我听首页的顶部四个按钮model
    var listenFourModel : HFFMListenFourModel?
    
    var subscribeMoel : HFFMSubscribeModel?
    
    typealias SubscribeBlock = () -> Void
    typealias fourBlock = () -> Void
    //数据源更新
    var updateBlock: SubscribeBlock?
    
    var getListenFourModelBlock : fourBlock?
    
    
}

extension HFFMSubscribeViewModel {
    func listenFirstPage() {
         //获得json的文件路径
        let  path  = Bundle.main.path(forResource: "HFFMListenTopFour", ofType: "json")
        //获得json文件里面的内容,NSData格式
        let jsonData = NSData(contentsOfFile: path!)
        //解析书库
        let json = JSON(jsonData!)
        if  let mappedObject = JSONDeserializer<HFFMListenFourModel>.deserializeFrom(json: json.description) {
            self.listenFourModel = mappedObject
            self.getListenFourModelBlock?()
        }
    }
    
    func listenSubscribeRecommend() {
        HFFMListenModelProvider.request(.listenSubscribeRecommend){ (result) in
            if case let .success(response) = result {
                let data = try? response.mapJSON()
                let json = JSON(data!)
                print("订阅 == \(json)")
                
                if  let mappedObject = JSONDeserializer<HFFMSubscribeModel>.deserializeFrom(json: json["data"].description) {
                    self.subscribeMoel = mappedObject
                    self.updateBlock?()
                }
            }
        }
    }
    
}


extension HFFMSubscribeViewModel {
       // 每个分区显示item数量
    func numberOfRowsInSection(section: NSInteger) -> NSInteger {
        return self.subscribeMoel?.albums?.count ?? 0
    }

}
