//
//  HFFMEBookCollectionViewCell.swift
//  HFWYYProject
//
//  Created by Chen on 2021/3/5.
//  Copyright © 2021 CH. All rights reserved.
//

import UIKit

class HFFMEBookCollectionViewCell: UICollectionViewCell {
    
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        self.addSubview(pictureView)
        self.addSubview(nameLabel)
    }
    
    override func layoutSubviews() {
        super.layoutSubviews()
        pictureView.snp.makeConstraints { (make) in
            make.top.equalTo(15)
            make.leading.equalTo(0)
            make.size.equalTo(CGSize(width: HFFMEBookItem_Width, height: 150))
        }
        
        nameLabel.snp.makeConstraints { (make ) in
            make.left.equalTo(pictureView.snp_left)
            make.top.equalTo(pictureView.snp_bottom).offset(10)
            make.height.equalTo(16)
        }
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    lazy var pictureView: UIImageView = {
        let imageView = UIImageView()
        imageView.backgroundColor = .red
        imageView.layer.cornerRadius = 5
        imageView.layer.masksToBounds = true
        return imageView
    }()
    
    lazy var nameLabel : UILabel = {
        let label = UILabel.init(titleString: "捡来", textColorString: "#EEEEEE", fontNumber: 15, textAlignments: .left, numberLines: 1)
        return label
    }()
}
