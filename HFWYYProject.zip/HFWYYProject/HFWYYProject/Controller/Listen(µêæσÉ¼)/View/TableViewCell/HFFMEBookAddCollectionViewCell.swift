//
//  HFFMEBookAddCollectionViewCell.swift
//  HFWYYProject
//
//  Created by Chen on 2021/3/5.
//  Copyright © 2021 CH. All rights reserved.
//

import UIKit

class HFFMEBookAddCollectionViewCell: UICollectionViewCell {
    
    override init(frame: CGRect) {
        super.init(frame: frame )
        contentView.addSubview(pictureView)
        
    
    }
    
    override func layoutSubviews() {
        super.layoutSubviews()
        pictureView.snp.makeConstraints { (make) in
            make.top.equalTo(15)
            make.leading.equalTo(0)
            make.size.equalTo(CGSize(width: HFFMEBookItem_Width, height: 150))
        }
        
    }
    
   lazy var pictureView: UIImageView = {
        let imageView = UIImageView()
        imageView.backgroundColor = .green
        imageView.layer.cornerRadius = 5
        imageView.layer.masksToBounds = true
        return imageView
    }()
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    
}
