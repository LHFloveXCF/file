//
//  HFFMSubscribeTableViewCell.swift
//  HFWYYProject
//
//  Created by Chen on 2021/3/5.
//  Copyright © 2021 CH. All rights reserved.
//

import UIKit
import KingfisherWebP

class HFFMSubscribeTableViewCell: UITableViewCell {

    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        
        self.selectionStyle = .none
        
        contentView.addSubview(pictureView)
        contentView.addSubview(titleLabel)
        contentView.addSubview(descriptionLabel)
        contentView.addSubview(subscribeButton)
        contentView.addSubview(listenNumberButton)
        contentView.addSubview(collectNumberButton)
        
    }
    
    
    override func layoutSubviews() {
        super.layoutSubviews()
        pictureView.snp.makeConstraints { (make ) in
            make.left.top.equalTo(self).offset(20)
            make.size.equalTo(CGSize(width: 70, height: 70))
        }
        
        titleLabel.snp.makeConstraints { (make ) in
            make.left.equalTo(pictureView.snp_right).offset(10)
            make.top.equalTo(pictureView.snp_top).offset(3)
            make.right.equalTo(self.snp_right).offset(-30)
            make.height.equalTo(20)
        }
        descriptionLabel.snp.makeConstraints { (make ) in
            make.left.equalTo(pictureView.snp_right).offset(10)
            make.top.equalTo(titleLabel.snp_bottom).offset(5)
            make.right.equalTo(self.snp_right).offset(-100)
            make.height.equalTo(15)
        }
        
        subscribeButton.snp.makeConstraints { (make ) in
            make.right.equalTo(self).offset(-20)
            make.bottom.equalTo(pictureView.snp_bottom)
            make.size.equalTo(CGSize(width: 60, height: 30))
        }
        
        listenNumberButton.snp.makeConstraints { (make ) in
            make.left.equalTo(pictureView.snp_right).offset(10)
            make.top.equalTo(descriptionLabel.snp_bottom).offset(15)
            make.height.equalTo(15)
        }
        collectNumberButton.snp.makeConstraints { (make ) in
            make.left.equalTo(listenNumberButton.snp_right).offset(20)
            make.top.equalTo(descriptionLabel.snp_bottom).offset(15)
            make.height.equalTo(15)
        }
    }
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    

    lazy var pictureView: UIImageView = {
        let imageView = UIImageView()
        imageView.layer.cornerRadius = 3
        imageView.layer.masksToBounds = true
        imageView.backgroundColor = .red
        return imageView
    }()
    
    lazy var titleLabel : UILabel = {
        let label = UILabel.init(titleString: "西游记", textColorString: "#404040", fontNumber: 16, textAlignments: .left, numberLines: 1)
        return label
    }()
    
    lazy var descriptionLabel : UILabel = {
        let label = UILabel.init(titleString: "根据你的兴趣爱好推荐", textColorString: "#B0B0B0", fontNumber: 13, textAlignments: .left, numberLines: 1)
        return label
    }()
    
    
    lazy var subscribeButton: UIButton = {
        let button = UIButton.init(type: .custom)
        button.setTitle("+ 订阅", for: .normal)
        button.setTitleColor(.white, for: .normal)
        button.titleLabel?.font = UIFont.systemFont(ofSize: 12)
        button.layer.cornerRadius = 15
        button.layer.masksToBounds = true
        button.backgroundColor = HFFMThemeColor
        return button
    }()
    
    lazy var listenNumberButton: UIButton = {
        let button = UIButton.init(type: .custom)
        button.setTitle("26678万", for: .normal)
        button.setTitleColor(UIColor.colorWithHexString("#DBDBDB"), for: .normal)
        button.setImage(UIImage(named: "mine_messgae"), for: .normal)
        button.hf_layoutButtonEdgInsets(.HFButtonEdgeInsetsStyleLeft, spaceNumber: 5)
        button.titleLabel?.font = UIFont.systemFont(ofSize: 13)
        return button
    }()
    
    
    lazy var collectNumberButton: UIButton = {
        let button = UIButton.init(type: .custom)
        button.setTitle("202", for: .normal)
        button.setTitleColor(UIColor.colorWithHexString("#DBDBDB"), for: .normal)
        button.setImage(UIImage(named: "mine_messgae"), for: .normal)
        button.hf_layoutButtonEdgInsets(.HFButtonEdgeInsetsStyleLeft, spaceNumber: 5)
        button.titleLabel?.font = UIFont.systemFont(ofSize: 13)
        return button
    }()
      
    
    
    var albumResults : HFFMSubscribeDataModel? {
        didSet{
            guard let model = albumResults  else {  return  }
//            self.pictureView.kf.setImage(with: URL(string: model.coverMiddle!))
            self.pictureView.kf.setImage(with: URL(string: (model.coverMiddle)!), placeholder: nil, options:  [.processor(WebPProcessor.default),.cacheSerializer(WebPSerializer.default)], progressBlock: nil) { (result) in
            }
            self.titleLabel.text = model.title
            self.descriptionLabel.text = model.recReason
            self.listenNumberButton.setTitle(String(model.playsCounts), for: .normal)
            self.collectNumberButton.setTitle(String(model.tracks), for: .normal)
        }
    }
    
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
