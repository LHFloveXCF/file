//
//  HFFMSubscribeHeaderView.swift
//  HFWYYProject
//
//  Created by Chen on 2021/3/5.
//  Copyright © 2021 CH. All rights reserved.
//

import UIKit

class HFFMSubscribeHeaderView: UIView {

    
    override init(frame: CGRect) {
        super.init(frame: frame)
        
        self.addSubview(loginBgButton)
        loginBgButton.addSubview(titleLabel)
        loginBgButton.addSubview(subLabel)
        loginBgButton.addSubview(clickLoginLabel)
        self.addSubview(reminderLabel)
    }
    
    //页面的布局
    override func layoutSubviews() {
        super.layoutSubviews()
        
        loginBgButton.snp.makeConstraints { (make ) in
            make.left.top.equalTo(self).offset(20)
            make.size.equalTo(CGSize(width: HFFMScreen_Width - 20 * 2, height: 70))
        }
        
        titleLabel.snp.makeConstraints { (make ) in
            make.left.top.equalTo(loginBgButton).offset(20)
            make.height.equalTo(15)
        }
        
        subLabel.snp.makeConstraints { (make ) in
            make.left.equalTo(loginBgButton).offset(20)
            make.top.equalTo(titleLabel.snp_bottom).offset(8)
            make.height.equalTo(15)
        }
        
        clickLoginLabel.snp.makeConstraints { (make ) in
            make.centerY.equalTo(loginBgButton.snp_centerY)
            make.right.equalTo(loginBgButton.snp_right).offset(-20)
            make.size.equalTo(CGSize(width: 80, height: 30))
        }
        
        reminderLabel.snp.makeConstraints { (make ) in
            make.centerX.equalTo(self.snp_centerX)
            make.top.equalTo(loginBgButton.snp_bottom).offset(10)
            make.height.equalTo(15)
        }
    }
    
    //登录的按钮的点击方法
    @objc func buttonLoginCLick(){
        
    }
    
    
    lazy var loginBgButton: UIButton = {
        let  button = UIButton.init(type: .custom)
        button.backgroundColor = UIColor.colorWithHexString("#F5DEB3")
        button.addTarget(self, action: #selector(buttonLoginCLick), for: .touchUpInside)
        button.layer.cornerRadius = 5
        button.layer.masksToBounds = true
        return button
    }()
     
    lazy var titleLabel : UILabel = {
        let label = UILabel.init(titleString: "登录后可同步订阅内容", textColorString: "#DAA520", fontNumber: 15, textAlignments: .left, numberLines: 1)
        label.font = UIFont.boldSystemFont(ofSize: 15)
        return label
    }()
    
    lazy var subLabel : UILabel = {
         let label = UILabel.init(titleString: "新用户还可领取VIP权益", textColorString: "#CDAF95", fontNumber: 13, textAlignments: .left, numberLines: 1)
         return label
     }()
     
    lazy var clickLoginLabel: UILabel = {
        let label = UILabel.init(titleString: "立即登录", textColorString: "#FFFFFF", fontNumber: 14, textAlignments: .center, numberLines: 1)
        label.backgroundColor = UIColor.colorWithHexString("#FF8247")
        label.layer.cornerRadius = 15
        label.layer.masksToBounds = true
        return label
    }()
    
    lazy var reminderLabel : UILabel = {
        let label = UILabel.init(titleString: "----- 你可能感兴趣的内容 ------", textColorString: "#CDC9C9", fontNumber: 13, textAlignments: .center, numberLines: 1)
        return label
    }()
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
}
