//
//  ListenHeaderView.swift
//  HFWYYProject
//
//  Created by Chen on 2021/3/5.
//  Copyright © 2021 CH. All rights reserved.
//

import UIKit

class ListenHeaderView: UIView {
    

 
    override init(frame: CGRect) {
        super.init(frame: frame)
        for index in 0...3 {
            let button  = UIButton.init(type: .custom)
            button.setTitle("哈喽", for: .normal)
            button.setImage(UIImage(named: "mine_messgae"), for: .normal)
            button.hf_layoutButtonEdgInsets(.HFButtonEdgeInsetsStyleTop, spaceNumber: 10)
            button.titleLabel?.font = UIFont.systemFont(ofSize: 14)
            self.addSubview(button)
            let  item_Width = (HFFMScreen_Width - ( 25 * 5)) / 4
            button.frame = CGRect(x: 25 + (item_Width + 25) * CGFloat(index), y: 0, width: item_Width, height: item_Width)
        }
    }
    
    
    var dataArray  : [HFFMListenFourDataModel]?{
        didSet{
            for subview in self.subviews{
                subview.removeFromSuperview()
            }
            for (index , element) in dataArray!.enumerated(){
                let button  = UIButton.init(type: .custom)
                button.setTitle(element.title, for: .normal)
                button.setTitleColor(.darkGray, for: .normal)
                button.backgroundColor = .red
                //                button.kf.setImage(with: element.coverPath as! Resource, for: .normal)
                button.hf_layoutButtonEdgInsets(.HFButtonEdgeInsetsStyleTop, spaceNumber: 10)
                button.titleLabel?.font = UIFont.systemFont(ofSize: 14)
                self.addSubview(button)
                let  item_Width = (HFFMScreen_Width - ( 25 * 5)) / 4
                button.frame = CGRect(x: 25 + (item_Width + 25) * CGFloat(index), y: 20, width: item_Width, height: item_Width)
                button.addTarget(self, action: #selector(buttonClickCallBack(btn:)), for: .touchUpInside)
            }
        }
    }
    
    @objc func buttonClickCallBack(btn : UIButton) {
        
    }
    
    
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}
