//
//  HFFMProgramListViewController.swift
//  HFWYYProject
//
//  Created by Chen on 2021/4/13.
//  Copyright © 2021 CH. All rights reserved.
//

import UIKit

class HFFMProgramListViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationController?.setNavigationBarHidden(false, animated: false)
        self.view.backgroundColor = .white
    }

}
