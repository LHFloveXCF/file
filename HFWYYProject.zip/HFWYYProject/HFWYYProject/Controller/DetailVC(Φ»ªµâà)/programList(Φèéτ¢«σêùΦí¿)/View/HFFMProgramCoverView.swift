//
//  HFFMProgramCoverView.swift
//  HFWYYProject
//
//  Created by Chen on 2021/4/13.
//  Copyright © 2021 CH. All rights reserved.
//

import UIKit

class HFFMProgramCoverView: UIView {
    override init(frame: CGRect) {
        super.init(frame: frame)
        self.backgroundColor = .red
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
}
