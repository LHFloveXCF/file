//
//  HFFMProgramAPI.swift
//  HFWYYProject
//
//  Created by Chen on 2021/4/13.
//  Copyright © 2021 CH. All rights reserved.
//

import Foundation
import Moya
import SwiftyJSON
import HandyJSON


let programeAPIProvider =  MoyaProvider<HFFMProgrameModelAPI>()



enum HFFMProgrameModelAPI {
    case programeModePage(Int, Int)
}

extension HFFMProgrameModelAPI : TargetType{
    var baseURL: URL {
        return URL(string: "https://mobile.ximalaya.com")!
    }
    
    var path: String {
        switch self {
        case .programeModePage:
            return "/mobile-album/album/page/ts-1618304795644"
        default:
            break
        }
    }
    
    var method: Moya.Method {
        return .get
    }
    
    var sampleData: Data {
        return "".data(using: String.Encoding.utf8)!
    }
    
    var task: Task {
        var  parmeters:[String:Any] = [:]
        switch self {
        case .programeModePage(let albumId, let source):
            parmeters = ["albumId":albumId ,
                         "source" : source ,
                         "pageSize":"20",
                         "ac":"WIFI",
                         "device":"iPhone",
                         "isAsc":"true",
                         "isQueryInvitationBrand":"true",
                         "isVideoAsc":"true"]
        default:
            parmeters = [ : ]
        }
        return .requestParameters(parameters: parmeters, encoding: URLEncoding.default)
    }
    
    var headers: [String : String]? {
        return  nil
    }
    
    
}
