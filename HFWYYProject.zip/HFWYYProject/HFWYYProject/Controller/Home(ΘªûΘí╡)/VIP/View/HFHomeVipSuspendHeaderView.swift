//
//  HFHomeVipSuspendHeaderView.swift
//  HFWYYProject
//
//  Created by Chen on 2021/3/20.
//  Copyright © 2021 CH. All rights reserved.
//

import UIKit

class HFHomeVipSuspendHeaderView: UIView {

    override init(frame: CGRect) {
        super.init(frame: frame)
        self.backgroundColor = .randomColor()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    

}
