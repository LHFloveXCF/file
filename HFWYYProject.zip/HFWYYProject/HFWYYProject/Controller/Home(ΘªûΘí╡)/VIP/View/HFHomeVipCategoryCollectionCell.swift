//
//  HFHomeVipCategoryCollectionCell.swift
//  HFWYYProject
//
//  Created by Chen on 2021/3/19.
//  Copyright © 2021 CH. All rights reserved.
//

import UIKit
import KingfisherWebP

class HFHomeVipCategoryCollectionCell: UICollectionViewCell {
    override init(frame: CGRect) {
        super.init(frame: frame)
        self.addSubview(topImageView)
        self.addSubview(titleLabel)
    }
    
    var model : HFHomeVipContentCategoryModel? {
        didSet{
            guard model != nil else {
                return
            }
            self.titleLabel.text = model?.title
 
            self.topImageView.kf.setImage(with: URL(string: (model?.icon)!), placeholder: nil, options:  [.processor(WebPProcessor.default),.cacheSerializer(WebPSerializer.default)], progressBlock: nil) { (result) in
            }
        }
    }
    
    override func layoutSubviews() {
        super.layoutSubviews()
        topImageView.snp.makeConstraints { (make) in
            make.centerX.equalTo(self.snp_centerX)
            make.top.equalTo(self).offset(10)
            make.size.equalTo(CGSize(width: 30, height: 30))
        }
        
        titleLabel.snp.makeConstraints { (make) in
            make.centerX.equalTo(self.snp_centerX)
            make.top.equalTo(topImageView.snp_bottom).offset(10)
            make.height.equalTo(20)
        }
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    lazy var topImageView: UIImageView = {
        let imageView = UIImageView()
        return imageView
    }()
    
    
    lazy var titleLabel: UILabel = {
        let label = UILabel.init(titleString: "热门推荐", textColorString: "#565758", fontNumber: 15, textAlignments: .center, numberLines: 1)
        return label
    }()
}
