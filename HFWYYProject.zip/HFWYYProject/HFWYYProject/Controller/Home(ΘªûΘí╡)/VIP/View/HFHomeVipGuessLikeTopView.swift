//
//  HFHomeVipGuessLikeReusableView.swift
//  HFWYYProject
//
//  Created by Chen on 2021/3/19.
//  Copyright © 2021 CH. All rights reserved.
//

import UIKit

class HFHomeVipGuessLikeTopView: UIView {
    
    var delegate : HFHomeVipGuessLikeTopViewDelegate?
    
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        self.addSubview(titleLabel)
        self.addSubview(subTitleLabel)
        self.addSubview(moreButton)
    }
    var model  : HFHomeVipRecommendProperitesModel? {
        didSet{
            guard model != nil else {
                return
            }
            self.titleLabel.text = model?.title
            self.subTitleLabel.text = model?.subTitle
        }
    }
    
    override func layoutSubviews() {
        super.layoutSubviews()
        self.titleLabel.snp.makeConstraints { (make ) in
            make.top.left.equalTo(self).offset(10)
            make.height.equalTo(20)
        }
        self.subTitleLabel.snp.makeConstraints { (make ) in
            make.left.equalTo(self).offset(10)
            make.top.equalTo(self.titleLabel.snp_bottom).offset(0)
            make.height.equalTo(20)
        }
        moreButton.snp.makeConstraints { (make ) in
            make.centerY.equalTo(self.snp_centerY)
            make.right.equalTo(self.snp_right).offset(-10)
            make.size.equalTo(CGSize(width: 70, height: 30))
        }
    }
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    lazy var titleLabel: UILabel = {
        let label = UILabel.init(titleString: "猜你喜欢", textColorString: "#565758", fontNumber: 17, textAlignments: .center, numberLines: 1)
        label.font = UIFont.boldSystemFont(ofSize: 17)
        return label
    }()
    lazy var subTitleLabel: UILabel = {
        let label = UILabel.init(titleString: "听点爱听的", textColorString: "#B8860B", fontNumber: 12, textAlignments: .center, numberLines: 1)
        return label
    }()
    lazy var moreButton : UIButton = {
        let button =  UIButton.init(type: .custom)
        button.setTitle("更多", for: .normal)
        button.setImage(UIImage(named: "likeMore"), for: .normal)
        button.imagePosition(style: .right, spacing: 0)
        button.titleLabel?.font = UIFont.systemFont(ofSize: 13)
        button.setTitleColor(UIColor.colorWithHexString("#808081"), for: .normal)
        button.addTarget(self , action: #selector(moreButtonClick), for: .touchUpInside)
        return button
    }()
    
    @objc func moreButtonClick(){
        if self.delegate != nil && ((self.delegate?.responds(to: Selector.init(("getMoreguessLikeList")))) != nil) {
            self.delegate?.getMoreguessLikeList()
        }
    }
}

protocol HFHomeVipGuessLikeTopViewDelegate : NSObjectProtocol {
    func getMoreguessLikeList()
}
