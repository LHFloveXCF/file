//
//  HFHomeVipListenTableViewCell.swift
//  HFWYYProject
//
//  Created by Chen on 2021/3/20.
//  Copyright © 2021 CH. All rights reserved.
//

import UIKit

class HFHomeVipListenTableViewCell: UITableViewCell {

    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier )
        self.selectionStyle = .none
        
//        self.backgroundColor = .randomColor()
        
     
        contentView.addSubview(coverBgView)
        
        (coverBgView).addSubview(coverImageView)
        (coverBgView).addSubview(titleLabel)
        (coverBgView).addSubview(subTitleLabel)
        (coverBgView).addSubview(statusLabel)
        (coverBgView).addSubview(playImageView)
        
    }
    
    
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    override func layoutSubviews() {
        super.layoutSubviews()
        coverBgView.snp.makeConstraints { (make ) in
            make.left.top.equalTo(contentView).offset(10)
            make.size.equalTo(CGSize(width: HFFMScreen_Width - 90, height: 90))
        }
        self.coverImageView.snp.makeConstraints { (make ) in
            make.left.top.equalTo((coverBgView)).offset(10)
            make.size.equalTo(CGSize(width: 40, height: 40))
        }
        self.titleLabel.snp.makeConstraints { (make ) in
            make.left.equalTo(coverImageView.snp_right).offset(10)
            make.top.equalTo(coverImageView.snp_top).offset(3)
            make.right.equalTo((coverBgView).snp_right).offset(-20)
        }
        self.subTitleLabel.snp.makeConstraints { (make ) in
            make.left.equalTo(coverImageView.snp_right).offset(18)
            make.top.equalTo(titleLabel.snp_bottom).offset(0)
            make.right.equalTo((coverBgView).snp_right).offset(-20)
        }
        self.statusLabel.snp.makeConstraints { (make ) in
            make.left.equalTo((coverBgView)).offset(10)
            make.bottom.equalTo((coverBgView).snp_bottom).offset(-10)
            make.right.equalTo((coverBgView).snp_right).offset(-80)
        }
    }
    
    lazy var coverBgView : UIView = {
        let view = UIView.init()
        view.layer.shadowColor = UIColor.colorWithHexString("#B5B5B5").cgColor
        view.layer.shadowOpacity = 1.0
        view.layer.shadowOffset = CGSize(width: 0, height: 0)
        view.layer.shadowRadius = 8
        view.layer.masksToBounds = false
        view.layer.cornerRadius = 8
        view.backgroundColor = .white
        return view
    }()
    lazy var coverImageView: UIImageView = {
        let imageView = UIImageView.init()
        imageView.backgroundColor = .randomColor()
        return imageView
    }()
    
    lazy var titleLabel: UILabel = {
        let label = UILabel.init(titleString: "开通VIP 畅听好书好课", textColorString: "#0A0A0A", fontNumber: 15, textAlignments: .left, numberLines: 1)
        label.font = UIFont.boldSystemFont(ofSize: 15)
        return label
    }()
    
    lazy var subTitleLabel: UILabel = {
        let label = UILabel.init(titleString: "开通VIP 畅听好书好课", textColorString: "#CD6839", fontNumber: 13, textAlignments: .left, numberLines: 1)
        return label
    }()
    
    lazy var statusLabel: UILabel = {
        let label = UILabel.init(titleString: "开通VIP 畅听好书好课", textColorString: "#CD6839", fontNumber: 13, textAlignments: .left, numberLines: 1)
        label.font = UIFont.boldSystemFont(ofSize: 15)
        return label
    }()
    lazy var playImageView: UIImageView = {
        let imageView = UIImageView.init()
        imageView.layer.cornerRadius  = 20
        imageView.layer.masksToBounds = true
        imageView.backgroundColor = .randomColor()
        return imageView
    }()

//    override var frame: CGRect{
//        didSet{
//            var newFrame = frame
////            newFrame.origin.x += 10
////            newFrame.size.width -= 80
//            newFrame.origin.y += 10
//            super.frame = newFrame
//        }
//    }
    
}
