//
//  HFHomeVipGuessLikeTableViewCell.swift
//  HFWYYProject
//
//  Created by Chen on 2021/3/19.
//  Copyright © 2021 CH. All rights reserved.
//

import UIKit

class HFHomeVipGuessLikeTableViewCell: UITableViewCell {
    
    var delegate  : HFHomeVipGuessLikeTableViewCellDelegate?
    
     let item_width :  CGFloat  = (HFFMScreen_Width - 10 * 6) / 3

    
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        self.selectionStyle = .none
        
 
        self.layer.shadowColor = UIColor.colorWithHexString("#B5B5B5").cgColor
        self.layer.shadowOpacity = 1.0
        self.layer.shadowOffset = CGSize(width: 0, height: 0)
        self.layer.shadowRadius = 8
        self.layer.masksToBounds = false
        self.layer.cornerRadius = 8
        
      
    }
    
    
    var model  : HFHomeVipRecommendModulesMolde? {
        didSet{
            guard  model != nil else {
                return
            }
            self.addSubview(topView)
            self.addSubview(guessLikeCollectionView)
            self.addSubview(changeButton)

            self.topView.model = model?.properties
                        
            self.guessLikeCollectionView.reloadData()
        }
    }
    
    
    override func layoutSubviews() {
        super.layoutSubviews()
        topView.snp.makeConstraints { (make ) in
            make.left.right.top.equalTo(self)
            make.height.equalTo(40)
        }
        guessLikeCollectionView.snp.makeConstraints { (make ) in
            make.left.equalTo(self).offset(10)
            make.right.equalTo(self.snp_right).offset(-10)
            make.height.equalTo((item_width + 30 + 20) * 2)
            make.top.equalTo(topView.snp_bottom).offset(20)
        }
        self.changeButton.snp.makeConstraints { (make ) in
            make.centerX.equalTo(self.snp_centerX)
            make.top.equalTo(guessLikeCollectionView.snp_bottom).offset(0)
            make.height.equalTo(40)
        }
    }

    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    lazy var guessLikeCollectionView: UICollectionView = {
        let flowlayout = UICollectionViewFlowLayout()
        flowlayout.itemSize = CGSize(width: item_width, height: item_width + 40)
        flowlayout.minimumInteritemSpacing = 10
        
        let collectionView = UICollectionView.init(frame: .zero, collectionViewLayout: flowlayout)
        collectionView.register(HFHomeGuessLikeCollectionViewCell.self, forCellWithReuseIdentifier: "guessLikeCollectionCell")
        collectionView.delegate = self
        collectionView.dataSource = self
        collectionView.backgroundColor = .white
        return collectionView
    }()
    lazy var topView : HFHomeVipGuessLikeTopView = {
        let view  = HFHomeVipGuessLikeTopView.init()
        view.delegate = self
        return view
    }()
    lazy var changeButton: UIButton = {
        let button = UIButton.init(type: .custom)
        button.setTitle("换一批", for: .normal)
        button.setTitleColor(UIColor.colorWithHexString("#C2C2C2"), for: .normal)
        button.titleLabel?.font = UIFont.systemFont(ofSize: 14)
        button.setImage(UIImage(named: "change_imageName"), for: .normal)
        button.imagePosition(style: .left, spacing: 10)
        button.addTarget(self, action: #selector(changeButtonClick), for: .touchUpInside)
        return button
    }()
    
    @objc func changeButtonClick(){
        if self.delegate != nil && ((self.delegate?.responds(to: Selector.init(("vipGuessLikeChangeDataList")))) != nil) {
            self.delegate?.vipGuessLikeChangeDataList()
        }
    }
    
    override var frame: CGRect{
        didSet{
            var newFrame = frame
            newFrame.origin.x += 10
            newFrame.size.width -= 2 * 10
            newFrame.origin.y += 10
            super.frame = newFrame
        }
    }
}

extension  HFHomeVipGuessLikeTableViewCell: UICollectionViewDelegate{
    
}

extension  HFHomeVipGuessLikeTableViewCell: UICollectionViewDataSource{
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return self.model!.albums!.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "guessLikeCollectionCell", for: indexPath) as!HFHomeGuessLikeCollectionViewCell
        cell.vipGuessLikeModel = self.model?.albums![indexPath.row]
        return cell
    }
}


protocol HFHomeVipGuessLikeTableViewCellDelegate : NSObjectProtocol {
    func vipGuessLikeChangeDataList()
    func homeVipGetMoreGuessLikeDataList()
}


extension HFHomeVipGuessLikeTableViewCell : HFHomeVipGuessLikeTopViewDelegate{
    func getMoreguessLikeList() {
        if self.delegate != nil && ((self.delegate?.responds(to: Selector.init(("homeVipGetMoreGuessLikeDataList")))) != nil) {
            self.delegate?.homeVipGetMoreGuessLikeDataList()
        }
    }
}
