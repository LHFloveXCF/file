//
//  HFHomeVipTopHeaderView.swift
//  HFWYYProject
//
//  Created by Chen on 2021/3/18.
//  Copyright © 2021 CH. All rights reserved.
//

import UIKit
import KingfisherWebP

class HFHomeVipTopHeaderView: UIView {

    override init(frame: CGRect) {
        super.init(frame: frame)
        self.addSubview(exchangeButton)
        self.exchangeButton.snp.makeConstraints { (make ) in
            make.centerX.equalTo(self.snp_centerX)
            make.centerY.equalTo(self.snp_centerY)
            make.size.equalTo(CGSize(width: 100, height: 30))
        }
    }
    
    var model : HFHomeVipCommunityDataModel? {
        didSet{
            guard model != nil else {
                 return
            }
            self.exchangeButton.kf.setImage(with: URL(string: (model?.image)!), for: .normal, placeholder: nil, options: [.processor(WebPProcessor.default),.cacheSerializer(WebPSerializer.default)], progressBlock: nil) { (result) in
            }
        }
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    
    lazy var exchangeButton: UIButton = {
        let button = UIButton.init(type: .custom)
        button.imageView?.contentMode = .scaleAspectFit
//        button.backgroundColor = .randomColor()
        return button
    }()

}
