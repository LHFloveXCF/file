//
//  HFHomeVipCategoryTableViewCell.swift
//  HFWYYProject
//
//  Created by Chen on 2021/3/19.
//  Copyright © 2021 CH. All rights reserved.
//

import UIKit

class HFHomeVipCategoryTableViewCell: UITableViewCell {

    
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        
        self.selectionStyle = .none
        
        
        
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    lazy var categryCollectionView: UICollectionView = {
        let flowLayout = UICollectionViewFlowLayout()
        let item_width = (HFFMScreen_Width - 20 * 2) / 6
        flowLayout.itemSize = CGSize(width: item_width , height: item_width)
        flowLayout.sectionInset = UIEdgeInsets(top: 10, left: 20, bottom: 10, right: 20)
        
        let collectionView = UICollectionView.init(frame: CGRect(x: 0, y: 0, width: HFFMScreen_Width, height: item_width * 2 + 40), collectionViewLayout: flowLayout)
        collectionView.backgroundColor = .white
        collectionView.register(HFHomeVipCategoryCollectionCell.self, forCellWithReuseIdentifier: "CollectionCell")
        collectionView.delegate = self
        collectionView.dataSource = self
        return collectionView
    }()
    
    override var frame: CGRect{
        didSet{
            var newFrame = frame
            newFrame.origin.y += 10
            newFrame.size.height -= 10
            super.frame = newFrame
        }
    }
    
    
    var model : HFHomeVipRecommendModulesMolde? {
        didSet{
            guard model != nil else {
                return
            }
            self.addSubview(categryCollectionView)
            self.categryCollectionView.reloadData()
        }
    }
    
}

extension HFHomeVipCategoryTableViewCell : UICollectionViewDelegate{
    
}

extension HFHomeVipCategoryTableViewCell : UICollectionViewDataSource{
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "CollectionCell", for: indexPath) as!HFHomeVipCategoryCollectionCell
        cell.model = self.model?.list![indexPath.row]
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return (self.model?.list!.count)!
    }
   
}
