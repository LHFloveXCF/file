//
//  HFVipUserHeaderTableViewCell.swift
//  HFWYYProject
//
//  Created by Chen on 2021/3/20.
//  Copyright © 2021 CH. All rights reserved.
//

import UIKit

class HFVipUserHeaderTableViewCell: UITableViewCell {
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        self.addSubview(bgButtonView)
               bgButtonView.addSubview(headerImageView)
               bgButtonView.addSubview(titleLabel)
               bgButtonView.addSubview(openVipImageView)
               bgButtonView.addSubview(priceImageView)
    }
    var model  : HFHomeVipRecommendModulesMolde?{
         didSet{
             guard model != nil else {
                 return
             }
//             self.titleLabel.text = model?.properties?.guideText
            
         }
     }
    
    override func layoutSubviews() {
        super.layoutSubviews()
        self.bgButtonView.snp.makeConstraints { (make ) in
            make.left.top.equalTo(self).offset(15)
            make.right.equalTo(self.snp_right).offset(-15)
            make.height.equalTo(80)
        }
        
        headerImageView.snp.makeConstraints { (make ) in
            make.centerY.equalTo(bgButtonView.snp_centerY)
            make.left.equalTo(bgButtonView).offset(15)
            make.size.equalTo(CGSize(width: 40, height: 40))
        }
        titleLabel.snp.makeConstraints { (make ) in
            make.centerY.equalTo(bgButtonView.snp_centerY)
            make.left.equalTo(headerImageView.snp_right).offset(15)
            make.height.equalTo(20)
        }
        openVipImageView.snp.makeConstraints { (make ) in
            make.right.equalTo(bgButtonView.snp_right).offset(-30)
            make.centerY.equalTo(bgButtonView.snp_centerY)
            make.size.equalTo(CGSize(width: 90, height: 50))
        }
        
        priceImageView.snp.makeConstraints { (make ) in
            make.bottom.equalTo(openVipImageView.snp_top).offset(8)
            make.left.equalTo(openVipImageView.snp_centerX)
            make.size.equalTo(CGSize(width: 50, height: 16))
        }
        
    }

    lazy var bgButtonView: UIButton = {
           let button = UIButton.init(type: .custom)
           button.backgroundColor = UIColor.colorWithHexString("#E6B88C")
           button.layer.cornerRadius = 8
           button.layer.masksToBounds = true
           return button
       }()
       
       lazy var headerImageView: UIImageView = {
           let imageView = UIImageView.init()
           imageView.layer.cornerRadius  = 20
           imageView.layer.masksToBounds = true
           imageView.backgroundColor = .randomColor()
           return imageView
       }()
       
       lazy var titleLabel: UILabel = {
           let label = UILabel.init(titleString: "开通VIP 畅听好书好课", textColorString: "#CD6839", fontNumber: 15, textAlignments: .left, numberLines: 1)
           label.font = UIFont.boldSystemFont(ofSize: 15)
           return label
       }()
       lazy var openVipImageView: UIImageView = {
           let imageView = UIImageView.init()
           imageView.backgroundColor = .randomColor()
           return imageView
       }()
       
       lazy var priceImageView: UIImageView = {
           let imageView = UIImageView.init()
           imageView.backgroundColor = .randomColor()
           return imageView
       }()
       required init?(coder: NSCoder) {
           fatalError("init(coder:) has not been implemented")
       }

}
