//
//  HFHomeVipViewModel.swift
//  HFWYYProject
//
//  Created by Chen on 2021/3/19.
//  Copyright © 2021 CH. All rights reserved.
//

import UIKit
import SwiftyJSON
import HandyJSON

class HFHomeVipViewModel: NSObject {
    
    var vipCommunityModel : HFHomeVipCommunityDataModel?
    var vipRecommendModel : HFHomeVipRecommendDataModel?
    var vipRecommendModulesModel : HFHomeVipRecommendModulesMolde?
    var vipRecommednGuessLikeModel  : [HFHomeVipGuessLikeAlbumsModel]?
    
    var vipMoreGuessLikeListModel : [HFHomeVipGuessLikeAlbumsModel]? = []
    
    
    
    typealias getDatablock = ()->Void
    
    var havaMoreGuessLike : Bool?
    
    
}


extension  HFHomeVipViewModel{
    func getVipTopExchangeData(updataBlock : @escaping getDatablock) {
        HFFMHomeVipProvider.request(.homeVipExchange) { (result ) in
             if case let  .success(response) = result{
             //解析数据
             let data = try? response.mapJSON()
                let json = JSON(data!)
                print("交流的图片==\(json)")
                if let mappObject = JSONDeserializer<HFHomeVipCommunityModel>.deserializeFrom(json: json.description) {
                    if mappObject.msg == "success" {
                        self.vipCommunityModel = mappObject.data
                        updataBlock()
                    }
                }
            }
        }
    }
}

extension  HFHomeVipViewModel{
    func getVipCommendDataList(updataBlock : @escaping getDatablock)  {
        //获得json的文件路径
        let  path  = Bundle.main.path(forResource: "HFHomeVipRecommend", ofType: "json")
        //获得json文件里面的内容,NSData格式
        let jsonData = NSData(contentsOfFile: path!)
        //解析书库
         let json = JSON(jsonData!)
        if let mappObject = JSONDeserializer<HFHomeVipRecommendModel>.deserializeFrom(json: json.description) {
            self.vipRecommendModel = mappObject.data
            
            for (index , model) in mappObject.data!.modules!.enumerated() {
                
                if  model.moduleType == "VIP_NEW_STATUS_V3" {
                    if let userVipModel = JSONDeserializer<HFHomeVipRecommendModulesMolde>.deserializeFrom(json: json["data"]["modules"][index].description) {
                        self.vipRecommendModulesModel = userVipModel
                    }
                }
                if model.moduleType == "VIP_SQUARE" {
                    if  let vipSquare = JSONDeserializer<HFHomeVipRecommendModulesMolde>.deserializeFrom(json: json["data"]["modules"][index].description) {
                        self.vipRecommendModulesModel = vipSquare
                    }
                }
                if model.moduleType == "RECOMMENDATION" {
                    if let guessYouLikeModel = JSONDeserializer<HFHomeVipRecommendModulesMolde>.deserializeFrom(json: json["data"]["modules"][index].description){
                        self.vipRecommendModulesModel?.albums = guessYouLikeModel.albums
                    }
                }
                updataBlock()
            }
        }
    }
    
    //获取Vip界面 的更多喜欢
    func  getVipMoreGuessLike(pageNumber: Int , updataBlock : @escaping getDatablock)  {
        HFFMHomeVipProvider.request(.vipMoreGuessLikeList(pageNumber)) { (result) in
            if case let .success(response) = result{
                let data = try? response.mapJSON()
                let json = JSON(data!)
                print("获取Vip界面 的更多喜欢 ==\(json)")
                print("pageNumber == \(pageNumber)")
                if let mappObject = JSONDeserializer<HFHomeVipMoreGuessLikeModel>.deserializeFrom(json: json["data"].description) {
                    self.havaMoreGuessLike  = mappObject.hasMore
                    print("self.havaMoreGuessLike ==\(mappObject.hasMore)")
                    if pageNumber == 1 {
                        self.vipMoreGuessLikeListModel?.removeAll()
                        self.vipMoreGuessLikeListModel = mappObject.data
                    }else{
                        self.vipMoreGuessLikeListModel! += mappObject.data!
                    }
                    updataBlock()
                }
            }
            
        }
     }
}

extension  HFHomeVipViewModel {
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        let modulesType = self.vipRecommendModel!.modules![indexPath.section].moduleType
         
        if modulesType == "VIP_NEW_STATUS_V3" {
             return 100
        }else if modulesType == "VIP_SQUARE" {
          return 180
        }else if modulesType == "RECOMMENDATION" {
            return 400 + 10
        }else if modulesType == "HISTORY"{
            return 80
        } else {
            return 0.001
        }
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return (self.vipRecommendModel?.modules!.count)!
    }
}
