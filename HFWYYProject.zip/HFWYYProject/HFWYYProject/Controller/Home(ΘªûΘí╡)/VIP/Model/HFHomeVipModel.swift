//
//  HFHomeVipModel.swift
//  HFWYYProject
//
//  Created by Chen on 2021/3/19.
//  Copyright © 2021 CH. All rights reserved.
//

import Foundation
import HandyJSON


//顶部交流
struct HFHomeVipCommunityModel: HandyJSON {
    var ret : Int = 0
    var msg : String?
    var data:HFHomeVipCommunityDataModel?
    
}

struct HFHomeVipCommunityDataModel : HandyJSON {
    var moduleType : String?
    var image : String?
    var url : String?
    var sortEnable : Bool = false
    var moduleId : Int = 0
}



//Vip列表
struct HFHomeVipRecommendModel: HandyJSON {
    var ret : Int = 0
    var msg : String?
    var data : HFHomeVipRecommendDataModel?
}

struct HFHomeVipRecommendDataModel :  HandyJSON {
    var vipStatus : Int = 0
    var now : Int = 0
    var isFreeTrail : Bool = false
    var isAutoRenew : Bool = false
    var channelLifeStatus : Int = 0
    var transformRate : Int = 0
    var nickName: String?
    var logoPic : String?
    var modules : [HFHomeVipRecommendModulesMolde]?
    
}

struct HFHomeVipRecommendModulesMolde:HandyJSON {
    var moduleType :String?
    var sortEnable : Bool = false
    var moduleId : Int = 0
    var moduleName : String?
    var nickName :String?
    var logoPic :String?
    var levelUrl : String?
    var properties :HFHomeVipRecommendProperitesModel?
    
    //内容标签
    var squareType : String?
    var squareClassType : String?
    var list : [HFHomeVipContentCategoryModel]?
    
    
    var loopSize : Int = 0
    var albums : [HFHomeVipGuessLikeAlbumsModel]?
    //猜你喜欢
    
    
    //最近在听
    var records :[HFHomeVipLatelyListenRecordsModel]?
    
}

struct HFHomeVipRecommendProperitesModel: HandyJSON {
    var sortEnable : Bool = false
    var moduleId : Int = 0
    var guideText : String?
    var guideTextUrl : String?
    var buttonType :String?
    var buttonImage :String?
    var buttonText :String?
    var buttonIcon :String?
    var buttonUrl :String?
    var rightDetailsText :String?
    var rightDetailsUrl :String?
    var showLevel : Bool = false
    var classType : String?
    
    
    var title :String?
    var subTitle : String?
    var cardClass :String?
    var hasMore : Bool = false
    
    
}

////内容分类的标签
struct HFHomeVipContentCategoryModel : HandyJSON {
    var title :String?
    var icon :String?
    var type :Int = 0
    var value :String?
    var iconForNight :String?
    var name :String?
}

//vip猜你喜欢
struct HFHomeVipGuessLikePropertiesModel : HandyJSON {
    var title: String?
    var subTitle :String?
    var hasMore : Bool = false
    var cardClass : String?
}

//vip更多猜你喜欢
struct HFHomeVipMoreGuessLikeModel: HandyJSON {
    var pageSize : Int = 0
    var pageNo : Int  = 0
    var data : [HFHomeVipGuessLikeAlbumsModel]?
    var totalCount : Int = 0
    var hasMore : Bool = false
}
struct HFHomeVipGuessLikeAlbumsModel : HandyJSON {
    var albumId : Int = 0
    var uid : Int = 0
    var intro  : String?
    var nickname  : String?
    var coverPath  : String?
    var logoPic  : String?
    var title : String?
    
    var tags : String?
    var tracks :Int = 0
    var playsCounts : Int = 0
    var serialState : Int = 0
    
    var trackId : Int = 0
    var recSrc : String?
    var recTrack : String?

    var isPaid: Bool = false
    var commentsCount : Int = 0
    var priceTypeId : Int = 0
    var price : Int = 0
    var discountedPrice : Int = 0
    var displayPrice : String?
    var displayDiscountedPrice : String?
    var priceTypeEnum : Int = 0
    var refundSupportType : Int = 0
    var isVipFree : Bool = false
    var priceUnit : String?
    var isDraft : Bool = false
    var vipFreeType : Int = 0
    var preferredType : Int = 0
    var provider : String?
    var contractStatus : Int = 0
    var subTitle : String?
    var digStatus : Int = 0
    var deleted : Bool = false
    var albumSubscript : String?
    
    var  id : Int = 0
    
    
}


//焦点图
struct HFHomeVipFocusModel: HandyJSON {
     var moduleType :String?
     var sortEnable : Bool = false
     var moduleId : Int = 0
     var moduleName : String?
}
struct HFHomeVipFocusImagesModel : HandyJSON{
    var ret : Int = 0
    var responseId : Int = 0
    
    
}


//最近在听
//struct HFHomeVipLatelyListenModel: HandyJSON {
//    var moduleType :String?
//    var sortEnable : Bool = false
//    var moduleId : Int = 0
//    var moduleName : String?
//    var records : [HFHomeVipLatelyListenRecordsModel]?
//
//}
struct HFHomeVipLatelyListenRecordsModel: HandyJSON{
    var startedAt : Int = 0
    var endAt : Int = 0
    var direction : Int = 0
    var breakSecond : Int = 0
    var albumId : Int = 0
    var trackId : Int = 0
    var trackTitle : String?
    var albumTitle : String?
    var platform : Int = 0
    var position : Int = 0
    var lastUpTrackAt : Int = 0
    var albumCoverPath: String?
    var finished : Int = 0
    var albumSubscript : String?
}
