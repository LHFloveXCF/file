//
//  HFHomeMoreGuessLikeTableViewCell.swift
//  HFWYYProject
//
//  Created by Chen on 2021/3/23.
//  Copyright © 2021 CH. All rights reserved.
//

import UIKit
import Kingfisher
import KingfisherWebP

class HFHomeMoreGuessLikeTableViewCell: UITableViewCell {

    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier )
        self.selectionStyle = .none
        contentView.addSubview(coverImageView)
        contentView.addSubview(isFinshedLabel)
        contentView.addSubview(titleLabel)
        contentView.addSubview(subtitleLabel)
        contentView.addSubview(playButton)
        contentView.addSubview(collectButton)
        coverImageView.addSubview(youXuanImageView)
//        contentView.addSubview(VipImageView)

    }
    
    var model : HFHomeVipGuessLikeAlbumsModel? {
        didSet{
            guard model != nil else {
                return
            }
            
            self.coverImageView.kf.setImage(with: URL(string: (model?.coverPath)!))
             self.titleLabel.text = model?.title
            
 
            
           
            self.subtitleLabel.text = model?.subTitle
            let  tracks : Int = model!.tracks
            
            self.collectButton.setTitle(String("\(tracks) 集"), for: .normal)
            
            let json : [String : Any] = ( self.stringValueDic((model?.albumSubscript)!)!)
            let albumSubscriptUrl : String = json["url"]! as! String
            
            self.youXuanImageView.kf.setImage(with: URL(string: albumSubscriptUrl), placeholder: nil, options: [.processor(WebPProcessor.default),.cacheSerializer(WebPSerializer.default)], progressBlock: nil) { (result) in
            }
        }
    }
    
    func stringValueDic(_ str: String) -> [String : Any]?{
        
        let data = str.data(using: String.Encoding.utf8)
        
        if let dict = try? JSONSerialization.jsonObject(with: data!, options: JSONSerialization.ReadingOptions.mutableContainers) as? [String : Any] {
            
            return dict
            
        }
        return nil
        
    }
    override func layoutSubviews() {
        super.layoutSubviews()
        self.coverImageView.snp.makeConstraints { (make ) in
            make.left.top.equalTo(self).offset(20)
            make.size.equalTo(CGSize(width: 70, height: 70))
        }
        self.isFinshedLabel.snp.makeConstraints { (make ) in
            make.left.equalTo(coverImageView.snp_right).offset(8)
            make.top.equalTo(coverImageView).offset(3)
            make.size.equalTo(CGSize(width: 30 , height: 15))
        }
        
        self.titleLabel.snp.makeConstraints { (make ) in
            make.left.equalTo(isFinshedLabel.snp_right).offset(8)
            make.top.equalTo(coverImageView)
            make.right.equalTo(self.snp_right).offset(-20)
        }
        self.subtitleLabel.snp.makeConstraints { (make ) in
            make.left.equalTo(coverImageView.snp_right).offset(8)
            make.top.equalTo(titleLabel.snp_bottom).offset(10)
            make.right.equalTo(self.snp_right).offset(-20)
        }
        self.playButton.snp.makeConstraints { (make ) in
            make.left.equalTo(coverImageView.snp_right).offset(8)
            make.top.equalTo(subtitleLabel.snp_bottom).offset(10)
            make.size.equalTo(CGSize(width: 70, height: 20))
        }
        self.collectButton.snp.makeConstraints { (make ) in
            make.left.equalTo(playButton.snp_right).offset(8)
            make.top.equalTo(subtitleLabel.snp_bottom).offset(10)
            make.size.equalTo(CGSize(width: 70, height: 20))
        }
        
        self.youXuanImageView.snp.makeConstraints { (make ) in
            make.left.equalTo(coverImageView.snp_left).offset(-1)
            make.top.equalTo(coverImageView.snp_top).offset(0)
//            make.right.equalTo(coverImageView.snp_right).offset(-20)
            make.height.equalTo(12)
            make.width.equalTo(40)
        }
        
    }
    
    lazy var coverImageView: UIImageView = {
        let imageView = UIImageView()
        imageView.layer.cornerRadius = 5
        imageView.layer.masksToBounds = true
        imageView.backgroundColor = .randomColor()
        return imageView
    }()
    lazy var isFinshedLabel: UILabel = {
        let label = UILabel.init(titleString: "完结", textColorString: "#937666", fontNumber: 11, textAlignments: .center, numberLines: 1)
        label.layer.borderColor = UIColor.colorWithHexString("#937666").cgColor
        label.layer.borderWidth = 0.5
        label.layer.cornerRadius = 2
        label.layer.masksToBounds = true
        return label
    }()
    lazy var titleLabel: UILabel = {
        let label = UILabel.init(titleString: "热门推荐", textColorString: "#000000", fontNumber: 15, textAlignments: .left, numberLines: 2)
        label.font = UIFont.boldSystemFont(ofSize: 15)
        return label
    }()
    lazy var subtitleLabel: UILabel = {
         let label = UILabel.init(titleString: "热门推荐", textColorString: "#88898A", fontNumber: 13, textAlignments: .left, numberLines: 1)
         return label
     }()
    lazy var playButton: UIButton = {
        let button = UIButton.init(type: .custom)
        button.setTitle("48580万", for: .normal)
        button.setImage(UIImage(named: "play_ImageName"), for: .normal)
        button.imagePosition(style: .left, spacing: 5)
        button.titleLabel?.font = UIFont.systemFont(ofSize: 13)
        button.setTitleColor(UIColor.colorWithHexString("#88898A"), for: .normal)
        return button
    }()
    lazy var collectButton: UIButton = {
        let button = UIButton.init(type: .custom)
        button.setTitle("48集", for: .normal)
        button.setImage(UIImage(named: "voiceImage"), for: .normal)
        button.imagePosition(style: .left, spacing: 5)
        button.titleLabel?.font = UIFont.systemFont(ofSize: 13)
        button.setTitleColor(UIColor.colorWithHexString("#88898A"), for: .normal)
        return button
    }()
    
    lazy var youXuanImageView: UIImageView = {
        let imageView = UIImageView()
//        imageView.backgroundColor  = .red
//        imageView.contentMode = .scaleAspectFit
        return imageView
    }()
    
    lazy var VipImageView: UIImageView = {
        let imageView = UIImageView()
        return imageView
    }()
    override var frame: CGRect{
        didSet{
            var  newFrame = frame
            newFrame.size.height -= 5
            super.frame = newFrame
        }
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}
