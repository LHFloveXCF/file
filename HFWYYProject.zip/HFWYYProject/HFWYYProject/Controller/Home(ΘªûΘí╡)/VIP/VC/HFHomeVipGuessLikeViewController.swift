//
//  HFHomeVipGuessLikeViewController.swift
//  HFWYYProject
//
//  Created by Chen on 2021/3/23.
//  Copyright © 2021 CH. All rights reserved.
//

import UIKit

class HFHomeVipGuessLikeViewController: HFFMBaseViewController {
    var pageNumber : Int = 1
    

    override func viewDidLoad() {
        super.viewDidLoad()
        self.view.backgroundColor = UIColor.colorWithHexString("#F1F2F4")
        self.navigationController?.setNavigationBarHidden(false, animated: false)
        self.title = "猜你喜欢"
        self.view.addSubview(guessLikeTableView)
        
        self.addRefrshTableView()
     }
    
    func addRefrshTableView( )  {
        guessLikeTableView.initRefreshView()
        guessLikeTableView.mj_header?.refreshingBlock = { [weak self] in
            self?.pageNumber = 1
            self?.getGuessLikeMoreList()
        }
        
        guessLikeTableView.mj_footer?.refreshingBlock = { [weak self] in
            
            if self?.viewModel.havaMoreGuessLike == false  {
                self?.guessLikeTableView.mj_footer?.endRefreshingWithNoMoreData()
                return
            }
            self!.getGuessLikeMoreList()
        }
        guessLikeTableView.mj_header?.beginRefreshing()
        
        
        
    }
    
    func  getGuessLikeMoreList() {
        weak var weakSelf = self
        viewModel.getVipMoreGuessLike(pageNumber: self.pageNumber) {
            weakSelf?.guessLikeTableView.mj_header?.endRefreshing()
            weakSelf?.guessLikeTableView.mj_footer?.endRefreshing()
            weakSelf?.pageNumber += 1
            weakSelf?.guessLikeTableView.reloadData()
        }
        
    }
    
    lazy var guessLikeTableView: UITableView = {
        let tableview = UITableView.init(frame: CGRect(x: 0, y: 0, width: HFFMScreen_Width, height: HFFMScreen_Height), style: .plain)
        tableview.delegate = self
        tableview.dataSource = self
        tableview.register(HFHomeMoreGuessLikeTableViewCell.self, forCellReuseIdentifier: "MoreGuessLikeTableViewCell")
        tableview.separatorStyle = .none
        tableview.backgroundColor = .clear
        return tableview
    }()
    lazy var viewModel : HFHomeVipViewModel = {
        return HFHomeVipViewModel()
    }()
    
}

extension HFHomeVipGuessLikeViewController: UITableViewDelegate {
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 110 + 5
    }
}

extension HFHomeVipGuessLikeViewController: UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.viewModel.vipMoreGuessLikeListModel!.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "MoreGuessLikeTableViewCell", for: indexPath) as!HFHomeMoreGuessLikeTableViewCell
        cell.model = self.viewModel.vipMoreGuessLikeListModel![indexPath.row]
        return cell
    }
    
    
}
