//
//  HFHomeVIPVC.swift
//  HFWYYProject
//
//  Created by Chen on 2021/3/9.
//  Copyright © 2021 CH. All rights reserved.
//

import UIKit

class HFHomeVIPVC: UIViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        //初始化界面
        self.setUpSubViews()
        // 解决方式一: weak
        weak var weakSelf = self
        vipViewModel.getVipTopExchangeData {
            weakSelf?.topExchangeView.model = self.vipViewModel.vipCommunityModel
        }
        
        vipViewModel.getVipCommendDataList {
            weakSelf?.vipTableView.reloadData()
        }
    }
    
    func setUpSubViews() {
        self.view.addSubview(searchView)
        searchView.snp.makeConstraints { (make ) in
            make.left.equalTo(self.view).offset(0)
            make.top.equalTo(self.view).offset(0)
            make.size.equalTo(CGSize(width: HFFMScreen_Width - 20 - 100, height: 40))
        }
        self.view.addSubview(topExchangeView)
        topExchangeView.snp.makeConstraints { (make ) in
            make.left.equalTo(searchView.snp_right).offset(10)
            make.centerY.equalTo(searchView.snp_centerY)
            make.height.equalTo(44)
            make.right.equalTo(self.view.snp_right).offset(-20)
        }
        self.view.addSubview(vipTableView)
        vipTableView.snp.makeConstraints { (make ) in
            make.top.equalTo(searchView.snp_bottom).offset(0)
            make.leading.trailing.bottom.equalToSuperview()
        }
    }
    
    lazy var searchView: HFFMSearchView = {
        let view = HFFMSearchView.init()
        return view
    }()
    
    lazy var topExchangeView: HFHomeVipTopHeaderView = {
        let view = HFHomeVipTopHeaderView.init(frame: CGRect(x: HFFMScreen_Width - 110, y: 8, width: 80, height: 30))
        return view
    }()
    
    lazy var vipTableView: UITableView = {
        let tableView = UITableView.init(frame: .zero, style: .grouped)
        tableView.delegate = self
        tableView.dataSource = self
        tableView.separatorStyle = .none
        tableView.register(HFVipUserHeaderTableViewCell.self, forCellReuseIdentifier: "UserHeaderTableViewCell")
        tableView.register(HFHomeVipCategoryTableViewCell.self, forCellReuseIdentifier: "CategoryTableViewCell")
        tableView.register(HFHomeVipGuessLikeTableViewCell.self, forCellReuseIdentifier: "GuessLikeTableViewCell")
        tableView.register(HFHomeVipListenTableViewCell.self, forCellReuseIdentifier: "ListenTableViewCell")
        tableView.backgroundColor = .white
        return tableView
    }()
    lazy var vipViewModel: HFHomeVipViewModel = {
        return HFHomeVipViewModel()
    }()
}


extension HFHomeVIPVC: UITableViewDelegate{
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return self.vipViewModel.tableView(tableView, heightForRowAt: indexPath)
    }
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        if section == 5 {
            let headerView = HFHomeVipSuspendHeaderView.init(frame: CGRect(x: 0, y: 0, width: HFFMScreen_Width, height: 40))
            return headerView
        }else{
            return UIView()
        }
    }
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        if section == 5 {
            return 40
        }else{
            return 0.001
        }
    }
    func tableView(_ tableView: UITableView, viewForFooterInSection section: Int) -> UIView? {
        return UIView()
    }
    func tableView(_ tableView: UITableView, heightForFooterInSection section: Int) -> CGFloat {
        return 10
    }
}

extension HFHomeVIPVC : UITableViewDataSource{
    func numberOfSections(in tableView: UITableView) -> Int {
        return self.vipViewModel.numberOfSections(in: tableView)
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 1
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let  cell  = UITableViewCell()
        
        let modulesType = self.vipViewModel.vipRecommendModel!.modules![indexPath.section].moduleType
        if modulesType == "VIP_NEW_STATUS_V3" {
            let cell  = tableView.dequeueReusableCell(withIdentifier: "UserHeaderTableViewCell", for: indexPath) as! HFVipUserHeaderTableViewCell
            cell.model = self.vipViewModel.vipRecommendModulesModel
            return cell
        }
        
        if modulesType == "VIP_SQUARE" {
            let cell  = tableView.dequeueReusableCell(withIdentifier: "CategoryTableViewCell", for: indexPath) as!HFHomeVipCategoryTableViewCell
            cell.model = self.vipViewModel.vipRecommendModulesModel
            return cell
        }
        
        if modulesType == "RECOMMENDATION" { //猜你喜欢
            let cell  = tableView.dequeueReusableCell(withIdentifier: "GuessLikeTableViewCell", for: indexPath) as!HFHomeVipGuessLikeTableViewCell
            cell.model = self.vipViewModel.vipRecommendModulesModel
            cell.delegate = self
            return cell
        }
        
        if (modulesType == "HISTORY"){ //最近在听
            let cell  = tableView.dequeueReusableCell(withIdentifier: "ListenTableViewCell", for: indexPath) as!HFHomeVipListenTableViewCell
            return cell
        }
        return cell
    }
}


extension HFHomeVIPVC : HFHomeVipGuessLikeTableViewCellDelegate{
    func homeVipGetMoreGuessLikeDataList() {
        let  vc = HFHomeVipGuessLikeViewController()
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    func vipGuessLikeChangeDataList() {
         
    }
}
