//
//  HFFMVIPAPI.swift
//  HFWYYProject
//
//  Created by Chen on 2021/3/18.
//  Copyright © 2021 CH. All rights reserved.
//

import Foundation
import Moya
import SwiftyJSON
import HandyJSON

let HFFMHomeVipProvider =  MoyaProvider<HFFMHomeVIPAPI>()


enum HFFMHomeVIPAPI {
    case homeVipExchange
    case homeVipContengList
    case vipMoreGuessLikeList(Int)
}


extension HFFMHomeVIPAPI : TargetType{
    var baseURL: URL {
        return URL(string: "https://mobile.ximalaya.com")!
    }
    var path: String {
        switch self {
        case .homeVipExchange:
            return "/vip/v1/club/entrance/ts-1616052410"
        case .homeVipContengList :
            return "/vip/v1/recommand/ts-1616141687197"
        case .vipMoreGuessLikeList(_):
            return "/vip/v1/channel/recommendation/ts-1616491864838"
        }
    }
    
    var method: Moya.Method {
        return .get
    }
    
    var sampleData: Data {
        return "".data(using: String.Encoding.utf8)!
    }
    
    var task: Task {
        var  parmeters:[String:Any] = [:]
        switch self {
        case .homeVipContengList:
            parmeters = ["appid":"0",
                         "device":"iPhone",
                         "deviceId":"5AC6CCBA-21C6-47C7-9971-B75C6B257988",
                         "isAppleReview":"false",
                         "network":"WIFI",
                         "operator":"3",
                         "scale":"2",
                         "uid":"148102319",
                         "version":"7.3.18",
                         "xt":"1616141687197"]
        case .vipMoreGuessLikeList(let index):
              parmeters = ["pageNo":index, "pageSize":"20"]
        default:
            parmeters = [ : ]
        }
        return  .requestParameters(parameters: parmeters, encoding: URLEncoding.default)
    }
    
    var headers: [String : String]? {
        return nil
    }
    
    
}
