//
//  HFHomeViewController.swift
//  HFWYYProject
//
//  Created by Chen on 2021/3/3.
//  Copyright © 2021 CH. All rights reserved.
//

import UIKit
import DNSPageView


class HFHomeViewController: UIViewController {

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.navigationController?.setNavigationBarHidden(true, animated: false)
        
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
 
        // 单独设置 titleView 的 frame
        self.view.addSubview(pageViewManger.titleView)
        pageViewManger.titleView.frame = CGRect(x: 0, y:50, width: HFFMScreen_Width - 40, height: 50)
        // 单独设置 contentView 的大小和位置，可以使用 autolayout 或者 frame
        let contentView = pageViewManger.contentView
        view.addSubview(pageViewManger.contentView)
 
        contentView.snp.makeConstraints { (maker) in
            maker.top.equalTo(pageViewManger.titleView.snp_bottom).offset(10)
             maker.leading.trailing.bottom.equalToSuperview()
        }

        self.view.addSubview(moreChannleButton)
        moreChannleButton.snp.makeConstraints { (make ) in
            make.right.equalTo(self.view.snp_right).offset(-10)
            make.centerY.equalTo(pageViewManger.titleView.snp_centerY)
            make.size.equalTo(CGSize(width: 50, height: 40))
        }
 
    }
    
    lazy var pageViewManger: PageViewManager = {
        let style = PageStyle()
        style.isShowBottomLine = true
        style.bottomLineColor = HFFMThemeColor
        style.bottomLineWidth = 30
        style.bottomLineHeight = 4
        style.titleSelectedColor = HFFMThemeColor
        style.isTitleScaleEnabled = true
        style.titleFont = UIFont.systemFont(ofSize: 15)
        style.titleMaximumScaleFactor = 1.0
        style.titleSelectedFont = UIFont.boldSystemFont(ofSize: 17)
        
        let titles =  ["推荐","VIP","小说","儿童","直播"]
        
        let VCArray = [HFHomeRecommedVC(), HFHomeVIPVC(), HFHomeStoryVC() ,HFHomeChildViewController(), HFHomeLiveVC()]
        
        for (index , vc) in  VCArray.enumerated(){
            addChild(vc)
        }

        return PageViewManager(style: style, titles: titles, childViewControllers: children)
    }()
    
 
    lazy var moreChannleButton: UIButton = {
        let button = UIButton.init(type: .custom)
        button.setImage(UIImage(named: "channleMore_ImafeName"), for: .normal)
        button.imageView?.contentMode = .scaleAspectFit
        button.backgroundColor = .white
        button.addTarget(self, action: #selector(moreChannleButtonClick), for: .touchUpInside)
        return button
    }()
    
    @objc func moreChannleButtonClick(){
        let channelVC  = HFFMChannelViewController()
        self.navigationController?.pushViewController(channelVC, animated: true)
    }
}
