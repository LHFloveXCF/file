//
//  HFFMHomeStoryViewModel.swift
//  HFWYYProject
//
//  Created by Chen on 2021/3/26.
//  Copyright © 2021 CH. All rights reserved.
//

import UIKit
import SwiftyJSON
import HandyJSON

class HFFMHomeStoryViewModel: NSObject {

    var homeStoryListModel : [HFFMHomeStroyCategoryListModel]?
    
    var moduleStoryListModel : [HFFMHomeStoryModuleModel]?
    
 
    typealias updataCallBackBlock = () -> Void
}

extension HFFMHomeStoryViewModel {
    
    func getHomeStorylistData(updataBlock : @escaping updataCallBackBlock)  {
        
        let  path  = Bundle.main.path(forResource: "HFFMHomeStory", ofType: "json")
        //获得json文件里面的内容,NSData格式
        let jsonData = NSData(contentsOfFile: path!)
        //解析书库
        let json = JSON(jsonData!)
        if   let mappObject = JSONDeserializer<HFFMHomeStoryModel>.deserializeFrom(json: json.description) {
            self.homeStoryListModel = mappObject.categoryContents?.list
            
            for (_ , model ) in self.homeStoryListModel!.enumerated() {
                switch model.moduleType {
                case  48 , 5 , 55 , 3 :
                    self.moduleStoryListModel = model.list
                    break
                case 30 :
                    break
                case 43:
                    self.moduleStoryListModel = model.list
                    break
                case 17 :
                    self.moduleStoryListModel = model.list
                case 22:
                    self.moduleStoryListModel = model.list
                    break
                default:
                    break
                }
            }
            updataBlock()
        }

    }
    
    
}


extension HFFMHomeStoryViewModel {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.homeStoryListModel?.count ?? 0
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat{
        let model = self.homeStoryListModel![indexPath.row]
        switch model.moduleType {
        case  30:
            return  80
        case  48 , 5 , 55 , 3:
            return   380 + 10
        case 43 :
            return 250 + 10
        case 17 :
            return 150
        case 22:
            return 40 + 70 * 3 + 30 + 20
        default:
            return 380 + 10
        }
    }
    
    
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell{
        
        let model = self.homeStoryListModel![indexPath.row]
        switch model.moduleType {
        case  30:
            let cell = tableView.dequeueReusableCell(withIdentifier: "StoryKeyWordCell", for: indexPath) as!HFFMStoryKeyWordTableViewCell
            return cell
        case 48 , 5 , 55 , 3 :
            let cell = tableView.dequeueReusableCell(withIdentifier: "HFFMModuleTypeTableViewCell", for: indexPath) as! HFFMModuleTypeTableViewCell
            cell.model = model
            return cell
        case 43:
            let cell = tableView.dequeueReusableCell(withIdentifier: "HotMovieModuleTableViewCell", for: indexPath) as! HFFMHotMovieModuleTableViewCell
            cell.model = model
            return cell
        case 17 :
            let cell  = tableView.dequeueReusableCell(withIdentifier: "YunYingCardTableViewCell", for: indexPath) as!HFFMHomeYunYingCardTableViewCell
            cell.model = model
            return cell
        case 22:
            let cell = tableView.dequeueReusableCell(withIdentifier: "SoaringRankCell", for: indexPath) as! HFFMHomeSoaringRankTableViewCell
            cell.model = model
            return cell
        default:
            return UITableViewCell()
        }
    }
}
