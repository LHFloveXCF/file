//
//  HFHomeStoryVC.swift
//  HFWYYProject
//
//  Created by Chen on 2021/3/9.
//  Copyright © 2021 CH. All rights reserved.
//

import UIKit

class HFHomeStoryVC: UIViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.view.backgroundColor = UIColor.colorWithHexString("#ECECEC")
        self.view.addSubview(storyTableView)
       
        addStoryRefrsh()
        
    }
    
    
    func addStoryRefrsh() {
        storyTableView.initRefreshView()
        storyTableView.mj_header?.refreshingBlock = { [weak self] in
            self?.getStoryDataModel()
        }
        storyTableView.mj_header?.beginRefreshing()
    }
    
    func  getStoryDataModel()  {
        
        viewModel.getHomeStorylistData {
            self.storyTableView.mj_header?.endRefreshing()
            self.storyTableView.reloadData()
        }
    }
    
    lazy var storyTableView: UITableView = {
        let tableView = UITableView.init(frame: CGRect(x: 0, y: 10, width: HFFMScreen_Width, height: HFFMScreen_Height - 120 ), style: .plain)
        tableView.delegate = self
        tableView.dataSource = self
        tableView.backgroundColor = .clear
        tableView.separatorStyle = .none
        tableView.register(HFFMStoryKeyWordTableViewCell.self, forCellReuseIdentifier: "StoryKeyWordCell")
        tableView.register(HFFMModuleTypeTableViewCell.self, forCellReuseIdentifier: "HFFMModuleTypeTableViewCell")
        tableView.register(HFFMHotMovieModuleTableViewCell.self, forCellReuseIdentifier: "HotMovieModuleTableViewCell")
        tableView.register(HFFMHomeYunYingCardTableViewCell.self, forCellReuseIdentifier: "YunYingCardTableViewCell")
        tableView.register(HFFMHomeSoaringRankTableViewCell.self, forCellReuseIdentifier: "SoaringRankCell")
        return tableView
    }()
    
    lazy var viewModel: HFFMHomeStoryViewModel = {
        return HFFMHomeStoryViewModel()
    }()
    
}


extension HFHomeStoryVC: UITableViewDelegate{
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return viewModel.tableView(tableView, heightForRowAt: indexPath)
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
         
    }
}

extension HFHomeStoryVC: UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return viewModel.tableView(tableView, numberOfRowsInSection: section)
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        return viewModel.tableView(tableView, cellForRowAt: indexPath)
    }
    
    
}

