//
//  HFFMHomeStoryHeaderView.swift
//  HFWYYProject
//
//  Created by Chen on 2021/3/25.
//  Copyright © 2021 CH. All rights reserved.
//

import UIKit

class HFFMHomeStoryHeaderView: UIView {
    override init(frame: CGRect) {
        super.init(frame: frame)
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    

}
