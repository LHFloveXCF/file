//
//  HFFMHotMovieModuleTableViewCell.swift
//  HFWYYProject
//
//  Created by Chen on 2021/3/26.
//  Copyright © 2021 CH. All rights reserved.
//

import UIKit
import KingfisherWebP

//热播影视
class HFFMHotMovieModuleTableViewCell: UITableViewCell {
    let item_width :  CGFloat  = (HFFMScreen_Width - 10 * 6) / 3
    
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        //设置Cell的圆角 边距
        self.backgroundColor = .white
        self.layer.cornerRadius = 8
        self.layer.masksToBounds = true
        
        
        self.addSubview(topCoverImageView)
        self.addSubview(topTitleLabel)
        self.addSubview(subTitleLabel)
        self.addSubview(mainCollectionView)
    }
    
    
    var model : HFFMHomeStroyCategoryListModel? {
        didSet{
            guard model != nil else {
                return
            }
            self.topTitleLabel.text = model?.title
            self.subTitleLabel.text = model?.recData
            
            let topModel  = model?.list![0]
            
            self.topCoverImageView.kf.setImage(with: URL(string:(topModel?.coverPathBig)!), placeholder: nil, options: [.processor(WebPProcessor.default),.cacheSerializer(WebPSerializer.default)], progressBlock: nil) { (result) in
            }
            
            self.topCoverImageView.addCorner(conrners: [.topLeft , .topRight], radius: 8)
        }
    }
    
    
    override func layoutSubviews() {
        super.layoutSubviews()
        topCoverImageView.snp.makeConstraints { (make) in
            make.left.top.right.equalTo(self).offset(0)
            make.height.equalTo(250 / 2)
        }
        topTitleLabel.snp.makeConstraints { (make ) in
            make.left.equalTo(topCoverImageView).offset(15)
            make.top.equalTo(topCoverImageView.snp_top).offset(20)
            make.height.equalTo(18)
        }
        subTitleLabel.snp.makeConstraints { (make ) in
            make.left.equalTo(topCoverImageView).offset(15)
            make.top.equalTo(topTitleLabel.snp_bottom).offset(10)
            make.height.equalTo(15)
        }
        mainCollectionView.snp.makeConstraints { (make ) in
            make.left.equalTo(self).offset(10)
            make.top.equalTo(subTitleLabel.snp_bottom).offset(15)
            make.right.equalTo(self.snp_right).offset(-10)
            make.height.equalTo(item_width + 50)
        }
        
    }
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    lazy var topCoverImageView: UIImageView = {
        let imageView = UIImageView()
        imageView.backgroundColor = .randomColor()
        return imageView
    }()
    lazy var mainCollectionView: UICollectionView = {
        let flowlayout = UICollectionViewFlowLayout()
        flowlayout.itemSize = CGSize(width: item_width, height: item_width + 50)
        flowlayout.minimumInteritemSpacing = 10
        flowlayout.sectionInset = UIEdgeInsets(top: 10, left: 0, bottom: 10, right: 0)
        
        let collectionView = UICollectionView.init(frame: .zero, collectionViewLayout: flowlayout)
        collectionView.register(HFFMHotMovieCollectionViewCell.self, forCellWithReuseIdentifier: "HFFMHotMovieCollectionViewCell")
        collectionView.delegate = self
        collectionView.dataSource = self
        collectionView.backgroundColor = .clear
        collectionView.isScrollEnabled = false
        return collectionView
    }()
    lazy var topTitleLabel: UILabel = {
        let label = UILabel.init(titleString: "热播影视 原著小说", textColorString: "#ffffff", fontNumber: 18, textAlignments: .left, numberLines: 1)
        label.font = UIFont.boldSystemFont(ofSize: 18)
        return label
    }()
    lazy var subTitleLabel: UILabel = {
        let label = UILabel.init(titleString: "点击查看更多", textColorString: "#ffffff", fontNumber: 12, textAlignments: .left, numberLines: 1)
        return label
    }()
    
    override var frame: CGRect{
        didSet{
            var newFrame = frame
            newFrame.origin.x += 10
            newFrame.size.height -= 10
            newFrame.size.width -= 10 * 2
            super.frame = newFrame
        }
    }
}

extension HFFMHotMovieModuleTableViewCell: UICollectionViewDelegate{
    
}

extension HFFMHotMovieModuleTableViewCell: UICollectionViewDataSource{
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        let topModel  = model?.list![0]
        return (topModel?.albums!.count)!
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "HFFMHotMovieCollectionViewCell", for: indexPath) as! HFFMHotMovieCollectionViewCell
        let topModel  = model?.list![0]
        cell.model = topModel?.albums![indexPath.row]
        return cell
    }
    
}





class HFFMHotMovieCollectionViewCell: UICollectionViewCell {
    override init(frame: CGRect) {
        super.init(frame: frame)
        self.addSubview(coverImageView)
        self.addSubview(contentLabel)
    }
    
    var model : HFFMHomeVipAblumsModel? {
        didSet{
            guard model != nil else {
                return
            }
            self.coverImageView.kf.setImage(with: URL(string:(model?.albumCoverUrl290)!), placeholder: nil, options: [.processor(WebPProcessor.default),.cacheSerializer(WebPSerializer.default)], progressBlock: nil) { (result) in
            }
            self.contentLabel.text = model?.title
        }
    }
    
    
    override func layoutSubviews() {
        super.layoutSubviews()
        let item_width :  CGFloat  = (HFFMScreen_Width - 10 * 6) / 3
        coverImageView.snp.makeConstraints { (make ) in
            make.centerX.equalTo(self.snp.centerX)
            make.size.equalTo(CGSize(width: item_width, height: item_width))
        }
        contentLabel.snp.makeConstraints { (make ) in
            make.top.equalTo(coverImageView.snp_bottom).offset(10)
            make.left.right.equalTo(coverImageView).offset(0)
        }
    }
    
    lazy var coverImageView: UIImageView = {
        let imageView = UIImageView()
        imageView.layer.cornerRadius = 5
        imageView.layer.masksToBounds = true
        imageView.backgroundColor = .red
        return imageView
    }()
    lazy var contentLabel: UILabel = {
        let label = UILabel.init(titleString: "半妖司藤 | 景甜、张彬彬.......", textColorString: "#2B2C2D", fontNumber: 13, textAlignments: .left, numberLines: 2)
        return label
    }()
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
}
