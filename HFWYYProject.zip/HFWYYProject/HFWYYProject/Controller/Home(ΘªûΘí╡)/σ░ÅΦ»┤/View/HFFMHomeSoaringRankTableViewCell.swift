//
//  HFFMHomeSoaringRankTableViewCell.swift
//  HFWYYProject
//
//  Created by Chen on 2021/3/26.
//  Copyright © 2021 CH. All rights reserved.
//

import UIKit
import KingfisherWebP

//飙升榜单
class HFFMHomeSoaringRankTableViewCell: UITableViewCell {
    
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier   )
        
        self.selectionStyle = .none
        
        //设置Cell的圆角 边距
        self.backgroundColor = .white
        self.layer.cornerRadius = 8
        self.layer.masksToBounds = true
        
        
        self.addSubview(mainCollectionView)
        mainCollectionView.snp.makeConstraints { (make ) in
            make.left.right.equalToSuperview()
            make.top.equalTo(self).offset(0)
            make.height.equalTo(40 + 70 * 3 + 30)
        }
    }
    
    
    var  model  : HFFMHomeStroyCategoryListModel? {
        didSet{
            guard model != nil else {
                 return
            }
            self.mainCollectionView.reloadData()
        }
    }
    
    
    
    lazy var mainCollectionView : UICollectionView = {
        let flowLayout = UICollectionViewFlowLayout()
        flowLayout.itemSize = CGSize(width: HFFMScreen_Width - 60, height: 40 + 70 * 3 + 30)
        flowLayout.scrollDirection = .horizontal
        flowLayout.minimumInteritemSpacing = 30
        
        let collectionView = UICollectionView.init(frame: .zero, collectionViewLayout: flowLayout)
        collectionView.register(HFFMHomeSoaringRankCollectionCell.self, forCellWithReuseIdentifier: "SoaringRankCollectionCell")
        collectionView.delegate = self
        collectionView.dataSource = self
        collectionView.backgroundColor = .white
        return collectionView
    }()
    override var frame: CGRect{
        didSet{
            var newFrame = frame
            newFrame.origin.x += 10
            newFrame.size.height -= 10
            newFrame.size.width -= 2 * 10
            super.frame = newFrame
        }
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
}


extension HFFMHomeSoaringRankTableViewCell: UICollectionViewDelegate {
    
}

extension HFFMHomeSoaringRankTableViewCell: UICollectionViewDataSource{
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return (self.model?.list!.count)!
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "SoaringRankCollectionCell", for: indexPath) as! HFFMHomeSoaringRankCollectionCell
        let model = self.model?.list![indexPath.row]
        cell.model = model
        return cell
    }
}




class HFFMHomeSoaringRankCollectionCell: UICollectionViewCell  {
    override init(frame: CGRect) {
        super.init(frame: frame)
        //设置Cell的圆角 边距
        
        self.backgroundColor = .white
        self.layer.shadowColor = UIColor.colorWithHexString("#B5B5B5").cgColor
        self.layer.shadowOpacity = 1.0
        self.layer.shadowOffset = CGSize(width: 0, height: 0)
        self.layer.shadowRadius = 8
        self.layer.masksToBounds = false
        self.layer.cornerRadius = 8
        
        self.addSubview(topView)
        self.addSubview(mainTableView)
      
    }
    
    var model : HFFMHomeStoryModuleModel?{
        didSet{
            guard model != nil else {
                 return
            }
            self.topView.titleLabel.text = model?.title
            self.mainTableView.reloadData()
        }
    }
    
    override func layoutSubviews() {
        super.layoutSubviews()
        topView.snp.makeConstraints { (make ) in
            make.left.top.equalTo(self).offset(0)
            make.width.equalTo(HFFMScreen_Width - 60)
            make.height.equalTo(50)
        }
        mainTableView.snp.makeConstraints { (make) in
            make.top.equalTo(topView.snp_bottom).offset(0)
            make.left.bottom.equalTo(self).offset(0)
            make.width.equalTo(HFFMScreen_Width - 60)
        }
    }
    lazy var topView : HFHomeVipGuessLikeTopView = {
        let view  = HFHomeVipGuessLikeTopView.init()
        view.subTitleLabel.isHidden  = true
        view.titleLabel.textColor = UIColor.colorWithHexString("#292929")
        return view
    }()
    
    lazy var mainTableView: UITableView = {
        let tableView = UITableView.init(frame:self.bounds, style: .plain)
        tableView.delegate = self
        tableView.dataSource = self
        tableView.separatorStyle = .none
        tableView.showsVerticalScrollIndicator = false
        tableView.isScrollEnabled = false
        tableView.register(HFFMHomeSoaringRankSubTableViewCell.self, forCellReuseIdentifier: "SoaringRankSubCell")
        return tableView
    }()
    override var frame: CGRect{
        didSet{
            var  newFrame = frame
            newFrame.origin.x += 10
            newFrame.size.height -= 10
            newFrame.size.width -= 2 * 30
            super.frame = newFrame
        }
    }
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    
    
}


extension HFFMHomeSoaringRankCollectionCell: UITableViewDelegate {
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 70 + 10
    }
}
extension HFFMHomeSoaringRankCollectionCell: UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 3
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "SoaringRankSubCell", for: indexPath) as!HFFMHomeSoaringRankSubTableViewCell
        cell.model = self.model?.list![indexPath.row]
        cell.indexRow = indexPath.row
        return cell
    }
    
}




class HFFMHomeSoaringRankSubTableViewCell: UITableViewCell {
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        
        //设置Cell的圆角 边距
        self.backgroundColor = UIColor.colorWithHexString("#F0F1F2")
        self.layer.cornerRadius = 5
        self.layer.masksToBounds = true
        
        self.addSubview(coverLeftImageView)
        self.addSubview(topNumberLabel)
        self.addSubview(titleLabel)
        self.addSubview(subTitleLabel)
        self.addSubview(listenNumberButton)
        
    }
    var indexRow : Int? {
        didSet{
            if indexRow == 0 {
                self.topNumberLabel.backgroundColor = UIColor.colorWithHexString("#9D262C")
            }else if indexRow == 1 {
                self.topNumberLabel.backgroundColor = UIColor.colorWithHexString("#BF4728")
            }else{
                self.topNumberLabel.backgroundColor = UIColor.colorWithHexString("#B4782F")
            }
        }
    }
    
    var model  : HFFMHomeStoryModuleModel? {
        didSet{
            guard model != nil else {
                 return
            }
           coverLeftImageView.kf.setImage(with: URL(string:(model?.coverLarge)!), placeholder: nil, options: [.processor(WebPProcessor.default),.cacheSerializer(WebPSerializer.default)], progressBlock: nil) { (result) in
           }
            titleLabel.text = model?.albumTitle
            subTitleLabel.text = model?.intro
        }
    }
    
    
    override func layoutSubviews() {
        super.layoutSubviews()
        
        coverLeftImageView.snp.makeConstraints { (make ) in
            make.left.top.equalTo(self).offset(0)
            make.size.equalTo(CGSize(width: 70, height: 70))
        }
        topNumberLabel.snp.makeConstraints { (make ) in
            make.top.equalTo(coverLeftImageView.snp_top).offset(3)
            make.left.equalTo(coverLeftImageView.snp_right).offset(5)
            make.size.equalTo((CGSize(width: 35, height: 15)))
        }
        
        titleLabel.snp.makeConstraints { (make) in
            make.left.equalTo(coverLeftImageView.snp_right).offset(5)
            make.top.equalTo(topNumberLabel.snp_bottom).offset(3)
            make.right.equalTo(self.snp_right).offset(-20)
        }
        subTitleLabel.snp.makeConstraints { (make) in
            make.left.equalTo(coverLeftImageView.snp_right).offset(5)
            make.top.equalTo(titleLabel.snp_bottom).offset(3)
            make.right.equalTo(self.snp_right).offset(-20)
        }
        listenNumberButton.snp.makeConstraints { (make ) in
            make.left.equalTo(coverLeftImageView.snp_right).offset(5)
            make.top.equalTo(subTitleLabel.snp_bottom).offset(3)
            make.size.equalTo(CGSize(width: 60, height: 15))
        }
    }
    
    lazy var coverLeftImageView: UIImageView = {
        let imageView = UIImageView()
        imageView.backgroundColor = .randomColor()
        return imageView
    }()
    
    lazy var topNumberLabel: UILabel = {
        let label = UILabel.init(titleString: "TOP 1", textColorString: "#FFFFFF", fontNumber: 10, textAlignments: .center, numberLines: 1)
        label.backgroundColor = .randomColor()
        label.layer.cornerRadius = 2
        label.layer.masksToBounds = true
        label.font = UIFont.italicSystemFont(ofSize: 10)
        return label
    }()
    
    lazy var titleLabel: UILabel = {
        let label = UILabel.init(titleString: "都是奇门医圣", textColorString: "#000000", fontNumber: 13, textAlignments: .left, numberLines: 1)
        return label
    }()
    
    lazy var subTitleLabel: UILabel = {
        let label = UILabel.init(titleString: "诸天神佛天,不过一剑间", textColorString: "#7B7C7D", fontNumber: 11, textAlignments: .left, numberLines: 1)
        return label
    }()
    
    lazy var listenNumberButton: UIButton = {
        let button = UIButton.init(type: .custom)
        button.setImage(UIImage(named: "listen_imageName"), for: .normal)
        button.setTitle("12.3亿", for: .normal)
        button.imagePosition(style: .left, spacing: 2)
        button.setTitleColor(UIColor.colorWithHexString("#CECFD0"), for: .normal)
        button.titleLabel?.font = UIFont.systemFont(ofSize: 10)
        button.contentHorizontalAlignment = .left
        return button
    }()
    
    override var frame: CGRect{
        didSet{
            var  newFrame = frame
            newFrame.origin.x += 10
            newFrame.size.height -= 10
            newFrame.size.width -= 2 * 10
            super.frame = newFrame
        }
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
}
