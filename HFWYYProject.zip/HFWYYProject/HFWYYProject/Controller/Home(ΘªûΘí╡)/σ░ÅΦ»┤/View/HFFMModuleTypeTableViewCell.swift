//
//  HFFMModuleTypeTableViewCell.swift
//  HFWYYProject
//
//  Created by Chen on 2021/3/26.
//  Copyright © 2021 CH. All rights reserved.
//

import UIKit

class HFFMModuleTypeTableViewCell: UITableViewCell {
    
    let item_width :  CGFloat  = (HFFMScreen_Width - 10 * 6) / 3
    
    
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        
        self.selectionStyle = .none
        
        //设置Cell的圆角 边距
        self.backgroundColor = .white
        self.layer.cornerRadius = 8
        self.layer.masksToBounds = true
        
        contentView.addSubview(topView)
        contentView.addSubview(guessLikeCollectionView)
        
    }
    
    
    
    var model :  HFFMHomeStroyCategoryListModel? {
        didSet{
            guard model != nil else {
                return
            }
            self.topView.titleLabel.text = model?.title
//            model?.list
            self.guessLikeCollectionView.reloadData()
        }
    }
    
    
    override func layoutSubviews() {
        super.layoutSubviews()
        topView.snp.makeConstraints { (make ) in
            make.left.right.equalTo(self)
            make.top.equalTo(self).offset(10)
            make.height.equalTo(30)
        }
        
        guessLikeCollectionView.addCorner(conrners: [.bottomLeft , .bottomRight], radius: 8)
        guessLikeCollectionView.snp.makeConstraints { (make ) in
            make.left.bottom.right.equalTo(self).offset(0)
            make.top.equalTo(topView.snp_bottom).offset(0)
         }
    }
    
    lazy var topView : HFHomeVipGuessLikeTopView = {
        let view  = HFHomeVipGuessLikeTopView.init()
        view.subTitleLabel.isHidden  = true
        view.titleLabel.textColor = UIColor.colorWithHexString("#292929")
        return view
    }()
    lazy var guessLikeCollectionView: UICollectionView = {
        let flowlayout = UICollectionViewFlowLayout()
        flowlayout.itemSize = CGSize(width: item_width, height: item_width + 40)
        flowlayout.minimumInteritemSpacing = 10
        flowlayout.sectionInset = UIEdgeInsets(top: 10, left: 10, bottom: 10, right: 10)
        
        let collectionView = UICollectionView.init(frame: .zero, collectionViewLayout: flowlayout)
        collectionView.register(HFFMHomeModuleTypeCollectionViewCell.self, forCellWithReuseIdentifier: "ModuleTypeCollectionViewCell")
        collectionView.delegate = self
        collectionView.dataSource = self
        collectionView.backgroundColor = .white
        return collectionView
    }()
    override var frame: CGRect{
        didSet{
            var newFrame = frame
            newFrame.origin.x += 10
            newFrame.size.height -= 10
            newFrame.size.width -= 2 * 10
            super.frame = newFrame
        }
    }
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
}


extension  HFFMModuleTypeTableViewCell: UICollectionViewDelegate{
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        print("index ==\(indexPath.row)")
        let detailVC = HFFMProgramListViewController()
        self.customViewController()?.navigationController?.pushViewController(detailVC, animated: true)
    }
}


extension  HFFMModuleTypeTableViewCell: UICollectionViewDataSource{
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return self.model!.list!.count
    }
 
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "ModuleTypeCollectionViewCell", for: indexPath) as! HFFMHomeModuleTypeCollectionViewCell
        cell.model = self.model?.list![indexPath.row]
        return cell
    }
    
}


