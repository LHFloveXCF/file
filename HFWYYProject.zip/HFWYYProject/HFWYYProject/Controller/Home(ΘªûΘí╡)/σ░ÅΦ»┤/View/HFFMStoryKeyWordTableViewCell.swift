//
//  HFFMStoryKeyWordTableViewCell.swift
//  HFWYYProject
//
//  Created by Chen on 2021/3/26.
//  Copyright © 2021 CH. All rights reserved.
//

import UIKit

class HFFMStoryKeyWordTableViewCell: UITableViewCell {

    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        self.backgroundColor = .randomColor()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}
