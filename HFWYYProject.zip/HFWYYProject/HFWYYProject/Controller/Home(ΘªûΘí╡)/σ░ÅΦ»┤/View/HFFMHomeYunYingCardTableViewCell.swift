//
//  HFFMHomeYunYingCardTableViewCell.swift
//  HFWYYProject
//
//  Created by Chen on 2021/3/26.
//  Copyright © 2021 CH. All rights reserved.
//

import UIKit
//import KingfisherWebP
import Kingfisher
class HFFMHomeYunYingCardTableViewCell: UITableViewCell {

    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        
        //设置Cell的圆角 边距
        self.backgroundColor = .white
        self.layer.cornerRadius = 8
        self.layer.masksToBounds = true
        
        self.addSubview(coverLeftImageView)
        self.addSubview(coverRightImageView)
    }
    
    var model : HFFMHomeStroyCategoryListModel?{
        didSet{
            guard model != nil  else {
                return
            }
            let leftImage = model?.list![0]
            let rightImage = model?.list![1]
            self.coverLeftImageView.kf.setImage(with:  URL(string: (leftImage?.coverPath)!))
            self.coverRightImageView.kf.setImage(with:  URL(string: (rightImage?.coverPath)!))
            self.coverRightImageView.addCorner(conrners: [.topRight , .bottomRight], radius: 8)
            self.coverLeftImageView.addCorner(conrners: [.topLeft , .bottomLeft], radius: 8)

        }
 
    }
    
    override func layoutSubviews() {
        super.layoutSubviews()
        coverLeftImageView.snp.makeConstraints { (make ) in
            make.left.top.equalTo(self).offset(0)
            make.size.equalTo(CGSize(width: HFFMScreen_Width - 150, height: 140))
        }
        coverRightImageView.snp.makeConstraints { (make ) in
            make.right.top.equalTo(self).offset(0)
            make.height.equalTo(140)
            make.left.equalTo(coverLeftImageView.snp_right)
        }
    }
    
    lazy var coverLeftImageView: UIImageView = {
         let imageView = UIImageView()
         return imageView
     }()
     
    
    lazy var coverRightImageView: UIImageView = {
         let imageView = UIImageView()
         return imageView
     }()
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override var frame: CGRect{
        didSet{
            var newFrame = frame
            newFrame.origin.x += 10
            newFrame.size.height -= 10
            newFrame.size.width -= 10 * 2
            super.frame = newFrame
        }
    }
}
