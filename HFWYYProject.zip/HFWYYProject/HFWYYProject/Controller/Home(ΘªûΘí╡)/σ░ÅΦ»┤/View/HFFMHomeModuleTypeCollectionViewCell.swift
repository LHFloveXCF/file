//
//  HFFMHomeModuleTypeCollectionViewCell.swift
//  HFWYYProject
//
//  Created by Chen on 2021/3/26.
//  Copyright © 2021 CH. All rights reserved.
//

import UIKit
import KingfisherWebP

class HFFMHomeModuleTypeCollectionViewCell: UICollectionViewCell {
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        
        self.addSubview(coverImageView)
        self.addSubview(playCountButton)
        self.addSubview(isFinishLabel)
        self.addSubview(subTtileLabel)
        
    }
    
    var model : HFFMHomeStoryModuleModel? {
        didSet{
            guard model != nil else {
                return
            }
            self.coverImageView.kf.setImage(with: URL(string: (model?.coverMiddle!)!), placeholder: nil, options: [.processor(WebPProcessor.default),.cacheSerializer(WebPSerializer.default)], progressBlock: nil) { (result) in
            }
            self.subTtileLabel.text = model?.title
            let playCountNumber = "456789"
            let  playCountNumbers =   playCountNumber.roundUpReleaseZeroWithValue(doubleValue: model!.playsCounts , scale: 1, decimalStyle: false)
            playCountButton.setTitle("\(playCountNumbers)万", for: .normal)
        }
    }
    
    
    
    override func layoutSubviews() {
        super.layoutSubviews()
        let item_width :  CGFloat  = (HFFMScreen_Width - 10 * 5) / 3
        
        coverImageView.snp.makeConstraints{
            $0.centerX.equalTo(self.snp.centerX)
            $0.size.equalTo(CGSize(width:item_width, height: item_width))
        }
        playCountButton.snp.makeConstraints { (make) in
            make.left.equalTo(coverImageView.snp_left).offset(3)
            make.bottom.equalTo(coverImageView.snp_bottom).offset(-5)
            make.right.equalTo(coverImageView.snp_right).offset(-20)
            make.height.equalTo(15)
        }
        subTtileLabel.snp.makeConstraints { (make) in
            make.left.equalTo(coverImageView).offset(3)
            make.top.equalTo(coverImageView.snp_bottom).offset(8)
            make.right.equalTo(coverImageView.snp_right).offset(-3)
        }
        
    }
    lazy var coverImageView: UIImageView = {
        let imageView = UIImageView()
        imageView.layer.cornerRadius = 5
        imageView.layer.masksToBounds = true
        imageView.backgroundColor = .red
        return imageView
    }()
    
    lazy var playCountButton: UIButton = {
        let button = UIButton.init(type: .custom)
        button.setImage(UIImage(named: "playImageName"), for: .normal)
        button.setTitle("36.5万", for: .normal)
        button.titleLabel?.font = UIFont.systemFont(ofSize: 12)
        button.imageView?.contentMode = .scaleAspectFit
        button.imagePosition(style: .left, spacing: 5)
        button.contentHorizontalAlignment = .left
        return button
    }()
    
    lazy var isFinishLabel: UILabel = {
        let label = UILabel.init(titleString: "完结", textColorString: "#CDAA7D", fontNumber: 12, textAlignments: .center, numberLines: 1)
        label.layer.borderColor = UIColor.colorWithHexString("#CDAA7D").cgColor
        label.layer.borderWidth = 0.5
        label.layer.cornerRadius = 1
        label.layer.masksToBounds = true
        return label
    }()
    
    lazy var subTtileLabel: UILabel = {
        let label = UILabel.init(titleString: "中国成语故事集", textColorString: "#939495", fontNumber: 12, textAlignments: .left, numberLines: 2)
        return label
    }()
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    
}
