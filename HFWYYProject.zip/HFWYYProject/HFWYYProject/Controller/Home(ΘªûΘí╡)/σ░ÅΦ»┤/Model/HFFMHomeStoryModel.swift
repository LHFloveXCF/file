//
//  HFFMHomeStoryModel.swift
//  HFWYYProject
//
//  Created by Chen on 2021/3/26.
//  Copyright © 2021 CH. All rights reserved.
//

import Foundation
import HandyJSON


struct HFFMHomeStoryModel : HandyJSON{
    var msg : String?
    var showModules : String?
    var ret : Int = 0
    var serverMilliseconds : Int = 0
    var focusImages : HFFMHomeStoryFocusImagesDataModel?
    var keywords : [HFFMHomeStoryKeywordsModel]?
    var categoryContents : HFFMHomeStoryCategoryContentsModel?
    
    
}
//MARK: 小说界面的轮播图
struct HFFMHomeStoryFocusImagesDataModel : HandyJSON{
    var responseId : Int = 0
    var ret : Int = 0
    var data  : [HFFMHomeStoryFocusImagesModel]?
}

struct HFFMHomeStoryFocusImagesModel : HandyJSON {
    var adBucketIds : String?
    var adId : Int = 0
    var adType : Int = 0
    var buttonShowed  : Bool = false
    var clickAction : Int = 0
    var clickTokenEnable  : Bool = false

    var clickType : Int = 0
    var cover : String?
    var displayType : Int = 0
    var dpRealLink : String?
    var isAd : Bool = false
    var isInternal : Int = 0
    var isLandScape : Bool = false
    var isShareFlag : Bool = false
    var isTrueExposure : Bool = false
    var link : String?
    var linkType : Int = 0
    var openlinkType : Int = 0
    var realLink : String?
    var recSrc : String?
    var recTrack : String?
    var showTokenEnable : Bool = false
    var targetId : Int = 0
}

//MARK: 关键词model
struct HFFMHomeStoryKeywordsModel:HandyJSON {
    var categoryId : Int = 0
    var keywordId : Int = 0
    var realCategoryId : Int = 0
    var keywordType : Int = 0
    var keywordName : String?
}

//MARK:  contentsModel


struct HFFMHomeStoryCategoryContentsModel : HandyJSON {
    var ret : Int = 0
    var title : String?
    var list : [HFFMHomeStroyCategoryListModel]?
}
struct HFFMHomeStroyCategoryListModel : HandyJSON {
    var calcDimension : String?
    
    var cardClass  : String?
    var categoryId :Int = 0
    var channelId  : Int = 0
    var coverPath : String?
    var deadLine :Int = 0
    var displayCount : Int = 0
    var hasMore : Bool = false
    var hasMoreIting :String?
    var loopCount : Int = 0
    var minorProtectOpen : Bool = false
    var moduleId : Int = 0
    var moduleType : Int = 0
    var musicSongList : Bool = false
    var offset : Int = 0
    var skinColor : String?
    var skinUrl : String?
    var title : String?
    var recData : String?
    var wordColor : Int = 0
    var list : [HFFMHomeStoryModuleModel]?
    
}


struct HFFMHomeStoryModuleModel: HandyJSON {
    var ageLevel : Int = 0
    var albumCoverUrl290 : String?
    var albumId : Int = 0
    var albumSubscript : String?
    var albumTitle : String?
    var albumType : Int = 0
    var categoryId : Int = 0
    var commentsCount : Int = 0
    var contractStatus : Int = 0
    var coverLarge : String?
    var coverMiddle : String?
    var coverSmall : String?
    var createdAt : Int = 0
    var customTitle : String?
    var discountedPrice : Int = 0
    var displayDiscountedPrice : String?
    var displayPrice : String?
    var draft :Bool = false
    var id : Int = 0
    var intro : String?
    var isFinished : Int = 0
    var isPaid : Bool = false
    var isSampleAlbumTimeLimited : Bool = false
    var isVipFree : Bool = false
    var lastUptrackAt : Int = 0
    var lastUptrackId : Int = 0
    var lastUptrackTitle : String?
    var materialType : String?
    var nickname : String?
    var originalCoverPath : String?
    var playsCounts : Double = 0
    var preferredType : Int = 0
    var price : Int = 0
    var priceTypeEnum : Int = 0
    var priceTypeId : Int = 0
    var priceUnit : String?
    var provider : String?
    var refundSupportType : Int = 0
    var sampleAlbumExpireTime : Int = 0
    var score : Int = 0
    var serialState : Int = 0
    var subscribesCounts : Int = 0
    var tags : String?
    var title : String?
    var trackId : Int = 0
    var tracks : Int = 0
    var type : Int = 0
    var uid : Int = 0
    var vipFree : Bool = false
    var vipFreeType : Int = 0
    var coverPath :String?
    
    
    
    var contentType : Int = 0
    var coverPathBig :String?
    var footnote :String?
    var personalSignature :String?
    var smallLogo :String?
    var specialId :String?

    var albums : [HFFMHomeVipAblumsModel]?
    var list : [HFFMHomeStoryModuleModel]?
    
    
}


struct HFFMHomeVipAblumsModel: HandyJSON {
    var albumCoverUrl290 : String?
    var albumId : Int = 0
    var commentsCount : Int = 0
    var contractStatus : Int = 0
    var coverLarge : String?
    var coverMiddle : String?
    var coverSmall : String?
    var discountedPrice : Int = 0

    var displayDiscountedPrice : String?
    var displayPrice : String?
    var id : Int = 0
    var intro : String?
    var isDraft : Bool = false
    var isFinished : Int = 0
    var isPaid : Bool = false
    var isSample : Bool = false
    var isSampleAlbumTimeLimited : Bool = false
    var isVipFree : Bool = false
    var lastUptrackAt : Int = 0
    var materialType : String?
    var nickName :String?
    var origin : HFFMHomeVipAblumsOriginModel?
    
    var playsCounts : Int = 0
    var price : Int = 0
    var priceTypeEnum : Int = 0
    var priceTypeId : Int = 0
    var priceUnit :String?
    var serialState : Int = 0
    var subscribeStatus : Bool = false
    var title : String?
    var tracksCounts : Int = 0
    var uid  : Int = 0
    var vipFreeType : Int = 0
}

struct HFFMHomeVipAblumsOriginModel : HandyJSON {
    var albumCoverUrl290 : String?
    var title : String?
}
