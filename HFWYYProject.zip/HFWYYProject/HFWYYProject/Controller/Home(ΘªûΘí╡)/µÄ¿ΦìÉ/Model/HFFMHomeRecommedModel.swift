//
//  HFFMHomeRecommedModel.swift
//  HFWYYProject
//
//  Created by Chen on 2021/3/9.
//  Copyright © 2021 CH. All rights reserved.
//

import UIKit
import HandyJSON

struct HFHomeRecommedModel: HandyJSON {
    var msg: String?
    var ret: Int = 0
    var code: Int = 0
    var isNewUser : Bool = false
    var profileId : Int = 0
    var body : [HFHomeRecommedBodyModel]?
    var header:[HFHomeRecommedHeaderModel]?
    var bucketId: Int = 0
    
    var offset : Int = 0
    
    
}

struct HFHomeRecommedBodyModel: HandyJSON {
    var itemType : String?
    var item :HFHomeRecommedBodyItemModel?
    
}
struct HFHomeRecommedBodyItemModel: HandyJSON {
    var albumId  : Int = 0
    var albumScore : Int = 0
    var albumIntro : String?
    var albumSubscript :String?
    
    var category: String?
    var categoryId: Int = 0
    var commentScore :Int = 0
    var commentsCount : Int = 0
    var contractStatus : Int = 0
    var discountedPrice : Int = 0
    var displayDiscountedPrice : String?
    var displayPrice: String?
    
    
    var categoryTag : String?
    var albumCoverUrl290 : String?
    var refundSupportType : String?
    
    
    
    var coverLarge :String?
    var coverMiddle :String?
    var coverPath :String?
    var coverSmall :String?
    var createdAt : Int = 0
    var isFinished : Int = 0
    var isFollowing : Bool = false
    var isVipFree: Bool = false
    var vipFree : Bool = false
    
    
    
    var firstTrackId:Int = 0
    var firstTrackTitle: String?
    var infoType: String?
    var intro: String?
    var isPaid: Bool = false
    var isSampleAlbumTimeLimited: Bool = false
    var lastUptrackAt : Int = 0
    var lastUptrackTitle:String?
    var nickname:String?  
    var playsCounts : Int = 0
    var preferredType : Int = 0
    var serialState: Int = 0
    var subscribeStatus : Bool = false
    var title :String?
    var tracks: Int = 0
    var tracksCount : Int = 0
    var trackTitle: String?
    var trackId : Int = 0
    
    var provider: String?
    
    
    
    var type : Int = 0
    var uid : Int = 0
    var recInfo:HFRecommendRecInfoModel?
    var pic: String?
    var price: Int = 0
    var priceTypeEnum : Int = 0
    var priceUnit : String?
    var subtitle :String?
    var recReason :String?
    
    
    var dislikeReasons : [HFHomeDislikeReasonsModel]?
    var dislikeReasonNew : HFHomeDislikeReasonNewModel?
    
    
}
struct HFHomeDislikeReasonNewModel: HandyJSON {
    var defaultomdel: [HFHomeDislikeDefaultModel]?
    var traits :[HFHomeDislikeTraitsModel]?
}
struct HFHomeDislikeDefaultModel : HandyJSON{
    var codeType: String?
    var name: String?
    
}
struct HFHomeDislikeTraitsModel: HandyJSON{
    var codeType: String?
    var name: String?
}
struct HFHomeDislikeReasonsModel: HandyJSON {
    var name: String?
    var value: String?
}

struct HFRecommendRecInfoModel: HandyJSON {
    var recIconType: Int = 0
    var recReason :String?
    var recReasonType :String?
    var recSrc :String?
    var recTrack :String?
}

 
//MARK: headerModel
struct HFHomeRecommedHeaderModel: HandyJSON {
    var itemType :String?
    var item : HFHomeRecommedHeaderItemModel?
}

struct HFHomeRecommedHeaderItemModel: HandyJSON {
    var displayStyle: String?
    var loopCount: Int = 0
    var moduleType: String?
    var showInterestCard: Bool = false
    var title: String?
    
}


struct HFHomeRecommendHeaderItemListModel : HandyJSON {
    var bubbleText: String?
    var bucketId : Int = 0
    var contentType :String?
    var contentUpdatedAt :String?
    var coverPath   : String?
    var darkCoverPath:String?
    var displayClass :String?
    var enableShare : Bool = false
    var id : Int = 0
    var isExternalUrl : Bool = false
    var orderNum : Bool = false
    var subtitle :String?
    var url :String?
    var title : String?
    var properties : HFRecommendPropertiesModel?
}

struct HFRecommendPropertiesModel: HandyJSON {
    var isPaid: Bool = false
    var type : String?
    var url : String?
    
}

//MARK: 今天推荐
struct HFRecommendTodayListModel :  HandyJSON {
    var abtest: Int = 0
    var categoryId : Int = 0
    var contentType : Int = 0
    var id: Int = 0
    var specialType : String?
    var title : String?
    var url: String?
    var coverPathList:[String]?
    var extData : HFRecommendTodayExDataModel?
}

struct HFRecommendTodayExDataModel : HandyJSON {
    var paomaTitle : String?
    var display_style: String?
    var topList : [HFRecommendTodayTopListModel]?
}

struct HFRecommendTodayTopListModel: HandyJSON {
    var coverPath : String?
    var title: String?
    var url  :String?
}



//更多猜你喜欢
struct HFHomeMoreGuessLikeModel : HandyJSON {
    var msg : String?
    var totalCount : Int = 0
    var hasInterest : Bool = false
    var title :String?
    var hasMore : Bool = false
    var ret  : Int = 0
    var list : [HFHomeRecommedBodyItemModel]?
}
