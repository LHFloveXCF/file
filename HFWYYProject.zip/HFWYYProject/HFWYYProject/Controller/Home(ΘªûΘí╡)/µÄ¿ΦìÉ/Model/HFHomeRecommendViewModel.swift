//
//  HFHomeRecommendViewModel.swift
//  HFWYYProject
//
//  Created by Chen on 2021/3/9.
//  Copyright © 2021 CH. All rights reserved.
//

import UIKit
import HandyJSON
import SwiftyJSON


class  HFHomeRecommendViewModel: NSObject {
     
    var recommendModel: HFHomeRecommedModel?
    var homeRecommendHeaderList : [HFHomeRecommedHeaderModel]?
    
    //排行榜
    var homeRecommendSquareListModel :[HFHomeRecommendHeaderItemListModel]?
    
    //今日推荐
    var homeTodayRecommendListModel :[HFRecommendTodayListModel]?
    
    //猜你喜欢
    var homeGuessLikeListModel :[HFHomeRecommedBodyItemModel]?
    
    var homeRecommendBodyModel :HFHomeRecommedBodyItemModel?
    
    //更多猜你喜欢
    var homeMoreGuessLikeListModel :  [HFHomeRecommedBodyItemModel]? = []
    
    
    // Mark: -数据源更新
    typealias AddDataBlock = () ->Void
    var updataBlock:AddDataBlock?

    
}

extension HFHomeRecommendViewModel {
    
    func getHomeRecommendData() {
        //获得json的文件路径
        let  path  = Bundle.main.path(forResource: "HFFMHomeRecommed", ofType: "json")
        //获得json文件里面的内容,NSData格式
        let jsonData = NSData(contentsOfFile: path!)
        //解析书库
        let json = JSON(jsonData!)
        if  let mappedObject = JSONDeserializer<HFHomeRecommedModel>.deserializeFrom(json: json.description) {
            self.recommendModel = mappedObject
            self.homeRecommendHeaderList = mappedObject.header
           
            for (index , element) in self.homeRecommendHeaderList!.enumerated() {
                //排行榜
                if element.item!.moduleType == "square" {
                    if let squareList = JSONDeserializer<HFHomeRecommendHeaderItemListModel>.deserializeModelArrayFrom(json: json["header"][index]["item"]["list"].description) {
                         self.homeRecommendSquareListModel = (squareList as! [HFHomeRecommendHeaderItemListModel])
                    }

                }
                //今日推荐
                if element.item!.moduleType == "todayRecommend" {
                    if let todayModel = JSONDeserializer<HFRecommendTodayListModel>.deserializeModelArrayFrom(json: json["header"][1]["item"]["list"].description){
                        self.homeTodayRecommendListModel = (todayModel as! [HFRecommendTodayListModel])
                    }
                }
                
                //列表
                if element.itemType == "ALBUM" {
                    if let bodyModel = JSONDeserializer<HFHomeRecommedBodyItemModel>.deserializeFrom(json: json["header"][index]["item"].description) {
                        self.homeRecommendBodyModel = bodyModel
                    }
                }
                if element.item?.moduleType == "guessYouLike" {
                    if let guessLikeModel = JSONDeserializer<HFHomeRecommedBodyItemModel>.deserializeModelArrayFrom(json: json["header"][index]["item"]["list"].description) {
                        self.homeGuessLikeListModel = (guessLikeModel as! [HFHomeRecommedBodyItemModel])                         
                    }
                }
            }
            
             self.updataBlock?()
        }
    }
    
    
    func getHomeMoreGuessLike(pageNumber : Int , updateBlock:@escaping AddDataBlock) {
        HFRecommendProvider.request(.guessLikeMoreList(pageNumber)) { (result) in
            if  case let .success(respone) =  result{
                //j解析数据
                let data = try? respone.mapJSON()
                let json = JSON(data!)
                print("获取更多猜你喜欢 ==\(json)")
                        
                if let mappObject = JSONDeserializer<HFHomeMoreGuessLikeModel>.deserializeFrom(json: json.description) {
                    
                    if pageNumber == 1 {
                        self.homeMoreGuessLikeListModel = mappObject.list
                    }else{
                        self.homeMoreGuessLikeListModel! += mappObject.list!
                    }
//                    print("个数 == \(self.homeMoreGuessLikeListModel?.count)")
                    updateBlock()
                }
            }
        }
    }
}


extension HFHomeRecommendViewModel {
    // 每个分区显示item数量
    func numberOfSections(in tableView: UITableView) -> Int {
        return self.homeRecommendHeaderList?.count ?? 0
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 1
    }
    
    func sizeForIndexPathRow(indexPathSection : IndexPath) -> CGFloat {
        let moduleType = self.homeRecommendHeaderList![indexPathSection.section].item?.moduleType
        if moduleType == "square" {
            return 120
        }else if moduleType == "todayRecommend"{
            return 180
        }else if moduleType == "guessYouLike"{
            return 180
        }
        return 120
    }
    
}

extension HFHomeRecommendViewModel {
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        let model = self.homeMoreGuessLikeListModel![indexPath.row]
        let  item_width = (HFFMScreen_Width - 20 * 3) / 2
        let string_height : CGFloat = (model.recReason!.heightWithConstrainedWidth(width: item_width - 16, font: UIFont.systemFont(ofSize: 15)))
        let item_height : CGFloat = item_width / 3 + 20 + 5 + string_height + 8 + 15 + 10 + 20 + 10

        return CGSize(width: item_width, height: item_height)
    }
}
