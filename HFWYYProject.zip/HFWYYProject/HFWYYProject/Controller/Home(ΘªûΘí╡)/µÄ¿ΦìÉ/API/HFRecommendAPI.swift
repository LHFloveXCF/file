//
//  HFRecommendAPI.swift
//  HFWYYProject
//
//  Created by Chen on 2021/3/22.
//  Copyright © 2021 CH. All rights reserved.
//

import Foundation
import Moya
import SwiftyJSON
import HandyJSON

let  HFRecommendProvider = MoyaProvider<HFRecommendAPI>()


enum HFRecommendAPI {
    case  guessLikeMoreList(Int)
}

extension  HFRecommendAPI : TargetType{
    var baseURL: URL {
        return  URL(string: "https://mobile.ximalaya.com")!
    }
    
    var path: String {
        return "/discovery-firstpage/guessYouLike/list/ts-1616403895908"
    }
    
    var method: Moya.Method {
        return .get
    }
    
    var sampleData: Data {
        return  "".data(using: String.Encoding.utf8)!
    }
    
    var task: Task {
          var parmeters:[String:Any] = [:]
        switch self {
        case .guessLikeMoreList(let index):
            parmeters = ["appid":"0",
                         "device":"iPhone",
                         "deviceId":"5AC6CCBA-21C6-47C7-9971-B75C6B257988",
                         "inreview":"false",
                         "network":"WIFI",
                         "operator":"3",
                         "pageId":index,
                         "pageSize":"20",
                         "sacle":"2",
                         "uid":"148102319",
                         "version":"7.3.18",
                         "xt":"1616403895909"]
        default:
            parmeters = [ : ]
        }
        return .requestParameters(parameters: parmeters, encoding: URLEncoding.default)
    }
    
    var headers: [String : String]? {
        return nil
    }
    
    
}
