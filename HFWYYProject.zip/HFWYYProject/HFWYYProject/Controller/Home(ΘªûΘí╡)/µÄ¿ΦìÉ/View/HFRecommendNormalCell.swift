//
//  HFRecommendNormalCell.swift
//  HFWYYProject
//
//  Created by Chen on 2021/3/12.
//  Copyright © 2021 CH. All rights reserved.
//

import UIKit
import KingfisherWebP

class HFRecommendNormalCell: UITableViewCell {
    
    weak var delegate : HFRecommendNormalCellDelegate?
    
    var selectedIndexSection: Int = 0
    
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        
        self.selectionStyle = .none
        
        contentView.addSubview(coverImageView)
        contentView.addSubview(titleLabel)
        contentView.addSubview(playCountButton)
        contentView.addSubview(subTitleLabel)
        contentView.addSubview(colorBgView)
        contentView.addSubview(recReasonLabel)
        contentView.addSubview(moreButton)
    }
    
    override func layoutSubviews() {
        super.layoutSubviews()
        
        coverImageView.snp.makeConstraints { (make) in
            make.left.top.equalTo(self).offset(20)
            make.size.equalTo(CGSize(width: 80, height: 80))
        }
        
        titleLabel.snp.makeConstraints { (make ) in
            make.top.equalTo(coverImageView.snp_top)
            make.left.equalTo(coverImageView.snp_right).offset(15)
            make.right.equalTo(self.snp_right).offset(-40)
            make.height.equalTo(16)
        }
        
        playCountButton.snp.makeConstraints { (make ) in
            make.top.equalTo(titleLabel.snp_bottom).offset(20)
            make.left.equalTo(coverImageView.snp_right).offset(15)
            make.size.equalTo(CGSize(width: 50, height: 15))
        }
        
        subTitleLabel.snp.makeConstraints { (make ) in
            make.left.equalTo(playCountButton.snp_right).offset(3)
            make.centerY.equalTo(playCountButton.snp_centerY)
            make.right.equalTo(titleLabel.snp_right)
            make.height.equalTo(15)
        }
        
        colorBgView.snp.makeConstraints { (make ) in
            make.left.equalTo(coverImageView.snp_right).offset(15)
            make.bottom.equalTo(coverImageView.snp_bottom)
            make.size.equalTo(CGSize(width: 150, height: 20))
        }
        
        recReasonLabel.snp.makeConstraints { (make) in
            make.centerY.equalTo(colorBgView.snp_centerY)
            make.centerX.equalTo(colorBgView.snp_centerX)
            make.height.equalTo(15)
        }
        moreButton.snp.makeConstraints { (make ) in
            make.centerY.equalTo(self.snp_centerY)
            make.right.equalTo(self.snp_right).offset(-20)
            make.size.equalTo(CGSize(width: 20, height: 50))
        }
    }
    
    lazy var coverImageView: UIImageView = {
        let imageView = UIImageView.init()
        imageView.layer.cornerRadius = 5
        imageView.layer.masksToBounds = true
        imageView.backgroundColor = .red
        return imageView
    }()
    
    lazy var titleLabel : UILabel = {
        let label = UILabel.init()
        label.text = "超级女婿"
        label.font = UIFont.boldSystemFont(ofSize: 16)
        return label
    }()
    
    lazy var playCountButton : UIButton = {
        let button = UIButton.init(type: .custom)
        button.setImage(UIImage(named: "playImageName"), for: .normal)
        button.setTitle("5.3亿", for: .normal)
        button.titleLabel?.font = UIFont.systemFont(ofSize: 13)
        button.imageView?.contentMode = .scaleAspectFit
        button.imagePosition(style: .left, spacing: 5)
        button.setTitleColor(UIColor.colorWithHexString("#8F8F8F"), for: .normal)
        return button
    }()
    
    lazy var subTitleLabel : UILabel = {
        let label = UILabel.init(titleString: "播放量最高", textColorString: "#8F8F8F", fontNumber: 14, textAlignments: .left, numberLines: 0)
        return label
    }()
    
    lazy var colorBgView: UIView = {
        let view = UIView()
        view.backgroundColor = UIColor.colorWithHexString("#FFD39B")
        view.layer.cornerRadius = 3
        view.layer.masksToBounds = true
        return view
    }()
    
    lazy var recReasonLabel: UILabel = {
        let label = UILabel.init(titleString: "NO.1音乐 热播榜", textColorString: "#FF8C00", fontNumber: 12, textAlignments: .left, numberLines: 0)
        return label
    }()
    lazy var moreButton : UIButton = {
        let button = UIButton.init(type: .custom)
        button.setImage(UIImage(named: "more_imageName"), for: .normal)
        button.imageView?.contentMode = .scaleAspectFill
        button.addTarget(self, action: #selector(moreButtonCLick), for: .touchUpInside)
        return button
    }()
    
    @objc func moreButtonCLick(){
        
        if self.delegate != nil && ((self.delegate?.responds(to: Selector.init(("showReasonView")))) != nil) {
            self.delegate?.showReasonView(section: self.selectedIndexSection)
        }        
    }
    
    var   normalModel : HFHomeRecommedBodyItemModel? {
        didSet{
            guard let model = normalModel else {
                return
            }
            self.titleLabel.text = model.title
            self.subTitleLabel.text = "| \(model.firstTrackTitle!)"
            self.recReasonLabel.text = model.recInfo!.recReason
            self.coverImageView.kf.setImage(with: URL(string: model.coverLarge!), placeholder: nil, options: [.processor(WebPProcessor.default),.cacheSerializer(WebPSerializer.default)], progressBlock: nil) { (result) in
        }

    }
}
 
    
    
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
        
}


protocol HFRecommendNormalCellDelegate: NSObjectProtocol {
    func showReasonView(section: Int)
}
