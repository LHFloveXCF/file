//
//  HFFMShowReasonView.swift
//  HFWYYProject
//
//  Created by Chen on 2021/3/12.
//  Copyright © 2021 CH. All rights reserved.
//

import UIKit

enum ShowReasonViewStyle {
    case normal
    case advert
    
}

class HFFMShowReasonView: UIView {
    
    weak var delegate : ShowReasonClickDelegate?
    
    var selectedIndexSection : Int = 0
    
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        
        //设置背景色
        self.backgroundColor = UIColor.black.withAlphaComponent(0.3)
        
        self.showNormalView(array: [""])
        
        self.addSubview(cancelButton)
        self.cancelButton.snp.makeConstraints { (make ) in
            make.left.bottom.right.equalTo(self).offset(0)
            make.height.equalTo(60)
        }
    }
    func initializeSubViews(style: ShowReasonViewStyle) {
        
    }
    
    
    func showNormalView(array : [String]) {
        let images = ["addSong","xiangsiImageName","faceBookImageName","shieldImageName","NoLike"]
        let titles = ["添加到听单","找相似","反馈问题","屏蔽","不感兴趣"]
        
        for (index ,  _ )in images.enumerated() {
            let  button   = UIButton.init(type: .custom)
            button.backgroundColor = .white
            button.isUserInteractionEnabled = true
            button.addTarget(self, action: #selector(buttonClick(btn:)), for: .touchUpInside)
            self.addSubview(button)
            button.tag = images.count - 1 - index;
            
            button.snp.makeConstraints { (make ) in
                make.left.equalTo(self).offset(0)
                make.bottom.equalTo(self.snp_bottom).offset(-(60  + ( 50 + 1) * index))
                make.size.equalTo(CGSize(width: HFFMScreen_Width, height: 50))
            }
            
            
            let leftButton = UIButton.init(type: .custom)
            leftButton.setTitle(titles[index], for: .normal)
            if index == 4 {
                 leftButton.setTitleColor(HFFMThemeColor, for: .normal)
            }else{
                leftButton.setTitleColor(.darkGray, for: .normal)
            }
            leftButton.setImage(UIImage(named: images[index]), for: .normal)
            leftButton.imagePosition(style: .left, spacing: 20)
            leftButton.titleLabel?.font = UIFont.systemFont(ofSize: 15)
            leftButton.contentHorizontalAlignment = .left
            button.addSubview(leftButton)
            leftButton.snp.makeConstraints { (make ) in
                make.left.equalTo(20)
                make.centerY.equalTo(button.snp_centerY)
                make.size.equalTo(CGSize(width: HFFMScreen_Width / 2, height: 50))
            }
        
            let rightLabel =  UILabel.init(titleString: "将减少这类内容出现", textColorString: "#CDC5BF", fontNumber: 13, textAlignments: .right, numberLines: 1)
            button.addSubview(rightLabel)
            rightLabel.snp.makeConstraints { (make) in
                make.right.equalTo(button.snp_right).offset(-20)
                make.centerY.equalTo(button.snp_centerY)
                make.height.equalTo(50)
            }
            
            
            let  lineView = UIView.init()
            lineView.backgroundColor = UIColor.colorWithHexString("#D6D6D6")
            self.addSubview(lineView)
            lineView.snp.makeConstraints { (make ) in
                make.left.equalTo(self).offset(20)
                make.top.equalTo(button.snp_bottom).offset(0.5)
                make.size.equalTo(CGSize(width: HFFMScreen_Width - 20, height: 0.5))
            }
        }
    }
    
    lazy var cancelButton : UIButton = {
        let button = UIButton.init(type: .custom)
        button.setTitle("取消", for: .normal)
        button.titleLabel?.font = UIFont.systemFont(ofSize: 15)
        button.setTitleColor(.black, for: .normal)
        button.backgroundColor = .white
        button.addTarget(self, action: #selector(cancelButtonClick), for: .touchUpInside)
        return button
    }()
    
    @objc func cancelButtonClick(){
        self.removeFromSuperview()
    }
    
    @objc func buttonClick(btn: UIButton){
        
        print("tag ==\(btn.tag)")
        
        if self.delegate != nil && ((self.delegate?.responds(to: Selector.init(("ShowReasonClickWithTag")))) != nil) {
            self.delegate?.ShowReasonClickWithTag(tag: btn.tag , section: self.selectedIndexSection)
        }
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}

protocol ShowReasonClickDelegate: NSObjectProtocol {
    func ShowReasonClickWithTag(tag: Int , section: Int)
}

