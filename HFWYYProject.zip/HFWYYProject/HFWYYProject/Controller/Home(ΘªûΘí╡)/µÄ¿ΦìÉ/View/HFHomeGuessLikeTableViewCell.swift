//
//  HFHomeGuessLikeTableViewCell.swift
//  HFWYYProject
//
//  Created by Chen on 2021/3/9.
//  Copyright © 2021 CH. All rights reserved.
//

import UIKit

class HFHomeGuessLikeTableViewCell: UITableViewCell {
    
    var guessLikeListModel :[HFHomeRecommedBodyItemModel]?{
        didSet{
            guard guessLikeListModel != nil else {
                return
            }
            self.guessLikeCollectionView.reloadData()
        }
    }
    

    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier )
        
        
        self.addSubview(guessLikeCollectionView)
        self.guessLikeCollectionView.backgroundColor = .white
        
        
        guessLikeCollectionView.snp.makeConstraints { (make ) in
            make.left.right.equalToSuperview()
            make.top.equalTo(self).offset(0)
            make.height.equalTo(180)
        }
        
    }
    
    
    lazy var guessLikeCollectionView: UICollectionView = {
        let flowlayout = UICollectionViewFlowLayout()
        let item_width :  CGFloat  = (HFFMScreen_Width - 10 * 6) / 3
        flowlayout.itemSize = CGSize(width: item_width, height: item_width + 30)
        flowlayout.sectionInset = UIEdgeInsets(top: 0, left: 10, bottom: 10, right: 10)
        flowlayout.scrollDirection = .horizontal
        flowlayout.minimumInteritemSpacing = 10
        
        let collectionView = UICollectionView.init(frame: .zero, collectionViewLayout: flowlayout)
        collectionView.register(HFHomeGuessLikeCollectionViewCell.self, forCellWithReuseIdentifier: "guessLikeCollectionCell")
        collectionView.delegate = self
        collectionView.dataSource = self
        return collectionView
    }()
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
}


extension HFHomeGuessLikeTableViewCell  :  UICollectionViewDelegate{
    
}

extension HFHomeGuessLikeTableViewCell  :  UICollectionViewDataSource{
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return self.guessLikeListModel?.count ?? 0
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let  cell = collectionView.dequeueReusableCell(withReuseIdentifier: "guessLikeCollectionCell", for: indexPath) as! HFHomeGuessLikeCollectionViewCell
        cell.guessLikeModel = self.guessLikeListModel![indexPath.row]
        return cell
    }
}

