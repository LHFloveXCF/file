//
//  HFHomeSquareTableViewCell.swift
//  HFWYYProject
//
//  Created by Chen on 2021/3/15.
//  Copyright © 2021 CH. All rights reserved.
//

import UIKit
import KingfisherWebP

class HFHomeSquareTableViewCell: UITableViewCell {
    
    weak var delegate:HFHomeSquareModelDelegate?
    
    
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)        
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    //排行榜 、 分类 、等
    func setSubViews(dataArray : [HFHomeRecommendHeaderItemListModel]?) {
        
        for (index, model) in dataArray!.enumerated(){
            let  button  = UIButton.init(type: .custom)
            button.imagePosition(style: .top, spacing: 10)
            button.imageView?.contentMode = .scaleAspectFit
            button.kf.setImage(with: URL(string: model.coverPath!), for: .normal, placeholder: nil, options: [.processor(WebPProcessor.default),.cacheSerializer(WebPSerializer.default)], progressBlock: nil) { (result) in
            }
 
            button.setTitle(model.title!, for: .normal)
            button.setTitleColor(.red, for: .normal)
            button.titleLabel?.font = UIFont.systemFont(ofSize: 14)
            button.tag = index ;
//            button.backgroundColor = .randomColor()
            button.addTarget(self, action: #selector(buttonClick(btn:)), for: .touchUpInside)
            
            self.addSubview(button)
            let button_itemWidth = (HFFMScreen_Width - 20 * 6) / 5
            
            button.snp.makeConstraints { (make ) in
                make.left.equalTo(self).offset(20 + index * (Int(button_itemWidth) + 20))
                make.top.equalTo(self).offset(20)
                make.size.equalTo(CGSize(width: button_itemWidth, height: button_itemWidth + 20))
            }
            
        }
    }
    
    var headerList :[HFHomeRecommendHeaderItemListModel]?{
        didSet{
            guard headerList != nil else { return}
            setSubViews(dataArray: headerList)
        }
    }
    
    @objc func buttonClick(btn: UIButton){
        if self.delegate != nil && ((self.delegate?.responds(to: Selector.init(("recommendSquareButtonClick")))) != nil){
            self.delegate?.recommendSquareButtonClick(index: btn.tag)
        }
    }
    
   
}


protocol HFHomeSquareModelDelegate: NSObjectProtocol {
    func  recommendSquareButtonClick(index: Int)
}
