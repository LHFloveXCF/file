//
//  HFHomeSectionHeaderView.swift
//  HFWYYProject
//
//  Created by Chen on 2021/3/15.
//  Copyright © 2021 CH. All rights reserved.
//

import UIKit

class HFHomeSectionHeaderView: UITableViewHeaderFooterView {

    var delegate  : HFHomeSectionHeaderViewDelegate?
    
    
    override init(reuseIdentifier: String?) {
        super.init(reuseIdentifier: reuseIdentifier)
        
        contentView.backgroundColor = .white
        
        contentView.addSubview(titleLabel)
        contentView.addSubview(moreButton)
        contentView.addSubview(chooseButton)
        
    }
    
    override func layoutSubviews() {
        super.layoutSubviews()
        titleLabel.snp.makeConstraints { (make) in
            make.left.top.equalTo(self).offset(15)
            make.height.equalTo(20)
        }
        moreButton.snp.makeConstraints { (make) in
            make.right.equalTo(self.snp_right).offset(-20)
            make.centerY.equalTo(titleLabel.snp_centerY)
            make.size.equalTo(CGSize(width: 40, height: 20))
        }
        chooseButton.snp.makeConstraints { (make) in
            make.right.equalTo(moreButton.snp_left).offset(-10)
            make.centerY.equalTo(titleLabel.snp_centerY)
            make.size.equalTo(CGSize(width: 70, height: 20))
        }
    }
    
    lazy var titleLabel : UILabel = {
        let label = UILabel.init(titleString: "猜你喜欢", textColorString: "#2E2E2E", fontNumber: 18, textAlignments: .left, numberLines: 0)
        return label
    }()
    
    lazy var moreButton: UIButton = {
        let button = UIButton.init(type: .custom)
        button.setTitle("更多", for: .normal)
        button.setImage(UIImage(named: "likeMore"), for: .normal)
        button.titleLabel?.font = UIFont.systemFont(ofSize: 13)
        button.setTitleColor(UIColor.colorWithHexString("#CCCCCC"), for: .normal)
        button.imagePosition(style: .right, spacing: 8)
        button.imageView?.contentMode = .scaleAspectFit
        button.addTarget(self , action: #selector(guessLikeMoreButtonClick), for: .touchUpInside)
        return button
    }()
    
    lazy var chooseButton: UIButton = {
        let button = UIButton.init(type: .custom)
        button.setTitle("选择兴趣 |", for: .normal)
        button.titleLabel?.font = UIFont.systemFont(ofSize: 13)
        button.setTitleColor(HFFMThemeColor, for: .normal)
        button.contentHorizontalAlignment = .right
        return button
    }()
    
    @objc func  guessLikeMoreButtonClick(){
        if self.delegate != nil && ((self.delegate?.responds(to: Selector.init(("guessLikeMoreButtonClickCallBack")))) != nil) {
            self.delegate?.guessLikeMoreButtonClickCallBack()
        }
    }
    
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}


protocol HFHomeSectionHeaderViewDelegate : NSObjectProtocol  {
    func  guessLikeMoreButtonClickCallBack()
}
