//
//  HFHomeTodayRecommendTableViewCell.swift
//  HFWYYProject
//
//  Created by Chen on 2021/3/15.
//  Copyright © 2021 CH. All rights reserved.
//

import UIKit
import KingfisherWebP

class HFHomeTodayRecommendTableViewCell: UITableViewCell {
    
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier )
        self.selectionStyle = .none
        
        self.todayRecommend()
    }
    var todayRecommendList : [HFRecommendTodayListModel]?{
        didSet{
            guard todayRecommendList != nil  else {
                return
            }
            
            for (_ , model) in todayRecommendList!.enumerated() {
                if model.specialType == "daily_listening" {
                    self.everyDayListenButton.kf.setImage(with: URL(string: model.coverPathList![0]), for: .normal, placeholder: nil, options: [.processor(WebPProcessor.default),.cacheSerializer(WebPSerializer.default)], progressBlock: nil) { (result) in
                    }
                }
                if model.specialType == "today_youxuan" {
                    self.newRecommendButton.kf.setImage(with: URL(string: model.coverPathList![0]), for: .normal, placeholder: nil, options: [.processor(WebPProcessor.default),.cacheSerializer(WebPSerializer.default)], progressBlock: nil) { (result) in
                    }
                }
                
                if model.specialType == "personaFM"{
                    self.stationButton.kf.setImage(with: URL(string: model.coverPathList![0]), for: .normal, placeholder: nil, options: [.processor(WebPProcessor.default),.cacheSerializer(WebPSerializer.default)], progressBlock: nil) { (result) in
                    }
                }
            }
        }
    }
    
    func todayRecommend() {
        self.backgroundColor = .green
        self.addSubview(newRecommendButton)
        self.addSubview(everyDayListenButton)
        self.addSubview(stationButton)
        newRecommendButton.snp.makeConstraints{ (make ) in
            make.right.equalTo(self.snp_right).offset(-20);
            make.bottom.equalTo(self.snp_bottom).offset(-30)
            make.size.equalTo(CGSize(width: newRecommendButton_Width, height: 70))
        }
        stationButton.snp.makeConstraints { (make ) in
            make.right.equalTo(newRecommendButton.snp_left).offset(-10)
            make.centerY.equalTo(newRecommendButton.snp_centerY)
            make.size.equalTo(CGSize(width: newRecommendButton_Width, height: 70))
        }
        everyDayListenButton.snp.makeConstraints { (make ) in
            make.right.equalTo(self.snp_right).offset(-20)
            make.bottom.equalTo(newRecommendButton.snp_top).offset(-10)
            make.size.equalTo(CGSize(width: newRecommendButton_Width * 2.0 + 10, height:60))
        }
        
    }
    
    lazy var everyDayListenButton: UIButton = {
        let button = UIButton.init(type: .custom)
        button.backgroundColor = .randomColor()
        button.imageView?.contentMode = .scaleAspectFit
        button.layer.cornerRadius = 5
        button.layer.masksToBounds = true
        button.addTarget(self, action: #selector(everyDayListenButtonClick), for: .touchUpInside)
        return button
    }()
    
    lazy var stationButton : UIButton = {
        let button = UIButton.init(type: .custom)
        button.backgroundColor = .white
        button.imageView?.contentMode = .scaleAspectFit
        button.layer.cornerRadius = 5
        button.layer.masksToBounds = true
        button.addTarget(self, action: #selector(stationButtonButtonClick), for: .touchUpInside)
        return button
    }()
    
    lazy var newRecommendButton : UIButton = {
        let button = UIButton.init(type: .custom)
        button.backgroundColor = .white
        button.imageView?.contentMode = .scaleAspectFit
        button.layer.cornerRadius = 5
        button.layer.masksToBounds = true
        button.addTarget(self, action: #selector(newRecommendButtonClick), for: .touchUpInside)
        return button
    }()
    
    
    
    @objc func everyDayListenButtonClick(){
        
    }
    @objc func stationButtonButtonClick(){
        
    }
    @objc func newRecommendButtonClick(){
        
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}
