//
//  HFHomeGuessLikeCollectionViewCell.swift
//  HFWYYProject
//
//  Created by Chen on 2021/3/15.
//  Copyright © 2021 CH. All rights reserved.
//

import UIKit
import KingfisherWebP

class HFHomeGuessLikeCollectionViewCell: UICollectionViewCell {
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        
        self.addSubview(coverImageView)
        coverImageView.addSubview(playCountButton)
        contentView.addSubview(isFinishLabel)
        contentView.addSubview(subTtileLabel)
        
    }
    
    var guessLikeModel :HFHomeRecommedBodyItemModel?{
        didSet{
            guard let model = guessLikeModel else {
                return
            }
            if  model.isFinished != 2 {
                self.isFinishLabel.isHidden = true
            }else{
                self.isFinishLabel.isHidden = false
            }
            self.isVipGuessLike(isVip: false)
            self.subTtileLabel.text = model.title
            
            self.coverImageView.kf.setImage(with: URL(string: model.pic!), placeholder: nil, options: [.processor(WebPProcessor.default),.cacheSerializer(WebPSerializer.default)], progressBlock: nil) { (result) in
            }
        }
    }
    
    var vipGuessLikeModel : HFHomeVipGuessLikeAlbumsModel? {
        didSet{
            guard vipGuessLikeModel != nil else {
                return
            }
            self.isVipGuessLike(isVip: true)
            self.subTtileLabel.text = vipGuessLikeModel?.title
            self.coverImageView.kf.setImage(with: URL(string: (vipGuessLikeModel?.coverPath!)!), placeholder: nil, options: [.processor(WebPProcessor.default),.cacheSerializer(WebPSerializer.default)], progressBlock: nil) { (result) in
            }
        }
    }
    
    func isVipGuessLike(isVip : Bool)  {
        if isVip {
            self.isFinishLabel.isHidden  = true
            self.subTtileLabel.snp_makeConstraints { (make ) in
                make.left.right.equalTo(self.coverImageView)
                make.top.equalTo(coverImageView.snp_bottom).offset(5)
            }
        }else{
            self.isFinishLabel.snp.makeConstraints { (make ) in
                make.left.equalTo(coverImageView.snp_left)
                make.top.equalTo(coverImageView.snp_bottom).offset(5)
                make.size.equalTo(CGSize(width: 30, height: 15))
            }
            self.subTtileLabel.snp_makeConstraints { (make ) in
                make.left.equalTo(self.isFinishLabel.snp_right).offset(3)
                make.top.equalTo(self.isFinishLabel.snp_top)
                make.right.equalTo(coverImageView.snp_right).offset(-3)
            }
        }
    }
    
    override func layoutSubviews() {
        super.layoutSubviews()
        let item_width :  CGFloat  = (HFFMScreen_Width - 10 * 5) / 3
        
        self.coverImageView.snp.makeConstraints{
            $0.centerX.equalTo(self.snp.centerX)
            $0.size.equalTo(CGSize(width:item_width, height: item_width))
        }
        
        //        self.playCountButton.snp.makeConstraints { (make ) in
        //            make.left.equalTo(self.coverImageView.snp_left).offset(8)
        //            make.bottom.equalTo(self.coverImageView.snp_bottom).offset(-3)
        //        }
        //
        
        
    }
    lazy var coverImageView: UIImageView = {
        let imageView = UIImageView()
        imageView.layer.cornerRadius = 5
        imageView.layer.masksToBounds = true
        imageView.backgroundColor = .red
        return imageView
    }()
    
    lazy var playCountButton: UIButton = {
        let button = UIButton.init(type: .custom)
        button.setImage(UIImage(named: "playImageName"), for: .normal)
        button.setTitle("36.5万", for: .normal)
        button.titleLabel?.font = UIFont.systemFont(ofSize: 12)
        button.imagePosition(style: .left, spacing: 5)
        return button
    }()
    
    lazy var isFinishLabel: UILabel = {
        let label = UILabel.init(titleString: "完结", textColorString: "#CDAA7D", fontNumber: 12, textAlignments: .center, numberLines: 1)
        label.layer.borderColor = UIColor.colorWithHexString("#CDAA7D").cgColor
        label.layer.borderWidth = 0.5
        label.layer.cornerRadius = 1
        label.layer.masksToBounds = true
        return label
    }()
    
    lazy var subTtileLabel: UILabel = {
        let label = UILabel.init(titleString: "中国成语故事集", textColorString: "#6B6B6B", fontNumber: 14, textAlignments: .left, numberLines: 2)
        return label
    }()
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
}
