//
//  HFHomeRecommedVC.swift
//  HFWYYProject
//
//  Created by Chen on 2021/3/9.
//  Copyright © 2021 CH. All rights reserved.
//

import UIKit

class HFHomeRecommedVC: UIViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.view.backgroundColor = .randomColor()
        self.view.addSubview(searchView)
        searchView.snp.makeConstraints { (make ) in
            make.left.equalTo(self.view).offset(0)
            make.top.equalTo(self.view).offset(0)
            make.size.equalTo(CGSize(width: HFFMScreen_Width - 20 - 100, height: 40))
        }
        
        self.view.addSubview(historyView)
        historyView.snp.makeConstraints { (make ) in
            make.left.equalTo(searchView.snp_right).offset(10)
            make.centerY.equalTo(searchView.snp_centerY)
            make.height.equalTo(44)
            make.right.equalTo(self.view.snp_right).offset(-20)
        }
        self.view.addSubview(recommendTableView)

        recommendViewModel.updataBlock = { [unowned self] in
            self.recommendTableView.reloadData()
        }
        recommendViewModel.getHomeRecommendData()

    }
    
    
    lazy var recommendTableView: UITableView = {
        let tableView = UITableView.init(frame: CGRect(x: 0, y: 40, width: HFFMScreen_Width, height: HFFMScreen_Height  - 100 - 50), style: .plain)
        tableView.delegate = self
        tableView.dataSource = self
        tableView.register(HFHomeSquareTableViewCell.self, forCellReuseIdentifier: "squareCell")
        tableView.register(HFHomeTodayRecommendTableViewCell.self, forCellReuseIdentifier: "todayRecommend")
        tableView.register(HFHomeGuessLikeTableViewCell.self, forCellReuseIdentifier: "guessLike")
        tableView.register(HFRecommendNormalCell.self, forCellReuseIdentifier: "normalCell")
        return tableView
    }()
    lazy var recommendViewModel: HFHomeRecommendViewModel = {
        return HFHomeRecommendViewModel()
    }()
    
    lazy var showReasonInView: HFFMShowReasonView = {
        let view = HFFMShowReasonView.init(frame: UIScreen.main.bounds)
        view.delegate = self
        return view
    }()
    
    lazy var historyView: HFFMPlayAndReadView = {
        let view = HFFMPlayAndReadView()
        view.delegate = self
        return view
    }()
    lazy var searchView: HFFMSearchView = {
        let view = HFFMSearchView.init()
        return view
    }()
    
}

extension HFHomeRecommedVC : UITableViewDelegate {
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return self.recommendViewModel.sizeForIndexPathRow(indexPathSection: indexPath)
    }
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        let moduleType = recommendViewModel.homeRecommendHeaderList![section].item?.moduleType
        if moduleType == "guessYouLike"{
            let  sectionView = HFHomeSectionHeaderView.init(frame: CGRect(x: 0, y: 0, width: HFFMScreen_Width, height: 60))
            sectionView.delegate = self
            return sectionView
        }else{
            return UIView()
        }
    }
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        
        let moduleType = recommendViewModel.homeRecommendHeaderList![section].item?.moduleType
        if moduleType == "guessYouLike"{
            return 40
        }else{
            return 0
        }
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {

    }
}

extension HFHomeRecommedVC : UITableViewDataSource{
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return self.recommendViewModel.numberOfSections(in: tableView)
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.recommendViewModel.tableView(tableView, numberOfRowsInSection: section)
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let moduleType = recommendViewModel.homeRecommendHeaderList![indexPath.section].item?.moduleType
        if moduleType == "square" {
            let  cell  = tableView.dequeueReusableCell(withIdentifier: "squareCell", for: indexPath) as! HFHomeSquareTableViewCell
            cell.headerList = self.recommendViewModel.homeRecommendSquareListModel
            cell.delegate = self
            return cell
        }else if moduleType == "todayRecommend"{
            let cell = tableView.dequeueReusableCell(withIdentifier: "todayRecommend", for: indexPath) as! HFHomeTodayRecommendTableViewCell
            cell.todayRecommendList = self.recommendViewModel.homeTodayRecommendListModel
            return cell
        }else if moduleType == "guessYouLike"{
            let  cell  = tableView.dequeueReusableCell(withIdentifier: "guessLike", for: indexPath) as!HFHomeGuessLikeTableViewCell
            cell.guessLikeListModel = self.recommendViewModel.homeGuessLikeListModel
            return cell
        }else{
            let  cell  = tableView.dequeueReusableCell(withIdentifier: "normalCell", for: indexPath) as! HFRecommendNormalCell
            cell.normalModel = self.recommendViewModel.homeRecommendBodyModel
            cell.delegate = self
            cell.selectedIndexSection = indexPath.section
            return cell
        }
    }
    func tableView(_ tableView: UITableView, viewForFooterInSection section: Int) -> UIView? {
        let view = UIView.init(frame: CGRect(x: 0, y: 0, width: HFFMScreen_Width, height: 8))
        view.backgroundColor = UIColor.colorWithHexString("#EDEDED")
        return view
    }
    func tableView(_ tableView: UITableView, heightForFooterInSection section: Int) -> CGFloat {
        return 8
    }
}


extension HFHomeRecommedVC : HFRecommendNormalCellDelegate {
    func showReasonView(section: Int) {
        let delegateWindow  = UIApplication.shared.delegate as! AppDelegate
        showReasonInView.selectedIndexSection = section
        delegateWindow.window?.addSubview(showReasonInView)
    }
    
}


extension HFHomeRecommedVC : ShowReasonClickDelegate{
    func ShowReasonClickWithTag(tag: Int, section: Int) {
        if tag == 0 {
            self.showReasonInView.removeFromSuperview()
            DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + 0.2) {
                self.recommendViewModel.homeRecommendHeaderList?.remove(at: section)
                self.recommendTableView.deleteSections(IndexSet(integer: section), with: .bottom)
                self.recommendTableView.reloadData()
            }
        }else if tag == 1{
            
        }
    }
}


extension HFHomeRecommedVC :HFHomeSquareModelDelegate{
    
    func recommendSquareButtonClick(index: Int) {
        switch index {
        case 0:
            let rankListVC = HFFMRankViewController()
            self.navigationController?.pushViewController(rankListVC, animated: true)
            
        case 1:
            let channelVC = HFFMChannelViewController()
            self.navigationController?.pushViewController(channelVC, animated: true)
        default:
            break
        }
    }    
}


extension HFHomeRecommedVC :  HFHomeSectionHeaderViewDelegate{
    func guessLikeMoreButtonClickCallBack() {
        let guesslikeVC = HFGuessLikeViewController()
        self.navigationController?.pushViewController(guesslikeVC, animated: true)
    }    
}


extension HFHomeRecommedVC : HFFMPlayAndReadViewDelegate {
    func addButtonClick() {

    }

    func historyButtonClick() {
        let hostoryVC = HFPlayerHistoryContentController()
        self.navigationController?.pushViewController(hostoryVC, animated: true)
    }

}
