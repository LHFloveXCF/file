//
//  HFGuessLikeViewController.swift
//  HFWYYProject
//
//  Created by Chen on 2021/3/22.
//  Copyright © 2021 CH. All rights reserved.
//

import UIKit

class HFGuessLikeViewController: HFFMBaseViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationController?.setNavigationBarHidden(false, animated: false)
        self.view.backgroundColor = UIColor.colorWithHexString("#F0F1F2")
        self.view.addSubview(guessLikeCollectionView)
        
        weak var weakSelf = self
        viewModel.getHomeMoreGuessLike(pageNumber: 1) {
            weakSelf?.guessLikeCollectionView.reloadData()
        }
     }
    
    lazy var guessLikeCollectionView: UICollectionView = {
        let flowLayout = UICollectionViewFlowLayout()
        flowLayout.sectionInset = UIEdgeInsets(top: 15, left: 20, bottom: 15, right: 20)
        flowLayout.minimumLineSpacing = 15
        flowLayout.minimumInteritemSpacing = 20
        
        let collectionView = UICollectionView.init(frame: CGRect(x: 0, y: 0, width: HFFMScreen_Width, height: HFFMScreen_Height), collectionViewLayout: flowLayout)
        collectionView.delegate = self
        collectionView.dataSource = self
        collectionView.backgroundColor = .clear
        collectionView.register(HFHomeMoreGuessLikeCollectionViewCell.self, forCellWithReuseIdentifier: "MoreGuessLikeColl")
        return collectionView
    }()
    lazy var viewModel : HFHomeRecommendViewModel = {
        return HFHomeRecommendViewModel()
    }()

}

extension HFGuessLikeViewController : UICollectionViewDelegateFlowLayout{
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
       
        return self.viewModel.collectionView(collectionView, layout: collectionViewLayout, sizeForItemAt: indexPath)
//        return CGSize(width: item_width, height: item_height)
    }
}
extension HFGuessLikeViewController : UICollectionViewDelegate {
    
}
extension HFGuessLikeViewController : UICollectionViewDataSource {
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return self.viewModel.homeMoreGuessLikeListModel!.count
    }
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "MoreGuessLikeColl", for: indexPath) as! HFHomeMoreGuessLikeCollectionViewCell
        cell.model = self.viewModel.homeMoreGuessLikeListModel![indexPath.row]
        return cell
    }
}
