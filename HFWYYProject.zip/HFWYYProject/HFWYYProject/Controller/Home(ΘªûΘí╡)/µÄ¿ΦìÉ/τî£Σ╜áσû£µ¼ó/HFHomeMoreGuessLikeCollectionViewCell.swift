//
//  HFHomeMoreGuessLikeCollectionViewCell.swift
//  HFWYYProject
//
//  Created by Chen on 2021/3/23.
//  Copyright © 2021 CH. All rights reserved.
//

import UIKit
import KingfisherWebP
import Kingfisher

class HFHomeMoreGuessLikeCollectionViewCell: UICollectionViewCell {
    override init(frame: CGRect) {
        super.init(frame: frame)
        
        self.backgroundColor = .white
        self.layer.cornerRadius = 8
        self.layer.masksToBounds = true
        
        
        self.addSubview(coverImageView)
        self.addSubview(titleLabel)
        self.addSubview(subtitleLabel)
        self.addSubview(tracksButton)
        self.addSubview(showReasonButton)
        self.addSubview(youXuanImageView)
    }
    
    var model : HFHomeRecommedBodyItemModel? {
        didSet{
            guard model != nil else {
                 return
            }
            self.coverImageView.kf.setImage(with:  URL(string: (model?.coverMiddle)!))
 
            self.titleLabel.text = model?.title
            self.subtitleLabel.text  = model?.recReason
            self.tracksButton.setTitle("\(model!.tracks)", for: .normal)
            
        }
    }
    
    
    
    override func layoutSubviews() {
        super.layoutSubviews()
        let  item_width = (HFFMScreen_Width - 20 * 3 / 2)
        
        coverImageView.snp.makeConstraints { (make ) in
            make.left.top.equalTo(self).offset(0)
            make.size.equalTo(CGSize(width:item_width, height: item_width / 3 + 20))
        }
        
        titleLabel.snp.makeConstraints { (make ) in
            make.top.equalTo(coverImageView.snp_bottom).offset(8)
            make.left.equalTo(coverImageView.snp_left).offset(5)
            make.right.equalTo(self.snp_right).offset(-8)
        }
        
        subtitleLabel.snp.makeConstraints { (make ) in
            make.left.equalTo(coverImageView.snp_left).offset(5)
            make.top.equalTo(titleLabel.snp_bottom).offset(8)
            make.right.equalTo(self.snp_right).offset(-8)
        }
        
        tracksButton.snp.makeConstraints { (make ) in
            make.left.equalTo(coverImageView.snp_left).offset(10)
            make.top.equalTo(subtitleLabel.snp_bottom).offset(10)
            make.height.equalTo( 20)
            make.width.equalTo(70)
        }
        
    }
    
    lazy var coverImageView: UIImageView = {
        let imageView  = UIImageView()
//        imageView.backgroundColor = .red
//        imageView.contentMode = .scaleAspectFit
        return imageView
    }()
    lazy var titleLabel : UILabel = {
        let label = UILabel.init(titleString: "大力实施", textColorString: "#000000", fontNumber: 14, textAlignments: .left, numberLines: 0)
        label.font = UIFont.boldSystemFont(ofSize: 14)
        return label
    }()
    lazy var subtitleLabel : UILabel = {
        let label = UILabel.init(titleString: "根据中国历史经典传记", textColorString: "#BE9B6D", fontNumber: 12, textAlignments: .left, numberLines: 1)
        return label
    }()
    
    lazy var tracksButton: UIButton = {
        let button = UIButton.init(type: .custom)
        button.setImage(UIImage(named: "voiceImage"), for: .normal)
        button.setTitle("761", for:.normal)
        button.setTitleColor(UIColor.colorWithHexString("#A2A3A4"), for: .normal)
        button.titleLabel?.font = UIFont.systemFont(ofSize: 13)
        button.imagePosition(style: .left, spacing: 5)
        button.contentHorizontalAlignment = .left
        return button
    }()
    
    lazy var showReasonButton : UIButton = {
        let button = UIButton.init(type: .custom)
        let image = UIImage(named: "more_imageName")
        return button
    }()
    lazy var youXuanImageView: UIImageView = {
        let imageView = UIImageView()
        imageView.addCorner(conrners: [.topLeft], radius: 8)
        return imageView
    }()
        
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}
