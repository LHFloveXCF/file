//
//  HFFMChildSwitchTableViewCell.swift
//  HFWYYProject
//
//  Created by Chen on 2021/3/30.
//  Copyright © 2021 CH. All rights reserved.
//

import UIKit
import DNSPageView

class HFFMChildSwitchTableViewCell: UITableViewCell {
    
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        self.selectionStyle = .none
        
        self.backgroundColor = .white
        self.layer.cornerRadius = 8
        self.layer.masksToBounds = true
        
        self.addSubview(topView)
        topView.frame  = CGRect(x: 0, y: 0, width: HFFMScreen_Width - 20, height: 40)
        
    
       
 
        self.addSubview(pageManagerView.titleView)
        pageManagerView.titleView.frame = CGRect(x: 10, y: 40, width: HFFMScreen_Width - 40, height: 40)
        // 单独设置 contentView 的大小和位置，可以使用 autolayout 或者 frame
        let contentView = pageManagerView.contentView
        self.addSubview(pageManagerView.contentView)
        contentView.backgroundColor = .clear
        contentView.snp.makeConstraints { (maker) in
            maker.top.equalTo(pageManagerView.titleView.snp.bottom).offset(0)
            maker.leading.trailing.bottom.equalToSuperview()
        }
        
        self.addSubview(changeButton)
        changeButton.snp.makeConstraints { (make ) in
            make.left.right.equalTo(self).offset(0)
            make.bottom.equalTo(contentView.snp_bottom).offset(-5)
            make.height.equalTo(40)
        }
    }
    
    var childModel :  HFFMHomeStroyCategoryListModel?{
        didSet{
            guard childModel != nil else { return }
            
            self.topView.leftButton.setTitle(childModel?.title, for: .normal)
             
            
        }
    }
    
    lazy var pageManagerView: PageViewManager = {
        let style = PageStyle()
        style.bottomLineWidth = 30
        style.bottomLineHeight = 4
        style.titleSelectedColor = HFFMThemeColor
        style.isShowCoverView = true
        style.coverViewBackgroundColor = UIColor.colorWithHexString("#FCEBE7")
        style.isTitleScaleEnabled = true
        style.titleFont = UIFont.systemFont(ofSize: 15)
        style.titleMaximumScaleFactor = 1.0
        style.titleSelectedFont = UIFont.boldSystemFont(ofSize: 17)
        
        let titles =  ["一","今","三","四","五","六","日",]
        
        let VCArray = [HFFMSwitchContentView(), HFFMSwitchContentView(), HFFMSwitchContentView() ,HFFMSwitchContentView(), HFFMSwitchContentView(),HFFMSwitchContentView(),HFFMSwitchContentView()]
        
        return PageViewManager(style: style, titles: titles, childViewControllers: VCArray)
    }()
    
    lazy var topView : HFFMHomeSwitchTopView = {
        let view = HFFMHomeSwitchTopView()
        return view
    }()
    
    lazy var changeButton: UIButton = {
        let button = UIButton.init(type: .custom)
        button.setTitle("换一批", for: .normal)
        button.setTitleColor(UIColor.colorWithHexString("#C2C2C2"), for: .normal)
        button.titleLabel?.font = UIFont.systemFont(ofSize: 14)
        button.setImage(UIImage(named: "change_imageName"), for: .normal)
        button.imagePosition(style: .left, spacing: 10)
        //        button.addTarget(self, action: #selector(changeButtonClick), for: .touchUpInside)
        return button
    }()
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    override var frame: CGRect{
        didSet{
            var newFrame = frame
            newFrame.origin.x += 10
            newFrame.size.width -= 10 * 2
            newFrame.size.height -= 10
            super.frame = newFrame
        }
    }
}


class HFFMSwitchContentView: UIViewController {
    
    override func viewWillLayoutSubviews() {
        super.viewWillLayoutSubviews()
        self.view.frame = CGRect(x: 10, y: 0, width: HFFMScreen_Width - 40, height: 140)
    }
    override func viewDidLoad() {
        super.viewDidLoad()
         self.view.addSubview(mainCollectionView)
        mainCollectionView.frame = CGRect(x: 0, y: 0, width: HFFMScreen_Width - 40, height: 140)
        
    }
    lazy var mainCollectionView: UICollectionView = {
        let flowLayout = UICollectionViewFlowLayout()
        flowLayout.itemSize = CGSize(width: (HFFMScreen_Width - 50) / 2, height: 130)
        flowLayout.scrollDirection = .horizontal
        flowLayout.minimumInteritemSpacing = 10
 
        let collectionView = UICollectionView.init(frame: .zero, collectionViewLayout: flowLayout)
        collectionView.register(HFFMHomeEveryDayHappyCell.self, forCellWithReuseIdentifier: "EveryDayHappyCell")
        collectionView.delegate = self
        collectionView.dataSource = self
        collectionView.backgroundColor = .white
        return collectionView
    }()
}


extension HFFMSwitchContentView : UICollectionViewDelegate{
    
}

extension HFFMSwitchContentView : UICollectionViewDataSource{
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return 2
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "EveryDayHappyCell", for: indexPath) as!HFFMHomeEveryDayHappyCell
        return cell
    }
}


class HFFMHomeEveryDayHappyCell: UICollectionViewCell {
    override init(frame: CGRect) {
        super.init(frame: frame)
        self.addSubview(coverImageView)
        self.addSubview(subTtileLabel)
    }
    override func layoutSubviews() {
        super.layoutSubviews()
        coverImageView.snp.makeConstraints { (make ) in
            make.left.top.equalTo(self).offset(0)
            make.size.equalTo(CGSize(width: (HFFMScreen_Width - 50) / 2, height: 90))
        }
        subTtileLabel.snp.makeConstraints { (make ) in
            make.left.right.equalTo(coverImageView).offset(0)
            make.top.equalTo(coverImageView.snp_bottom).offset(10)
        }
    }
    lazy var coverImageView: UIImageView = {
        let imageView = UIImageView()
        imageView.layer.cornerRadius = 5
        imageView.layer.masksToBounds = true
        imageView.backgroundColor = .randomColor()
        return imageView
    }()
    lazy var subTtileLabel: UILabel = {
        let label = UILabel.init(titleString: "中国成语故事集 中国成语故事集", textColorString: "#3E3F40", fontNumber: 13, textAlignments: .left, numberLines: 2)
        return label
    }()
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}
