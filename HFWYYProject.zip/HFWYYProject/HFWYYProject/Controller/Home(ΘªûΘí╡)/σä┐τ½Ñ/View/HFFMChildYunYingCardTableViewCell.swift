//
//  HFFMChildYunYingCardTableViewCell.swift
//  HFWYYProject
//
//  Created by Chen on 2021/4/2.
//  Copyright © 2021 CH. All rights reserved.
//

import UIKit
import KingfisherWebP

class HFFMChildYunYingCardTableViewCell: UITableViewCell {

    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        self.addSubview(coverImageView)
    }
    override func layoutSubviews() {
        super.layoutSubviews()
        coverImageView.snp.makeConstraints { (make) in
            make.left.right.top.bottom.equalTo(self).offset(0)
        }
    }
    var chileModel : HFFMHomeStroyCategoryListModel?{
        didSet{
            guard chileModel != nil  else { return  }
            let model = chileModel?.list![0]
            self.coverImageView.kf.setImage(with: URL(string: (model?.coverPath)!), placeholder: nil, options:  [.processor(WebPProcessor.default),.cacheSerializer(WebPSerializer.default)], progressBlock: nil) { (result) in
            }
        }
    }
    
    lazy var coverImageView: UIImageView = {
        let imageView = UIImageView()
        imageView.layer.cornerRadius = 5
        imageView.layer.masksToBounds = true
        imageView.backgroundColor = .randomColor()
        return imageView
    }()
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    override var frame: CGRect{
        didSet{
            var newFrame = frame
            newFrame.origin.x += 10
            newFrame.size.width -= 2 * 10
            newFrame.size.height -= 10
            super.frame = newFrame
        }
    }
}
