//
//  HFFMHomeSwitchTopView.swift
//  HFWYYProject
//
//  Created by Chen on 2021/3/30.
//  Copyright © 2021 CH. All rights reserved.
//

import UIKit

class HFFMHomeSwitchTopView: UIView {

    override init(frame: CGRect) {
        super.init(frame: frame)
        self.addSubview(leftButton)
        self.addSubview(lookMoreButton)
        self.addSubview(lineView)
    }
    override func layoutSubviews() {
        super.layoutSubviews()
        leftButton.snp.makeConstraints { (make ) in
            make.left.equalTo(self).offset(15)
            make.top.equalTo(self).offset(10)
            make.size.equalTo(CGSize(width: 200, height: 20))
        }
        lookMoreButton.snp.makeConstraints { (make ) in
            make.right.equalTo(self.snp_right).offset(-15)
            make.centerY.equalTo(leftButton.snp_centerY)
            make.size.equalTo(CGSize(width:90, height: 20))
        }
        lineView.snp.makeConstraints { (make ) in
            make.left.right.equalTo(self).offset(0)
            make.bottom.equalTo(self).offset(-0.5)
            make.height.equalTo(0.5)
        }
    }
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    lazy var leftButton : UIButton = {
        let  button = UIButton.init(type: .custom)
        button.setTitle("每天精彩更新", for: .normal)
        button.setImage(UIImage(named: "calendar_imageName"), for: .normal)
        button.imagePosition(style: .left, spacing: 8)
        button.titleLabel?.font = UIFont.systemFont(ofSize: 14)
        button.setTitleColor(UIColor.colorWithHexString("#C2C2C2"), for: .normal)
        button.contentHorizontalAlignment = .left
        return button
    }()
    
    lazy var lookMoreButton: UIButton = {
        let button = UIButton.init(type: .custom)
        button.setTitle("查看全部", for: .normal)
        button.setTitleColor(UIColor.colorWithHexString("#C2C2C2"), for: .normal)
        button.titleLabel?.font = UIFont.systemFont(ofSize: 12)
        button.setImage(UIImage(named: "likeMore"), for: .normal)
        button.imagePosition(style: .right, spacing: 10)
        button.contentHorizontalAlignment = .right
        return button
    }()
    
    lazy var lineView: UIView = {
        let view = UIView.init()
        view.backgroundColor = UIColor.colorWithHexString("#C2C2C2")
        return view
    }()
}
