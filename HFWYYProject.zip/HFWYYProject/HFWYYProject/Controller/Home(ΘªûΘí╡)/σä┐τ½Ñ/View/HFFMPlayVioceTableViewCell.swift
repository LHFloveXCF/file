//
//  HFFMPlayVioceTableViewCell.swift
//  HFWYYProject
//
//  Created by Chen on 2021/3/29.
//  Copyright © 2021 CH. All rights reserved.
//

import UIKit

class HFFMPlayVioceTableViewCell: HFFMBaseTableViewCell {
    
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        
        self.selectionStyle = .none
        
        self.backgroundColor = .white
        self.layer.cornerRadius = 8
        self.layer.masksToBounds = true
        
        self.addSubview(titleLabel)
        self.addSubview(playButton)
        self.addSubview(mainTableView)
        self.addSubview(lineView)
        self.addSubview(lookMoreButton)
    }
    
    var childModel :  HFFMHomeStroyCategoryListModel?{
        didSet{
            guard childModel != nil else {    return }
            
            self.titleLabel.text = childModel?.title
 
            self.mainTableView.reloadData()
        }
    }
    
    override func layoutSubviews() {
        super.layoutSubviews()
        self.titleLabel.snp.makeConstraints { (make) in
            make.left.equalTo(self).offset(15)
            make.top.equalTo(self).offset(20)
            make.height.equalTo(20)
        }
        
        self.playButton.snp.makeConstraints { (make ) in
            make.right.equalTo(self.snp_right).offset(-15)
            make.centerY.equalTo(titleLabel.snp_centerY)
            make.size.equalTo(CGSize(width: 100, height: 30))
        }
        
        mainTableView.snp.makeConstraints { (make ) in
            make.top.equalTo(titleLabel.snp_bottom).offset(15)
            make.left.right.equalTo(self).offset(0)
            make.height.equalTo(45 * 5)
        }
        
        lineView.snp.makeConstraints { (make ) in
            make.left.right.equalTo(self).offset(0)
            make.top.equalTo(mainTableView.snp_bottom).offset(0)
            make.height.equalTo(0.5)
        }
        lookMoreButton.snp.makeConstraints { (make ) in
            make.left.right.equalTo(self).offset(0)
            make.top.equalTo(lineView.snp_bottom).offset(5)
            make.height.equalTo(30)
        }
        
    }
    lazy var titleLabel : UILabel = {
        let label = UILabel.init(titleString: "民间小故事 生活大道理", textColorString: "#000000", fontNumber: 16, textAlignments: .left, numberLines: 0)
        label.font = UIFont.boldSystemFont(ofSize: 16)
        return label
    }()
    
    lazy var playButton : UIButton = {
        let button = UIButton.init(type: .custom)
        button.setTitle("一键播放", for: .normal)
        button.setImage(UIImage(named: "playImageName"), for: .normal)
        button.imagePosition(style: .left, spacing: 3)
        button.layer.cornerRadius = 15
        button.layer.masksToBounds = true
        button.backgroundColor = HFFMThemeColor
        button.titleLabel?.font = UIFont.systemFont(ofSize: 12)
        return button
    }()
    lazy var mainTableView: UITableView = {
        let tableView = UITableView.init(frame: .zero, style: .plain)
        tableView.delegate = self
        tableView.dataSource = self
        tableView.register(HFFMPlayVioceNormalTableViewCell.self, forCellReuseIdentifier: "PlayVioceNormalCell")
        tableView.separatorStyle = .none
        return tableView
    }()
    
    lazy var lineView: UIView = {
        let view  = UIView.init()
        view.backgroundColor = UIColor.colorWithHexString("#ECECEC")
        return view
    }()
    
    lazy var lookMoreButton: UIButton = {
        let button = UIButton.init(type: .custom)
        button.setTitle("查看全部", for: .normal)
        button.setTitleColor(UIColor.colorWithHexString("#C2C2C2"), for: .normal)
        button.titleLabel?.font = UIFont.systemFont(ofSize: 14)
        button.setImage(UIImage(named: "likeMore"), for: .normal)
        button.imagePosition(style: .right, spacing: 10)
        return button
    }()
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override var frame: CGRect{
        didSet{
            var newFrame = frame
            newFrame.origin.x += 10
            newFrame.size.width -= 10 * 2
            newFrame.size.height -= 10
            super.frame = newFrame
        }
    }
    
}


extension HFFMPlayVioceTableViewCell:UITableViewDelegate {
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return  45
    }
}

extension HFFMPlayVioceTableViewCell:UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 5
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "PlayVioceNormalCell", for: indexPath) as!HFFMPlayVioceNormalTableViewCell
        return cell
    }
    
}




class  HFFMPlayVioceNormalTableViewCell:  UITableViewCell {
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        self.addSubview(leftImageView)
        self.addSubview(titleLabel)
    }
    override func layoutSubviews() {
        super.layoutSubviews()
        self.leftImageView.snp.makeConstraints { (make ) in
            make.left.equalTo(self).offset(10)
            make.centerY.equalTo(self.snp_centerY)
            make.size.equalTo(CGSize(width: 20, height: 20))
        }
        self.titleLabel.snp.makeConstraints { (make ) in
            make.left.equalTo(leftImageView.snp_right).offset(15)
            make.centerY.equalTo(self.snp_centerY)
            make.right.equalTo(self.snp_right).offset(-20)
        }
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    lazy var leftImageView: UIImageView = {
        let imageView = UIImageView.init()
        imageView.image = UIImage(named: "voice_playImage")
        imageView.contentMode = .scaleAspectFit
        return imageView
    }()
    lazy var titleLabel : UILabel = {
        let label = UILabel.init(titleString: "[民间奇幻] 山海经里最帅的战神是谁", textColorString: "#272628", fontNumber: 13, textAlignments: .left, numberLines: 1)
        return label
    }()
}

