//
//  HFFMChildRecommendCell.swift
//  HFWYYProject
//
//  Created by Chen on 2021/3/29.
//  Copyright © 2021 CH. All rights reserved.
//

import UIKit

let item_width  = (HFFMScreen_Width - 10 * 7) / 3

class HFFMChildRecommendCell: UITableViewCell {
    
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        self.backgroundColor = .clear
        
        self.addSubview(mainCollectionView)
        mainCollectionView.snp.makeConstraints { (make ) in
            make.left.bottom.right.equalTo(self).offset(0)
            make.height.equalTo(200)
        }
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    lazy var mainCollectionView: UICollectionView = {
        let flowlayout = UICollectionViewFlowLayout()
        flowlayout.itemSize = CGSize(width: item_width, height: item_width + 60)
        flowlayout.minimumInteritemSpacing = 10
        flowlayout.scrollDirection = .horizontal
        flowlayout.sectionInset = UIEdgeInsets(top: 0, left: 10, bottom: 10, right: 10)
        
        let collectionView = UICollectionView.init(frame: .zero, collectionViewLayout: flowlayout)
        collectionView.register(HFFMChildRecommendCollectionCell.self, forCellWithReuseIdentifier: "ChildRecommendCollectionCell")
        collectionView.delegate = self
        collectionView.dataSource = self
        collectionView.backgroundColor = .clear
        
        return collectionView
    }()
    
}

extension HFFMChildRecommendCell: UICollectionViewDelegate {
    
}


extension HFFMChildRecommendCell: UICollectionViewDataSource {
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return 10
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "ChildRecommendCollectionCell", for: indexPath) as! HFFMChildRecommendCollectionCell
        return cell
    }
    
}

class HFFMChildRecommendCollectionCell: UICollectionViewCell {
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        self.backgroundColor = .white
        self.addSubview(coverImageView)
        self.addSubview(subTtileLabel)
        self.addSubview(numberLabel)
    }
    
    override func layoutSubviews() {
        super.layoutSubviews()
        coverImageView.snp.makeConstraints { (make ) in
            make.left.top.right.equalTo(self).offset(0)
            make.height.equalTo(item_width)
        }
        subTtileLabel.snp.makeConstraints { (make) in
            make.left.equalTo(self).offset(5)
            make.right.equalTo(self.snp_right).offset(0)
            make.top.equalTo(coverImageView.snp_bottom).offset(5)
        }
        numberLabel.snp.makeConstraints { (make ) in
            make.left.equalTo(self).offset(5)
            make.right.equalTo(self.snp_right).offset(-5)
            make.bottom.equalTo(self.snp_bottom).offset(-10)
        }
    }
    
    lazy var coverImageView: UIImageView = {
        let imageView = UIImageView()
        imageView.layer.cornerRadius = 5
        imageView.layer.masksToBounds = true
        imageView.backgroundColor = .randomColor()
        return imageView
    }()
    lazy var subTtileLabel: UILabel = {
        let label = UILabel.init(titleString: "中国成语故事集", textColorString: "#959697", fontNumber: 13, textAlignments: .left, numberLines: 2)
        return label
    }()
    lazy var numberLabel: UILabel = {
        let label = UILabel.init(titleString: "成员: 5678", textColorString: "#68696A", fontNumber: 11, textAlignments: .left, numberLines: 1)
        return label
    }()
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
}
