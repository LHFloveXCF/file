//
//  HFHomeChildNormalTableViewCell.swift
//  HFWYYProject
//
//  Created by Chen on 2021/3/29.
//  Copyright © 2021 CH. All rights reserved.
//

import UIKit

class HFHomeChildNormalTableViewCell: UITableViewCell {
    
   let item_width :  CGFloat  = (HFFMScreen_Width - 10 * 6) / 3
    
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        
        self.selectionStyle = .none
        self.backgroundColor = .white
        self.layer.cornerRadius = 8
        self.layer.masksToBounds = true
        
        self.addSubview(topView)
        self.addSubview(guessLikeCollectionView)
        self.addSubview(changeButton)
    }
    
    
    var childModel :  HFFMHomeStroyCategoryListModel?{
        didSet{
            guard childModel != nil  else {
                return
            }
            if childModel?.hasMore == false {
                self.topView.moreButton.isHidden = true
            }else{
                self.topView.moreButton.isHidden = false
            }
            self.topView.titleLabel.text = childModel?.title
            self.guessLikeCollectionView.reloadData()
        }
    }
    
    
    override func layoutSubviews() {
        super.layoutSubviews()
        topView.snp.makeConstraints { (make ) in
            make.left.right.equalTo(self)
            make.top.equalTo(self).offset(10)
            make.height.equalTo(30)
        }
        guessLikeCollectionView.snp.makeConstraints { (make ) in
            make.left.equalTo(self).offset(10)
            make.right.equalTo(self.snp_right).offset(-10)
            make.top.equalTo(topView.snp_bottom).offset(5)
            make.bottom.equalTo(self.snp_bottom).offset(-50)
        }
        self.changeButton.snp.makeConstraints { (make ) in
            make.left.right.equalTo(self)
            make.top.equalTo(guessLikeCollectionView.snp_bottom).offset(10)
            make.height.equalTo(30)
        }
    }
    lazy var topView : HFHomeVipGuessLikeTopView = {
        let view  = HFHomeVipGuessLikeTopView.init()
        view.subTitleLabel.isHidden  = true
        view.titleLabel.textColor = UIColor.colorWithHexString("#292929")
        return view
    }()
    lazy var guessLikeCollectionView: UICollectionView = {
        let flowlayout = UICollectionViewFlowLayout()
        flowlayout.itemSize = CGSize(width: item_width, height: item_width + 40)
        flowlayout.minimumInteritemSpacing = 10
        flowlayout.sectionInset = UIEdgeInsets(top: 10, left: 0, bottom: 10, right: 0)
        
        let collectionView = UICollectionView.init(frame: .zero, collectionViewLayout: flowlayout)
        collectionView.register(HFFMHomeModuleTypeCollectionViewCell.self, forCellWithReuseIdentifier: "ModuleTypeCollectionViewCell")
        collectionView.delegate = self
        collectionView.dataSource = self
        collectionView.backgroundColor = .white
        collectionView.isScrollEnabled = false
        return collectionView
    }()
    
    override var frame: CGRect{
        didSet{
            var newFrame = frame
            newFrame.origin.x += 10
            newFrame.size.height -= 10
            newFrame.size.width -= 2 * 10
            super.frame = newFrame
        }
    }
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    lazy var changeButton: UIButton = {
        let button = UIButton.init(type: .custom)
        button.setTitle("换一批", for: .normal)
        button.setTitleColor(UIColor.colorWithHexString("#C2C2C2"), for: .normal)
        button.titleLabel?.font = UIFont.systemFont(ofSize: 14)
        button.setImage(UIImage(named: "change_imageName"), for: .normal)
        button.imagePosition(style: .left, spacing: 10)
        return button
    }()
}
extension  HFHomeChildNormalTableViewCell: UICollectionViewDelegate{
    
}


extension  HFHomeChildNormalTableViewCell: UICollectionViewDataSource{
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return self.childModel?.list?.count ?? 0
    }
 
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "ModuleTypeCollectionViewCell", for: indexPath) as! HFFMHomeModuleTypeCollectionViewCell
        cell.model = self.childModel?.list![indexPath.row]
        return cell
    }
    
    
}

