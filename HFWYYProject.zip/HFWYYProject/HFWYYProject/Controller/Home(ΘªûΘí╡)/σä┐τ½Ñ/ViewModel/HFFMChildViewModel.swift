//
//  HFFMChildVIewModel.swift
//  HFWYYProject
//
//  Created by Chen on 2021/4/2.
//  Copyright © 2021 CH. All rights reserved.
//

import UIKit
import HandyJSON
import SwiftyJSON
class HFFMChildViewModel: NSObject {
    
    let item_width :  CGFloat  = (HFFMScreen_Width - 10 * 6) / 3
    
    var childListModel : [HFFMHomeStroyCategoryListModel]?
    
    typealias updataCallBackBlock = () -> Void
}

extension  HFFMChildViewModel {
    
    func getChildDataList(updataBlock : @escaping updataCallBackBlock) {
        //获取json的路径
        let path = Bundle.main.path(forResource: "HFHomeChild", ofType: "json")
        let data = NSData(contentsOfFile: path!)
        let json = JSON(data!)
        if let mappObject = JSONDeserializer<HFFMChildModel>.deserializeFrom(json: json.description) {
            self.childListModel = mappObject.categoryContents?.list
            
            for (_ , model ) in self.childListModel!.enumerated() {
//                print("model.moduleType == \(model.moduleType)")
            }
            updataBlock()
        }
    }
    
}

extension HFFMChildViewModel {
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        let model = self.childListModel![indexPath.row]
        if model.moduleType == 19 {
            return  40 + 40 * 7  + 10
        }else if model.moduleType == 17 {
            return 150
        }else if model.moduleType == 51 {
            return 280 + 10
        }else if model.moduleType == 63 {
            return 250
        }else if model.moduleType == 5 {
            let columnNumber : CGFloat  = CGFloat(model.list!.count) / 3
            return 40 + 5 + (item_width + 50) * columnNumber + 60 + 10
        } else{
            return 0.001
        }
    }
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.childListModel?.count ?? 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell{
        let cell =  UITableViewCell()
        
        let model = self.childListModel![indexPath.row]
        if model.moduleType == 19 {
            let cell = tableView.dequeueReusableCell(withIdentifier: "PlayVioceTableViewCell", for: indexPath) as!
            HFFMPlayVioceTableViewCell
            cell.childModel = model
            return cell
            
        }else if (model.moduleType == 17){
            let cell = tableView.dequeueReusableCell(withIdentifier: "ChildYunYingCardTableViewCell", for: indexPath) as! HFFMChildYunYingCardTableViewCell
            cell.chileModel = model
            return cell
        }  else if model.moduleType == 51 {
            let cell = tableView.dequeueReusableCell(withIdentifier: "SwitchTableViewCell", for: indexPath) as! HFFMChildSwitchTableViewCell
            cell.childModel = model
            return cell
        }else if model.moduleType == 63{
            let cell = tableView.dequeueReusableCell(withIdentifier: "SwitchTableViewCell", for: indexPath) as! HFFMChildSwitchTableViewCell
            return cell
        } else if  model.moduleType == 5 {
            let cell = tableView.dequeueReusableCell(withIdentifier: "ChildNormalTableViewCell", for: indexPath) as! HFHomeChildNormalTableViewCell
            cell.childModel = model
            return cell
        }
        return cell
    }
}
