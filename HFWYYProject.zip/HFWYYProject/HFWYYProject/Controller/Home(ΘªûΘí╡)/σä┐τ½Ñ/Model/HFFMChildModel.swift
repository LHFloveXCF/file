//
//  HFFMChildModel.swift
//  HFWYYProject
//
//  Created by Chen on 2021/4/2.
//  Copyright © 2021 CH. All rights reserved.
//

import UIKit
import HandyJSON

 

struct HFFMChildModel : HandyJSON {
    var msg : String?
    var ret : Int = 0
    var showModules : String?
    var focusImages : HFFMHomeStoryFocusImagesDataModel?
    var serverMilliseconds : Int = 0
    var categoryContents : HFFMChildCategoryContentListModel?
    
    
    
}

struct  HFFMChildCategoryContentListModel : HandyJSON {
    var ret : Int = 0
    var title : String?
    var list : [HFFMHomeStroyCategoryListModel]?
}
