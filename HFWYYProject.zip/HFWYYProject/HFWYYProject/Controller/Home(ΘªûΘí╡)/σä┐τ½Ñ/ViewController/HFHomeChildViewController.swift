//
//  HFHomeChildViewController.swift
//  HFWYYProject
//
//  Created by Chen on 2021/3/29.
//  Copyright © 2021 CH. All rights reserved.
//

import UIKit

class HFHomeChildViewController: UIViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.view.backgroundColor = UIColor.colorWithHexString("#ECECEC")
        self.view.addSubview(mainTableView)
        
        viewModel.getChildDataList {
            self .mainTableView.reloadData()
        }
    }
    
    lazy var viewModel : HFFMChildViewModel = {
        return HFFMChildViewModel()
    }()
    
    
    lazy var mainTableView: UITableView = {
        let tableView = UITableView.init(frame: CGRect(x: 0, y: 0, width: HFFMScreen_Width, height: HFFMScreen_Height - 110), style: .plain)
        tableView.register(HFHomeChildNormalTableViewCell.self, forCellReuseIdentifier: "ChildNormalTableViewCell")
        tableView.register(HFFMPlayVioceTableViewCell.self, forCellReuseIdentifier: "PlayVioceTableViewCell")
        tableView.register(HFFMChildRecommendCell.self , forCellReuseIdentifier: "ChildRecommendCell")
        tableView.register(HFFMChildSwitchTableViewCell.self, forCellReuseIdentifier: "SwitchTableViewCell")
        tableView.register(HFFMChildYunYingCardTableViewCell.self, forCellReuseIdentifier: "ChildYunYingCardTableViewCell")
        tableView.delegate = self
        tableView.dataSource = self
        tableView.separatorStyle = .none
        tableView.backgroundColor = .clear
        return tableView
    }()
}

extension  HFHomeChildViewController: UITableViewDelegate {
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return self.viewModel.tableView(tableView, heightForRowAt: indexPath)
    }
}
extension  HFHomeChildViewController: UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.viewModel.tableView(tableView, numberOfRowsInSection: section)
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        return self.viewModel.tableView(tableView, cellForRowAt: indexPath)
    }
    
}

