//
//  HFFMAllChannelViewController.swift
//  HFWYYProject
//
//  Created by Chen on 2021/3/25.
//  Copyright © 2021 CH. All rights reserved.
//

import UIKit

class HFFMAllChannelViewController: UIViewController {

    var leftTableViewSelected : Int = 0
     
    var channelGroupID : Int = 0
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.view.addSubview(leftTableView)
        self.view.addSubview(rightTableView)
        
        weak var weakSelf = self
        viewModel.getAllChannelLeftList {
            weakSelf?.leftTableView.reloadData()
            let modelGroupID = self.viewModel.allChannelLeftListModel![0].id
            weakSelf?.getAllRightList(channelGroupID: modelGroupID)
        }
        
    }
    
    func getAllRightList(channelGroupID: Int)  {
         viewModel.getAllChannelRightList(channelGroupId: channelGroupID) {
             self.rightTableView.reloadData()
         }
    }

    lazy var leftTableView: UITableView = {
        let tableView = UITableView.init(frame: CGRect(x: 0, y: 0, width: 90, height: HFFMScreen_Height), style: .plain)
        tableView.delegate = self
        tableView.dataSource = self
        tableView.separatorStyle = .none
        tableView.register(HFRankLeftTableViewCell.self, forCellReuseIdentifier: "LeftTableViewCell")
        return tableView
    }()
    lazy var rightTableView: UITableView = {
        let tableView = UITableView.init(frame: CGRect(x: 90, y: 0, width: HFFMScreen_Width - 90, height: HFFMScreen_Height), style: .plain)
        tableView.delegate = self
        tableView.dataSource = self
        tableView.register(HFFMAllChannelTableViewCell.self, forCellReuseIdentifier: "AllChannelTableViewCell")
        return tableView
    }()
    
    lazy var viewModel: HFFMChannelViewModel = {
        return HFFMChannelViewModel()
    }()
       
}

extension HFFMAllChannelViewController : UITableViewDelegate{
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        if leftTableView == tableView {
            return 50
        }else{
            return 90
        }
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if leftTableView == tableView {
             self.leftTableViewSelected = indexPath.row
        }
        let model = self.viewModel.allChannelLeftListModel![indexPath.row]
        self.getAllRightList(channelGroupID: model.id)
        
        tableView.reloadData()
    }
    
    func tableView(_ tableView: UITableView, viewForFooterInSection section: Int) -> UIView? {
        return UIView()
    }
}

extension HFFMAllChannelViewController : UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        var isLeft: Bool = false
        if self.leftTableView == tableView{
            isLeft = true
        }else{
            isLeft = false
        }
        return self.viewModel.tableView(tableView, numberOfRowsInSection: section  ,isLeftTableView:isLeft)
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if self.leftTableView == tableView {
            let cell = tableView.dequeueReusableCell(withIdentifier: "LeftTableViewCell", for: indexPath) as! HFRankLeftTableViewCell
            //默认选择第一行
            if self.leftTableViewSelected == indexPath.row{
                cell.isSelectedCell = true
            }else{
                cell.isSelectedCell = false
            }
            let  model = self.viewModel.allChannelLeftListModel![indexPath.row]
            cell.channelModel = model
            return cell
        }else{
            let cell = tableView.dequeueReusableCell(withIdentifier: "AllChannelTableViewCell", for: indexPath) as! HFFMAllChannelTableViewCell
            cell.channelModel = self.viewModel.allChannelRightListModel![indexPath.row]
            return cell
        }
    }
}
