//
//  HFFMCommonUseChannelViewController.swift
//  HFWYYProject
//
//  Created by Chen on 2021/3/25.
//  Copyright © 2021 CH. All rights reserved.
//

import UIKit

class HFFMCommonUseChannelViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
   
}
