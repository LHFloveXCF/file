//
//  HFFMChannelViewController.swift
//  HFWYYProject
//
//  Created by Chen on 2021/3/17.
//  Copyright © 2021 CH. All rights reserved.
//

import UIKit
import DNSPageView

class HFFMChannelViewController: HFFMBaseViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationController?.setNavigationBarHidden(false, animated: false)
        
        self.navigationItem.titleView = pageViewManager.titleView
        pageViewManager.titleView.frame = CGRect(x: 40, y: 0, width: HFFMScreen_Width - 80, height: 44)
        
        //单独设置contentView
        let contentView = pageViewManager.contentView
        view.addSubview(contentView)
        contentView.snp.makeConstraints { (maker) in
            maker.edges.equalToSuperview()
        }
        if #available(iOS 11, *) {
            contentView.collectionView.contentInsetAdjustmentBehavior = .never
        } else {
            automaticallyAdjustsScrollViewInsets = false
        }
    }

    lazy var pageViewManager: PageViewManager = {
        let style = PageStyle()
        style.isShowBottomLine = true
        style.bottomLineColor = HFFMThemeColor
        style.bottomLineWidth = 30
        style.bottomLineHeight = 4
        style.titleSelectedColor = .black
        style.titleColor = UIColor.colorWithHexString("#8E8F90")
        style.isTitleScaleEnabled = true
        style.titleFont = UIFont.systemFont(ofSize: 15)
        style.titleMaximumScaleFactor = 1.0
        style.titleSelectedFont = UIFont.boldSystemFont(ofSize: 17)
        style.titleViewBackgroundColor = .clear
        
        let titles =  ["常用频道","全部频道"]
        let VCArray = [HFFMCommonUseChannelViewController(), HFFMAllChannelViewController()]
        
        for (index , vc) in  VCArray.enumerated(){
            vc.view.backgroundColor = .white
            addChild(vc)
        }
        return PageViewManager(style: style, titles: titles, childViewControllers: children)
    }()

}
