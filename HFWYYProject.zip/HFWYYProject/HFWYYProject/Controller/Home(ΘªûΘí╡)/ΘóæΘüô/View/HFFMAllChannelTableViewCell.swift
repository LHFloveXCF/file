//
//  HFFMAllChannelTableViewCell.swift
//  HFWYYProject
//
//  Created by Chen on 2021/3/25.
//  Copyright © 2021 CH. All rights reserved.
//

import UIKit
import KingfisherWebP
class HFFMAllChannelTableViewCell: UITableViewCell {

    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
    
        contentView.addSubview(coverImageView)
        contentView.addSubview(titleLabel)
        contentView.addSubview(programLabel)
    }
    
    var channelModel  : HFFMChannelRightDataModel? {
        didSet{
            guard  channelModel != nil else {
                return
            }
            self.coverImageView.kf.setImage(with: URL(string: (channelModel?.coverLarge!)!), placeholder: nil, options: [.processor(WebPProcessor.default),.cacheSerializer(WebPSerializer.default)], progressBlock: nil) { (result) in
            }
            self.titleLabel.text = channelModel?.channelName
            
            self.programLabel.text = "\(String(describing: channelModel!.trackCount))节目 | \(String(describing: channelModel!.newCount))更新"
        }
    }
    
    
    override func layoutSubviews() {
        super.layoutSubviews()
        coverImageView.backgroundColor = .randomColor()
        coverImageView.snp.makeConstraints { (make ) in
            make.left.top.equalTo(self).offset(15)
            make.size.equalTo(CGSize(width: 60, height: 60))
        }
        titleLabel.snp.makeConstraints { (make) in
            make.left.equalTo(coverImageView.snp_right).offset(10)
            make.top.equalTo(coverImageView.snp_top).offset(5)
            make.right.equalTo(-30)
        }
        programLabel.snp.makeConstraints { (make) in
            make.left.equalTo(coverImageView.snp_right).offset(10)
            make.bottom.equalTo(coverImageView.snp_bottom).offset(-5)
            make.height.equalTo(15)
        }
//        updateLabel.snp.makeConstraints { (make) in
//            make.left.equalTo(programLabel.snp_right).offset(10)
//            make.bottom.equalTo(coverImageView.snp_bottom).offset(-5)
//            make.height.equalTo(15)
//        }
        
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    lazy var coverImageView: UIImageView = {
        let imageView = UIImageView()
        imageView.layer.cornerRadius = 5
        imageView.layer.masksToBounds = true
        return imageView
    }()
    lazy var titleLabel : UILabel = {
        let label = UILabel.init(titleString: "男频小说", textColorString: "#000000", fontNumber: 15, textAlignments: .left, numberLines: 1)
        label.font = UIFont.boldSystemFont(ofSize: 15)
        return label
    }()
    
    lazy var programLabel: UILabel = {
        let label = UILabel.init(titleString: "665.18节目", textColorString: "#939495", fontNumber: 13, textAlignments: .left, numberLines: 1)
        return label
    }()
    lazy var updateLabel: UILabel = {
        let label = UILabel.init(titleString: "56789更新", textColorString: "#939495", fontNumber: 13, textAlignments: .left, numberLines: 1)
        return label
    }()
}
