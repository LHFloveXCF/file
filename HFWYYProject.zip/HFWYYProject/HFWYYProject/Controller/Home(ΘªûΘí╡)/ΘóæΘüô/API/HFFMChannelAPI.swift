//
//  HFFMChannelAPI.swift
//  HFWYYProject
//
//  Created by Chen on 2021/3/25.
//  Copyright © 2021 CH. All rights reserved.
//

import Foundation

import Moya
import HandyJSON
import SwiftyJSON


let HFFMChannelProvider = MoyaProvider<HFFMChannelAPI>()

enum HFFMChannelAPI {
    case getAllChannelLeftList
    case getAllChannelRightList(Int)
}

extension  HFFMChannelAPI: TargetType{
    var baseURL: URL {
        return  URL(string: "https://mobile.ximalaya.com")!
    }
    
    var path: String {
        switch self {
        case .getAllChannelLeftList:
            return "/metadatav2-mobile/channelgroup/list/ts-1616655518973"
        case .getAllChannelRightList(_):
            return "/metadatav2-mobile/channelgroup/channel/list/ts-1616656797808"
        default:
            break
        }
    }
    
    var method: Moya.Method {
        return .get
    }
    
    var sampleData: Data {
        return "".data(using: String.Encoding.utf8)!
    }
    
    var task: Task {
         var parmeters  : [String : Any] = [:]
        switch self {
        case .getAllChannelRightList(let channelGroupId):
            parmeters = ["channelGroupId" : channelGroupId]
        default:
            parmeters = [:]
        }
      
        return .requestParameters(parameters: parmeters, encoding: URLEncoding.default)
    }
    
    var headers: [String : String]? {
        return nil
    }
}
