//
//  HFFMChannelViewModel.swift
//  HFWYYProject
//
//  Created by Chen on 2021/3/25.
//  Copyright © 2021 CH. All rights reserved.
//

import UIKit
import SwiftyJSON
import HandyJSON

class HFFMChannelViewModel: NSObject {

    var allChannelLeftListModel  : [HFFMChannelLeftDataModel]?
    var allChannelRightListModel : [HFFMChannelRightDataModel]?
    
    
    typealias callBackBlock =  () -> Void
}

extension HFFMChannelViewModel{
    func getAllChannelLeftList( updataBlock: @escaping callBackBlock) {
        HFFMChannelProvider.request(.getAllChannelLeftList) { (result) in
            if case let .success(response) = result {
                let data = try? response.mapJSON()
                let json = JSON(data!)
                print("全部频道的左边json ==\(json)")
                if let mappObject = JSONDeserializer<HFFMChannelLeftModel>.deserializeFrom(json: json["data"].description) {
                    self.allChannelLeftListModel = mappObject.list
                    updataBlock()
                }
            }
        }
    }
    
    func getAllChannelRightList(channelGroupId : Int ,updataBlock: @escaping callBackBlock ) {
        HFFMChannelProvider.request(.getAllChannelRightList(channelGroupId)) { (result) in
            if case let .success(response) = result {
                let data = try? response.mapJSON()
                let json = JSON(data!)
                print("全部频道的右边json ==\(json)")
                if let mappObject = JSONDeserializer<HFFMChannelRightModel>.deserializeFrom(json: json["data"].description) {
                    self.allChannelRightListModel = mappObject.list
                    updataBlock()
                }
            }
        }
    }
}


extension HFFMChannelViewModel {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int , isLeftTableView : Bool) -> Int{
        if isLeftTableView {
              return self.allChannelLeftListModel?.count ?? 0
        }else{
            return self.allChannelRightListModel?.count ?? 0
        }
       
    }
}
