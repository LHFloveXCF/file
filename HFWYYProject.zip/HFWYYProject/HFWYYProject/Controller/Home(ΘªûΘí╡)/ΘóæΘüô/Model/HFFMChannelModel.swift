//
//  HFFMChannelModel.swift
//  HFWYYProject
//
//  Created by Chen on 2021/3/25.
//  Copyright © 2021 CH. All rights reserved.
//

import UIKit
import HandyJSON


struct HFFMChannelLeftModel: HandyJSON {
    var pageId : Int = 0
    var pageSize : Int = 0
    var maxPageId : Int = 0
    var totalCount : Int = 0
    var list : [HFFMChannelLeftDataModel]?
    
}

struct HFFMChannelLeftDataModel: HandyJSON{
    var  id : Int = 0
    var  channelCount : Int = 0
    var  position : Int = 0
    var  name : String?
}

struct HFFMChannelRightModel : HandyJSON {
     var pageId : Int = 0
     var pageSize : Int = 0
     var maxPageId : Int = 0
     var totalCount : Int = 0
     var list : [HFFMChannelRightDataModel]?
}
struct HFFMChannelRightDataModel: HandyJSON {
     var channelId : Int = 0
    var relationMetadataValueId : Int = 0
    var channelName : String?
    var coverSmall : String?
    var coverMiddle : String?
    var coverLarge : String?
    var newCount : Int = 0
    var trackCount : Int = 0
    var type : Int = 0
    var position : Int = 0
    var iting : String?
    
}
