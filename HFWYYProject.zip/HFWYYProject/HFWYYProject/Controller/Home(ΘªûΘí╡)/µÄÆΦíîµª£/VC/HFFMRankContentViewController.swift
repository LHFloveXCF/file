//
//  HFFMRankContentViewController.swift
//  HFWYYProject
//
//  Created by Chen on 2021/3/16.
//  Copyright © 2021 CH. All rights reserved.
//

import UIKit

class HFFMRankContentViewController: UIViewController {
    var  selectedIndex : Int = 0
    

    override func viewDidLoad() {
        super.viewDidLoad()
 
        print("HFFMRankContentViewController")
        
    }


}
