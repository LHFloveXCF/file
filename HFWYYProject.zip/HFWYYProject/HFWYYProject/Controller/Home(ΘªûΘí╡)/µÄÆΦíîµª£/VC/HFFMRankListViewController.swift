//
//  HFFMRankListViewController.swift
//  HFWYYProject
//
//  Created by Chen on 2021/3/16.
//  Copyright © 2021 CH. All rights reserved.
//

import UIKit
import DNSPageView
import MJRefresh

class HFFMRankListViewController: UIViewController {
    
    var selectedIndex : Int = 0
    
    
    var leftTableViewSelected : Int = 0
    
    var categoryId : Int = 0
    var clusterType : Int = 0
    var rankingListId : Int = 0
    
    // 定义一个可变数组,必须初始化才能使用
    var titles : [String] = [String]()
    
    var pageNumber: Int? //页码
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.view.addCorner(conrners: [.topLeft , .topRight], radius: 10)
        //        print("初始化几次")
        getRankLeftList(rankingListId: 14)
        
        getRankListData(selectedIndex: 0)
        
    }
 
    //获取左边表格的数据
    func getRankLeftList(rankingListId : Int) {
        // 解决方式一: weak
        weak var weakSelf = self
        rankListViewModel.getRankLeftList(rankingListId: rankingListId) {
            weakSelf!.view.addSubview(self.leftTableView)
            weakSelf!.leftTableView.reloadData()
            let model = self.rankListViewModel.rankLeftListModel![0]
            self.categoryId = model.categoryId
            self.clusterType = model.rankClusterId
            self.rankingListId = model.rankingListId
        }
        
    }
    
    //获取右边表格的数据
    func getRankListData(selectedIndex : Int) {
        self.view.addSubview(self.rightTableView)
        
        rightTableView.initRefreshView()
        rightTableView.mj_header?.refreshingBlock = { [weak self] in
            self?.pageNumber = 1
            if selectedIndex == 0 {
                self?.getNewProductRankList()
            }else if( selectedIndex == 1){
                self?.getHotProductRankList()
            }else if (selectedIndex == 2){
                self?.getSellerProductRankList()
            }else {
                self?.getOnLineProduceRankList()
            }
        }
        rightTableView.mj_footer?.refreshingBlock = { [weak self] in
            if  self!.pageNumber! >= self!.rankListViewModel.maxPageNumber!{
                self?.rightTableView.mj_footer?.endRefreshingWithNoMoreData()
                return
            }
            if selectedIndex == 0 {
                self?.getNewProductRankList()
            }else if( selectedIndex == 1){
                self?.getHotProductRankList()
            }else if (selectedIndex == 2){
                self?.getSellerProductRankList()
            }else {
                self?.getOnLineProduceRankList()
            }
        }
        rightTableView.mj_header?.beginRefreshing()
    }
    
    func getNewProductRankList()  {
        rankListViewModel.getNewProductRankList(pageNumber: self.pageNumber!, categoryId: self.categoryId, clusterType: self.clusterType, rankingListId: self.rankingListId) {
             self.rightTableView.mj_header?.endRefreshing()
             self.rightTableView.mj_footer?.endRefreshing()
             
             self.pageNumber! += 1
             self.rightTableView.reloadData()
        }
 
    }
    
    func getHotProductRankList() {
        rankListViewModel.getHotProdectRankList(pageNumber: self.pageNumber!, categoryId: self.categoryId, clusterType: self.clusterType, rankingListId: self.rankingListId) {
            self.rightTableView.mj_header?.endRefreshing()
            self.rightTableView.mj_footer?.endRefreshing()
            
            self.pageNumber! += 1
            self.rightTableView.reloadData()
        }
        
    }
    
    func getSellerProductRankList() {
        rankListViewModel.getSellerProductRankList(pageNumber: self.pageNumber!, categoryId: self.categoryId, clusterType: self.clusterType, rankingListId:self.rankingListId) {
            self.rightTableView.mj_header?.endRefreshing()
            self.rightTableView.mj_footer?.endRefreshing()
            
            self.pageNumber! += 1
            self.rightTableView.reloadData()
        }
    }
    
    func getOnLineProduceRankList() {
        rankListViewModel.getOnLineProductRankList(pageNumber: self.pageNumber!, categoryId: self.categoryId, clusterType: self.clusterType, rankingListId: self.rankingListId) {
            self.rightTableView.mj_header?.endRefreshing()
            self.rightTableView.mj_footer?.endRefreshing()
            
            self.pageNumber! += 1
            self.rightTableView.reloadData()
        }
        
    }
    
    lazy var leftTableView: UITableView = {
        let tableView = UITableView.init(frame: CGRect(x: 0 , y: 5, width: 90, height: HFFMScreen_Height - 150 - 44), style: .plain)
        tableView.register(HFRankLeftTableViewCell.self, forCellReuseIdentifier: "RankLeft")
        tableView.delegate = self
        tableView.dataSource = self
        tableView.backgroundColor = .clear
        tableView.separatorStyle = .none
        return tableView
    }()
    
    lazy var rightTableView: UITableView = {
        let tableView = UITableView.init(frame: CGRect(x: 95, y: 5, width: HFFMScreen_Width - 95, height: HFFMScreen_Height - 150 - 44), style: .plain)
        tableView.delegate = self
        tableView.dataSource  = self
        tableView.backgroundColor = .clear
        tableView.register(HFNewRankRightTableViewCell.self, forCellReuseIdentifier: "RankRightCell")
        tableView.register(HFRankOnLineTableViewCell.self, forCellReuseIdentifier: "OnLineTableViewCell")
        return tableView
    }()
    lazy var rankListViewModel: HFFMRankListViewModel = {
        return HFFMRankListViewModel()
    }()
}


extension HFFMRankListViewController: UITableViewDelegate{
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        if leftTableView == tableView {
            return 50
        }else{
            if self.selectedIndex == 3 {
                 return 80
            }
            return 100
        }
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if leftTableView == tableView {
            self.leftTableViewSelected = indexPath.row
            let model = self.rankListViewModel.rankLeftListModel![indexPath.row]
            self.categoryId = model.categoryId
            self.clusterType = model.rankClusterId
            self.rankingListId = model.rankingListId
            
            
            self.getRankListData(selectedIndex: self.selectedIndex)
            
            tableView.reloadData()
        }
    }
    
}
extension HFFMRankListViewController: UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if leftTableView == tableView {
            return self.rankListViewModel.rankLeftListModel!.count
        }
        
        if rightTableView == tableView{
            return  self.rankListViewModel.tableView(tableView, numberOfRowsInSection: section, selectedIndex: self.selectedIndex)
        }
        return 0
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if leftTableView == tableView {
            let cell = tableView.dequeueReusableCell(withIdentifier: "RankLeft", for: indexPath) as!HFRankLeftTableViewCell
            cell.leftModel = self.rankListViewModel.rankLeftListModel![indexPath.row]
            //默认选择第一行
            if self.leftTableViewSelected == indexPath.row{
                cell.isSelectedCell = true
            }else{
                cell.isSelectedCell = false
            }
            
            return cell
        }else{
            if self.selectedIndex == 3 {
                let cell = tableView.dequeueReusableCell(withIdentifier: "OnLineTableViewCell", for: indexPath) as! HFRankOnLineTableViewCell
                cell.model = self.rankListViewModel.onLineListModel![indexPath.row]
                return cell
            }else{
                let  cell  = tableView.dequeueReusableCell(withIdentifier: "RankRightCell", for: indexPath) as! HFNewRankRightTableViewCell
                cell.model = self.rankListViewModel.rankRightListModel?[indexPath.row]
                return cell
            }
            return UITableViewCell()
        }
    }
}


extension HFFMRankListViewController : PageEventHandleable{
    func titleViewDidSelectSameTitle() {
        print("重复点击了标题，index：\(selectedIndex)")
    }
    
    func contentViewDidDisappear() {
        print("contentView滑动结束，index：\(selectedIndex)")
        
    }
    
    func contentViewDidEndScroll() {
        print("我消失了，index：\(selectedIndex)")
        
        self.getRankListData(selectedIndex: selectedIndex)
        
        
        switch selectedIndex {
        case 0:
            self.getRankLeftList(rankingListId: 14)
        case 1 :
            self.getRankLeftList(rankingListId: 12)
        case 2:
            self.getRankLeftList(rankingListId: 13)
        case 3:
            self.getRankLeftList(rankingListId: 17)
        default:
             break
        }

    }

}

