//
//  HFFMRankViewController.swift
//  HFWYYProject
//
//  Created by Chen on 2021/3/17.
//  Copyright © 2021 CH. All rights reserved.
//

import UIKit
import DNSPageView

class HFFMRankViewController: HFFMBaseViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationController?.setNavigationBarHidden(true, animated: false)
        
        self.view.addSubview(headerView)
        
         
//        // 单独设置 titleView 的 frame
        self.view.addSubview(pageViewManger.titleView)
        pageViewManger.titleView.frame = CGRect(x: 0, y: 150, width: HFFMScreen_Width - 20, height: 44)
//        pageViewManger.titleView.delegate = self
        // 单独设置 contentView 的大小和位置，可以使用 autolayout 或者 frame
        let contentView = pageViewManger.contentView
//        contentView.delegate = self
        view.addSubview(pageViewManger.contentView)
        
        contentView.snp.makeConstraints { (maker) in
            maker.top.equalTo(pageViewManger.titleView.snp_bottom).offset(0)
            maker.size.equalTo(CGSize(width: HFFMScreen_Width, height: HFFMScreen_Height - 150 - 44))
        }

        if #available(iOS 11, *) {
            contentView.collectionView.contentInsetAdjustmentBehavior = .never
        } else {
            automaticallyAdjustsScrollViewInsets = false
        }
        
    }
 
    lazy var pageViewManger: PageViewManager = {
        let style = PageStyle()
        style.isShowBottomLine = true
        style.bottomLineColor = HFFMThemeColor
        style.bottomLineWidth = 30
        style.bottomLineHeight = 4
        style.titleSelectedColor = HFFMThemeColor
        style.isTitleScaleEnabled = true
        style.titleFont = UIFont.systemFont(ofSize: 15)
        style.titleMaximumScaleFactor = 1.0
        style.titleSelectedFont = UIFont.boldSystemFont(ofSize: 17)
        
        let titles =   ["新品榜","热播榜","畅销榜","口碑榜"]
        
        let VCArray = [HFFMRankListViewController(), HFFMRankListViewController(), HFFMRankListViewController() , HFFMRankListViewController()]
        
        for (index , vc) in  VCArray.enumerated(){
            vc.view.backgroundColor = .white
            vc.selectedIndex = index
            addChild(vc)
        }

        return PageViewManager(style: style, titles: titles, childViewControllers: children)
    }()
    
    lazy var headerView: HFFMRankHeaderView = {
        let view = HFFMRankHeaderView.init(frame: CGRect(x: 0, y: 0, width: HFFMScreen_Width, height: 150))
        view.delegate = self
        return view
    }()
}


extension HFFMRankViewController : HFFMRankHeaderDelegae{
    func backButtonClick() {
        self.navigationController?.popViewController(animated: true)
    }
}



//extension HFFMRankViewController : PageTitleViewDelegate {
//    var eventHandler: PageEventHandleable? {
//         return  nil
//    }
//    func titleView(_ titleView: PageTitleView, didSelectAt index: Int) {
//         print("didSelectAt==\(index)")
//
//    }
//}

//extension HFFMRankViewController: PageContentViewDelegate{
//    func contentView(_ contentView: PageContentView, didEndScrollAt index: Int) {
//         print(index)
//    }
//
//    func contentView(_ contentView: PageContentView, scrollingWith sourceIndex: Int, targetIndex: Int, progress: CGFloat) {
//
//    }
//
//
//}
