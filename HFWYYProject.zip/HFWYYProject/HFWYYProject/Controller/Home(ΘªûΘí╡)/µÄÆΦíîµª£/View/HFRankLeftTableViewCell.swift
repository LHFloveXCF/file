//
//  HFRankLeftTableViewCell.swift
//  HFWYYProject
//
//  Created by Chen on 2021/3/17.
//  Copyright © 2021 CH. All rights reserved.
//

import UIKit

class HFRankLeftTableViewCell: UITableViewCell {
    
    

    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        contentView.addSubview(titleLabel)
        contentView.addSubview(leftImageView)
        contentView.backgroundColor = .clear
        self.backgroundColor = UIColor.colorWithHexString("#F1F2F4")
        self.selectionStyle = .none
    }
    
    var isSelectedCell : Bool? {
        didSet{
            if isSelectedCell == true {
                self.backgroundColor = .white
                self.titleLabel.textColor =  HFFMThemeColor
                self.leftImageView.isHidden = false
            }else{
                 self.backgroundColor = UIColor.colorWithHexString("#F1F2F4")
                self.titleLabel.textColor =  UIColor.colorWithHexString("#757576")
                self.leftImageView.isHidden = true
            }
        }
    }
    
    
    
    
    override func layoutSubviews() {
        super.layoutSubviews()
        leftImageView.snp.makeConstraints { (make) in
            make.left.equalTo(contentView).offset(0)
            make.centerY.equalTo(contentView.snp_centerY)
            make.size.equalTo(CGSize(width: 4, height: 15))
        }
        
        titleLabel.snp.makeConstraints { (make ) in
            make.centerY.equalTo(contentView.snp_centerY)
            make.left.equalTo(contentView).offset(15)
            make.height.equalTo(20)
        }
        
    }
    
    
    var leftModel : HFRankLeftListDataModel? {
        didSet{
            guard leftModel != nil  else {
                 return
            }
            self.titleLabel.text = leftModel?.name
        }
    }
    
    
    var channelModel  : HFFMChannelLeftDataModel? {
        didSet{
            guard channelModel != nil  else {
                return
            }
            self.titleLabel.text = channelModel?.name
        }
    }
    
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    lazy var leftImageView: UIImageView = {
        let imageView = UIImageView.init()
        imageView.backgroundColor = HFFMThemeColor
        imageView.layer.cornerRadius = 2
        imageView.layer.masksToBounds = true
        return imageView
    }()
    
    lazy var titleLabel : UILabel = {
        let label = UILabel.init(titleString: "热门", textColorString: "#757576", fontNumber: 15, textAlignments: .left, numberLines: 0)
        label.textAlignment = .left
        return label
    }()
}
