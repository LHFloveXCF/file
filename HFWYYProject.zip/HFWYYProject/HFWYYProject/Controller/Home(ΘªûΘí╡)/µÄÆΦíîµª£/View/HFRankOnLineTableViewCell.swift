//
//  HFRankOnLineTableViewCell.swift
//  HFWYYProject
//
//  Created by Chen on 2021/3/24.
//  Copyright © 2021 CH. All rights reserved.
//

import UIKit
import Kingfisher

class HFRankOnLineTableViewCell: UITableViewCell {
    
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        contentView.addSubview(leftImageView)
        contentView.addSubview(leftBottomImageView)
        contentView.addSubview(coverImageView)
        contentView.addSubview(levelLabel)
        contentView.addSubview(titleLabel)
        contentView.addSubview(subtitleLabel)
        contentView.addSubview(strengthLabel)
        contentView.addSubview(attentionButton)
        
    }
    
    var model : HFRankOnLineDataModel? {
        didSet{
            guard model != nil else {
                return
            }
//            self.coverImageView.kf.setImage(with: URL(string: (model?.logoPic)!))
            self.titleLabel.text = model?.nickname
            self.subtitleLabel.text = model?.personDescribe
            self.strengthLabel.text = model?.score
            
            if model?.followStatus ==  1 {
                self.attentionButton.setTitle("已关注 ", for: .normal)
                self.attentionButton.setTitleColor(UIColor.colorWithHexString("#9C9D9E"), for: .normal)
                self.attentionButton.setImage(UIImage(named: "attention_selected"), for: .normal)
            }
        }
    }
    
    
    override func layoutSubviews() {
        super.layoutSubviews()
        coverImageView.snp.makeConstraints { (make) in
            make.left.equalTo(contentView).offset(35)
            make.centerY.equalTo(contentView.snp_centerY)
            make.size.equalTo(CGSize(width: 40, height: 40))
        }
        leftBottomImageView.snp.makeConstraints { (make ) in
            make.bottom.equalTo(coverImageView.snp_bottom).offset(-3)
            make.left.equalTo(10)
            make.size.equalTo(CGSize(width: 5, height: 2))
        }
        
        leftImageView.snp.makeConstraints { (make) in
            make.centerX.equalTo(leftBottomImageView.snp_centerX)
            make.centerY.equalTo(contentView.snp_centerY)
            make.size.equalTo(CGSize(width: 20, height: 20))
        }
        
        levelLabel.snp.makeConstraints { (make ) in
            make.left.equalTo(coverImageView.snp_right).offset(10)
            make.top.equalTo(coverImageView)
            make.height.equalTo(13)
            make.width.equalTo(40)
        }
        
        titleLabel.snp.makeConstraints { (make ) in
            make.left.equalTo(levelLabel.snp_right).offset(2)
            make.centerY.equalTo(levelLabel.snp_centerY)
            make.right.equalTo(contentView.snp_right).offset(-20)
        }
        
        subtitleLabel.snp.makeConstraints { (make) in
            make.left.equalTo(levelLabel.snp_left)
            make.top.equalTo(levelLabel.snp_bottom).offset(8)
            make.right.equalTo(contentView.snp_right).offset(-40)
        }
        strengthLabel.snp.makeConstraints { (make) in
            make.left.equalTo(levelLabel.snp_left)
            make.top.equalTo(subtitleLabel.snp_bottom).offset(5)
            make.right.equalTo(contentView.snp_right).offset(-20)
        }
        
        attentionButton.snp.makeConstraints { (make ) in
            make.right.equalTo(self.snp_right).offset(-10)
            make.bottom.equalTo(contentView.snp_bottom).offset(-15)
            make.size.equalTo(CGSize(width: 50, height: 40))
        }
        
    }
    
    lazy var leftImageView: UIImageView = {
        let imageView = UIImageView.init()
        imageView.backgroundColor = HFFMThemeColor
        return imageView
    }()
    lazy var leftBottomImageView: UIImageView = {
        let imageView = UIImageView.init()
        imageView.backgroundColor = HFFMThemeColor
        return imageView
    }()
    lazy var coverImageView: UIImageView = {
        let imageView = UIImageView.init()
        imageView.layer.cornerRadius = 20
        imageView.layer.masksToBounds = true
        imageView.backgroundColor = HFFMThemeColor
        return imageView
    }()
    lazy var levelLabel: UILabel = {
        let label = UILabel.init(titleString: "LV16", textColorString: "#A6233C", fontNumber: 10 , textAlignments: .center, numberLines: 0)
        label.font = UIFont.boldSystemFont(ofSize: 10)
        label.backgroundColor = UIColor.colorWithHexString("#F6C4CD")
        label.layer.cornerRadius  = 13 / 2
        label.layer.masksToBounds = true
        return label
    }()
    lazy var titleLabel : UILabel = {
        let label = UILabel.init(titleString: "热门", textColorString: "#1C1C1C", fontNumber: 15, textAlignments: .left, numberLines: 0)
        return label
    }()
    lazy var subtitleLabel : UILabel = {
        let label = UILabel.init(titleString: "喜马人肉故事机", textColorString: "#9C9D9E", fontNumber: 12, textAlignments: .left, numberLines:1)
        return label
    }()
    lazy var strengthLabel : UILabel = {
        let label = UILabel.init(titleString: "实力:45678", textColorString: "#BBBCBD", fontNumber: 10, textAlignments: .left, numberLines:1)
        return label
    }()
    lazy var attentionButton : UIButton = {
        let button = UIButton.init(type: .custom)
        button.setImage(UIImage(named: "attention_normal"), for: .normal)
        button.imagePosition(style: .top, spacing: 3)
        button.setTitle("关注", for: .normal)
        button.setTitleColor(HFFMThemeColor, for: .normal)
        button.titleLabel?.font = UIFont.systemFont(ofSize: 12)
        return button
    }()
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
}
