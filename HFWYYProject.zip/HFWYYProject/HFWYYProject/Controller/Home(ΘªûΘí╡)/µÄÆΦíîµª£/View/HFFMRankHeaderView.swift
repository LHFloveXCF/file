//
//  HFFMRankHeaderView.swift
//  HFWYYProject
//
//  Created by Chen on 2021/3/17.
//  Copyright © 2021 CH. All rights reserved.
//

import UIKit

class HFFMRankHeaderView: UIView {
    weak var delegate : HFFMRankHeaderDelegae?
    

    override init(frame: CGRect) {
        super.init(frame: frame )
        self.addSubview(bgImageView)
        bgImageView.addSubview(backButton)
        bgImageView.addSubview(shareButton)
        
    }
    override func layoutSubviews() {
        super.layoutSubviews()
        bgImageView.snp.makeConstraints { (make) in
            make.left.right.top.equalTo(self).offset(0)
            make.height.equalTo(150)
        }
        backButton.snp.makeConstraints { (make ) in
            make.left.equalTo(self).offset(10)
            make.top.equalTo(self).offset(60)
            make.size.equalTo(CGSize(width: 30, height: 20))
        }
        shareButton.snp.makeConstraints { (make ) in
            make.right.equalTo(self).offset(-20)
            make.top.equalTo(self).offset(60)
            make.size.equalTo(CGSize(width: 30, height: 20))
        }
    }
    
    lazy var bgImageView: UIImageView = {
        let imageView = UIImageView.init(frame: CGRect(x: 0, y: 0, width: HFFMScreen_Width, height: 150))
        imageView.backgroundColor = UIColor.black.withAlphaComponent(0.5)
        imageView.isUserInteractionEnabled = true
        return imageView
    }()
    
    lazy var backButton: UIButton = {
        let button = UIButton.init(type: .custom)
        button.setImage(UIImage(named: "white_back"), for: .normal)
        button.addTarget(self, action: #selector(backButtonClick), for: .touchUpInside)
        return button
    }()
    
    lazy var shareButton: UIButton = {
        let button = UIButton.init(type: .custom)
        button.setImage(UIImage(named: "white_share"), for: .normal)
        button.addTarget(self, action: #selector(shareButtonClick), for: .touchUpInside)
        button.imageView?.contentMode = .scaleAspectFit
        return button
    }()
    
    @objc func backButtonClick(){
        
        if self.delegate != nil && ((self.delegate?.responds(to: #selector(self.backButtonClick))) != nil) {
            self.delegate?.backButtonClick()
        }
    }
    @objc func shareButtonClick(){
        
    }
    
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}

protocol HFFMRankHeaderDelegae: NSObjectProtocol {
     func backButtonClick()
}
