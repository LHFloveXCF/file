//
//  HFNewRankRightTableViewCell.swift
//  HFWYYProject
//
//  Created by Chen on 2021/3/17.
//  Copyright © 2021 CH. All rights reserved.
//

import UIKit
import KingfisherWebP

class HFNewRankRightTableViewCell: UITableViewCell {
    
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        contentView.backgroundColor = .clear
        self.backgroundColor = .clear
        self.selectionStyle = .none
        
        contentView.addSubview(leftImageView)
        contentView.addSubview(leftBottomImageView)
        contentView.addSubview(titleLabel)
        contentView.addSubview(coverImageView)
        contentView.addSubview(subtitleLabel)
        contentView.addSubview(hotLabel)
        contentView.addSubview(youXuanImageView)
    }
    override func layoutSubviews() {
        super.layoutSubviews()
        coverImageView.snp.makeConstraints { (make) in
            make.left.equalTo(contentView).offset(30)
            make.centerY.equalTo(contentView.snp_centerY)
            make.size.equalTo(CGSize(width: 80, height: 80))
        }
        leftBottomImageView.snp.makeConstraints { (make ) in
            make.top.equalTo(coverImageView.snp_bottom).offset(-30)
            make.left.equalTo(10)
            make.size.equalTo(CGSize(width: 5, height: 2))
        }
        
        leftImageView.snp.makeConstraints { (make) in
            make.centerX.equalTo(leftBottomImageView.snp_centerX)
            make.bottom.equalTo(leftBottomImageView.snp_top).offset(-5)
            make.size.equalTo(CGSize(width: 20, height: 20))
        }
        
        titleLabel.snp.makeConstraints { (make ) in
            make.left.equalTo(coverImageView.snp_right).offset(10)
            make.top.equalTo(coverImageView.snp_top)
            make.right.equalTo(contentView.snp_right).offset(-25)
        }
        
        subtitleLabel.snp.makeConstraints { (make ) in
            make.left.equalTo(coverImageView.snp_right).offset(10)
            make.top.equalTo(titleLabel.snp_bottom).offset(10)
            make.right.equalTo(contentView.snp_right).offset(-25)
        }
        
        hotLabel.snp.makeConstraints { (make ) in
            make.left.equalTo(coverImageView.snp_right).offset(10)
            make.bottom.equalTo(coverImageView.snp_bottom).offset(0)
            make.right.equalTo(contentView.snp_right).offset(-25)
        }
        youXuanImageView.snp.makeConstraints { (make ) in
            make.left.equalTo(contentView).offset(30)
            make.top.equalTo(coverImageView).offset(0)
            make.height.equalTo(15)
            make.width.equalTo(50)
         }
    }
    
    
    
    
    var model  : HFRankContentDataListModel? {
        didSet{
            guard model != nil else {
                return
            }
            
            self.coverImageView.kf.setImage(with: URL(string: (model?.coverLarge)!))
            self.titleLabel.text = model?.title ?? ""
            self.subtitleLabel.text = model?.customTitle
            self.hotLabel.text = model?.popularity ?? ""
            
            
            
            if model?.albumSubscript != nil {
                let json : [String : Any] = ( self.stringValueDic((model?.albumSubscript)!)!)
                let albumSubscriptUrl : String = json["url"]! as! String
                
                self.youXuanImageView.kf.setImage(with: URL(string: albumSubscriptUrl), placeholder: nil, options: [.processor(WebPProcessor.default),.cacheSerializer(WebPSerializer.default)], progressBlock: nil) { (result) in
                }
            }

        }
    }
    func stringValueDic(_ str: String) -> [String : Any]?{
        
        let data = str.data(using: String.Encoding.utf8)
        
        if let dict = try? JSONSerialization.jsonObject(with: data!, options: JSONSerialization.ReadingOptions.mutableContainers) as? [String : Any] {
            
            return dict
            
        }
        
        return nil
        
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    lazy var leftImageView: UIImageView = {
        let imageView = UIImageView.init()
        imageView.backgroundColor = HFFMThemeColor
        return imageView
    }()
    lazy var leftBottomImageView: UIImageView = {
        let imageView = UIImageView.init()
        imageView.backgroundColor = HFFMThemeColor
        return imageView
    }()
    lazy var coverImageView: UIImageView = {
        let imageView = UIImageView.init()
        imageView.layer.cornerRadius = 5
        imageView.layer.masksToBounds = true
        imageView.backgroundColor = HFFMThemeColor
        return imageView
    }()
    lazy var titleLabel : UILabel = {
        let label = UILabel.init(titleString: "热门", textColorString: "#1C1C1C", fontNumber: 15, textAlignments: .left, numberLines: 0)
        label.font = UIFont.boldSystemFont(ofSize: 15)
        return label
    }()
    lazy var subtitleLabel : UILabel = {
        let label = UILabel.init(titleString: "热门", textColorString: "#CFCFCF", fontNumber: 12, textAlignments: .left, numberLines:1)
        return label
    }()
    lazy var hotLabel : UILabel = {
        let label = UILabel.init(titleString: "热度:110678", textColorString: "#CFCFCF", fontNumber: 12, textAlignments: .left, numberLines:1)
        return label
    }()
    lazy var youXuanImageView: UIImageView = {
        let imageView = UIImageView.init()
        return imageView
    }()
}
