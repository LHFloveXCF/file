//
//  HFFMRankListViewModel.swift
//  HFWYYProject
//
//  Created by Chen on 2021/3/16.
//  Copyright © 2021 CH. All rights reserved.
//

import Foundation
import SwiftyJSON
import HandyJSON

class HFFMRankListViewModel: NSObject {
     
    var rankListTopListModel :[HFRankListTopDataListModel]?
    
    //左边标签的数组
    var rankLeftListModel :[HFRankLeftListDataModel]? = []
    
    //主播榜的数组
    var  onLineListModel : [HFRankOnLineDataModel]? = []
    
    
    var maxPageNumber : Int?
    
    
 
    
    
    //右边的数组
    var rankRightListModel :[HFRankContentDataListModel]? = []
    
    
    
    // Mark: -数据源更新
    typealias AddDataBlock = () ->Void
    var updataBlock:AddDataBlock?
    
    typealias getDatablock = ()->Void
}

extension HFFMRankListViewModel {
    func getTopFirstData() {
        HFFMRankListProvider.request(.rankFirstPage) { (result) in
            print(result)
            if case let  .success(response) = result{
                //解析数据
                let data = try? response.mapJSON()
                let json = JSON(data!)
                print(json)
                
                if let mapObject = JSONDeserializer<HFRankListTopModel>.deserializeFrom(json: json.description){
                    self.rankListTopListModel = mapObject.data
 
                    self.updataBlock!()
                }
            }
        }
    }
}


extension HFFMRankListViewModel {
    //新品榜
    func getNewProductRankList(pageNumber: Int ,categoryId : Int , clusterType: Int , rankingListId: Int,  updataBlock: @escaping getDatablock)  {
        HFFMRankListProvider.request(.newRankRightList(pageNumber , categoryId , clusterType , rankingListId)) { (result) in
            if case let  .success(response) = result{
                //解析数据
                let data = try? response.mapJSON()
                let json = JSON(data!)
//                print("新品榜 ==\(json)")
                print("新品榜 ==")

                if let mappObject = JSONDeserializer<HFRankContentModel>.deserializeFrom(json: json.description) {
                    
                    self.maxPageNumber = mappObject.data?.maxPageId 
                    
                    if pageNumber == 1 {
                        self.rankRightListModel?.removeAll()
                        self.rankRightListModel = mappObject.data?.list
                    }else{
                        self.rankRightListModel! += (mappObject.data?.list)!
                    }
                    updataBlock()
                }
            }
        }
    }
    //热播榜
    func getHotProdectRankList(pageNumber: Int , categoryId : Int , clusterType: Int , rankingListId: Int, updataBlock: @escaping getDatablock) {
        HFFMRankListProvider.request(.hotRankRightList(pageNumber , categoryId , clusterType , rankingListId)) { (result ) in
            if case let  .success(response) = result{
                //解析数据
                let data = try? response.mapJSON()
                let json = JSON(data!)
//                print("热播榜 ==\(json)")
                print("热播榜 ==")

                if let mappObject = JSONDeserializer<HFRankContentModel>.deserializeFrom(json: json.description) {
                    
                    self.maxPageNumber = mappObject.data?.maxPageId
                    
                    if pageNumber == 1 {
                        self.rankRightListModel?.removeAll()
                        self.rankRightListModel = mappObject.data?.list
                    }else{
                        self.rankRightListModel! += (mappObject.data?.list)!
                    }
                    updataBlock()
                }
            }
        }
    }
    //畅销榜
    func getSellerProductRankList(pageNumber: Int,  categoryId : Int , clusterType: Int , rankingListId: Int, updataBlock: @escaping getDatablock) {
        HFFMRankListProvider.request(.sellerRankRightList(pageNumber , categoryId , clusterType , rankingListId)) { (result) in
            if case let  .success(response) = result{
                //解析数据
                let data = try? response.mapJSON()
                let json = JSON(data!)
                //                print("畅销榜 ==\(json)")
                print("畅销榜 ==")
                
                if let mappObject = JSONDeserializer<HFRankContentModel>.deserializeFrom(json: json.description) {
                    
                    self.maxPageNumber = mappObject.data?.maxPageId
                    
                    if pageNumber == 1 {
                        self.rankRightListModel?.removeAll()
                        self.rankRightListModel = mappObject.data?.list
                    }else{
                        self.rankRightListModel! += (mappObject.data?.list)!
                    }
                    updataBlock()
                }
            }
        }
    }
    //主播榜
    func getOnLineProductRankList(pageNumber :Int ,  categoryId : Int , clusterType: Int , rankingListId: Int,  updataBlock: @escaping getDatablock) {
        HFFMRankListProvider.request(.onLineRankRightList(pageNumber  ,categoryId ,clusterType , rankingListId)) { (result) in
            if case let  .success(response) = result{
                //解析数据
                let data = try? response.mapJSON()
                let json = JSON(data!)
                print("主播榜 =\(json)")
                
                if let mappObject = JSONDeserializer<HFRankOnLineModel>.deserializeFrom(json: json["data"].description) {
                    self.maxPageNumber = mappObject.maxPageId
                    
                    if pageNumber == 1 {
                        self.onLineListModel?.removeAll()
                        self.onLineListModel = mappObject.list
                    }else{
                        self.onLineListModel! += (mappObject.list)!
                    }
                    updataBlock()
                }
            }
        }
    }
}

extension HFFMRankListViewModel{
    func getRankLeftList(rankingListId: Int , updataBlock: @escaping getDatablock) {
        HFFMRankListProvider.request(.rankLeftList(rankingListId)) { (result) in
            if case let  .success(response) = result{
                //解析数据
                let data = try? response.mapJSON()
                let json = JSON(data!)
//                print("左边标签 ==\(json)")
                
                if let mappObject = JSONDeserializer<HFRankLeftListModel>.deserializeFrom(json: json.description) {
                    self.rankLeftListModel = mappObject.data
                    updataBlock()
                }
            }
        }
    }
}

extension HFFMRankListViewModel {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int , selectedIndex :Int) -> Int {
        
        if selectedIndex == 3 {
            return self.onLineListModel?.count ?? 0
        }else{
            return self.rankRightListModel?.count ?? 0
        }
    }
}
