
//
//  HFFMRankListAPI.swift
//  HFWYYProject
//
//  Created by Chen on 2021/3/16.
//  Copyright © 2021 CH. All rights reserved.
//

import Foundation
import Moya
import HandyJSON
import SwiftyJSON

let HFFMRankListProvider = MoyaProvider<HFFMRankListAPI>()


enum HFFMRankListAPI {
    case rankFirstPage
    case newRankRightList(Int , Int , Int , Int)
    case hotRankRightList(Int , Int , Int , Int)
    case sellerRankRightList(Int , Int , Int , Int)
    case onLineRankRightList(Int , Int , Int , Int)
    case rankLeftList(Int)
    
}

extension HFFMRankListAPI : TargetType {
    var baseURL: URL {
        return URL(string: "https://mobile.ximalaya.com")!
    }
    
    var path: String {
        switch self {
        case .rankFirstPage:
            return "/discovery-ranking-web/v3/ranking/AggregateRankFirstPage/1615875710516"
        case .newRankRightList(_ , _ ,_ ,_):
            return "/discovery-ranking-web/v3/ranking/concreteRankList/1616033348972"
        case .hotRankRightList(_ , _ ,_ ,_):
            return "/discovery-ranking-web/v3/ranking/concreteRankList/1616581439418"
        case .sellerRankRightList(_ , _ ,_ ,_):
            return "/discovery-ranking-web/v3/ranking/concreteRankList/1616571463356"
        case .onLineRankRightList(_ , _ ,_ ,_):
            return "/discovery-ranking-web/v3/ranking/concreteRankList/1616651611457"
        case .rankLeftList(_):
            return "/discovery-ranking-web/v3/ranking/AggregateRankListTabs/1616036027469"
        }
    }
    
    var method: Moya.Method {
        return .get
    }
    
    var sampleData: Data {
        return "".data(using: String.Encoding.utf8)!
    }
    
    var task: Task {
        
        var parmeters:[String:Any] = [:]
        switch self {
        case .newRankRightList(let index , let categoryId , let clusterType ,let rankingListId ):
            parmeters = ["categoryId":categoryId,
                         "clusterType":clusterType,
                         "pageId":index,
                         "pageSize":"20",
                         "rankingListId":rankingListId]
        case .rankLeftList (let rankingListId):
            parmeters = ["rankingListId":rankingListId]
        case .hotRankRightList(let index, let categoryId , let clusterType ,let rankingListId ):
            parmeters = ["categoryId":categoryId,
                         "clusterType":clusterType,
                         "pageId":index,
                         "pageSize":"20",
                         "rankingListId":rankingListId]
        case .sellerRankRightList(let index, let categoryId , let clusterType ,let rankingListId ) :
            parmeters = ["categoryId":categoryId,
                         "clusterType":clusterType,
                         "pageId":index,
                         "pageSize":"20",
                         "rankingListId":rankingListId]
        case .onLineRankRightList(let index, let categoryId , let clusterType ,let rankingListId ):
            parmeters = ["categoryId":categoryId,
                         "clusterType":clusterType,
                         "pageId":index,
                         "pageSize":"20",
                         "rankingListId":rankingListId]
            
        default:
            parmeters = [ : ]
        }
        return  .requestParameters(parameters: parmeters, encoding: URLEncoding.default)
        
    }
    
    var headers: [String : String]? {
        return nil
    }
    
    
}

