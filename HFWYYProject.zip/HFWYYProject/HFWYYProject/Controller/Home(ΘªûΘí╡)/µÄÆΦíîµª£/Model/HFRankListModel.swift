//
//  HFRankListModel.swift
//  HFWYYProject
//
//  Created by Chen on 2021/3/16.
//  Copyright © 2021 CH. All rights reserved.
//

import Foundation
import HandyJSON

struct HFRankListTopModel: HandyJSON {
    var ret : Int = 0
    var msg :String?
    var data : [HFRankListTopDataListModel]?
    
}

struct HFRankListTopDataListModel:HandyJSON {
    var aggregateListConfig :HFRankListTopAggregateListConfigModel?
    var aggregateListRule :HFRankListTopAggregateListRuleModel?
    var albumResults :[HFRankListTopAlbumResultsModel]?
}

struct HFRankListTopAggregateListConfigModel: HandyJSON {
    var clusterType : Int = 0
    var aggregateName :String?
    var anchorOrNot : Bool = false
    var bigCard : Bool = false
    var rankClusterId : Int = 0
    var rankingListId : Int = 0
    var activityPicUnClicked : String?
    var activityPicClicked :String?
}
struct HFRankListTopAggregateListRuleModel: HandyJSON{
    var updateTime :String?
    var calculateRule :String?
    var aggregateName :String?
    var clusterType : Int = 0
}
struct HFRankListTopAlbumResultsModel: HandyJSON{
}



//左边的标签
struct HFRankLeftListModel : HandyJSON {
    var ret : Int = 0
    var msg :String?
    var data : [HFRankLeftListDataModel]?
}

struct HFRankLeftListDataModel : HandyJSON {
    var categoryId : Int = 0
    var rankClusterId : Int = 0
    var rankingListId : Int = 0
    var name : String?
    var displayName : String?
    var contentType : String?
    var rankingRule : String?
    var sortRuleDesc:String?
    var updateAtDesc:String?
}

//新品榜单
struct HFRankContentModel: HandyJSON {
    var ret : Int = 0
    var msg :String?
    var data :HFRankContentDataModel?
    
}

struct HFRankContentDataModel: HandyJSON {
    var maxPageId : Int = 0
    var totalCount: Int = 0
    var pageId: Int = 0
    var pageSize: Int = 0
    var list : [HFRankContentDataListModel]?
//    var list : [HFRankOnLineDataModel]?

}

struct HFRankContentDataListModel :HandyJSON {
  
    
    var id : Int = 0
    var albumId : Int = 0
    var ageLevel : Int = 0
    var albumCoverUrl290 : String?
    var albumIntro :String?
    var categoryId : Int = 0
    var coverLarge :String?
    var coverMiddle :String?
    var coverSmall :String?
    var customTitle :String?
    var editorTitle :String?
    var intro :String?
    var isDraft : Bool = false
    var isFinished : Int = 0
    var isPaid : Bool = false
    var isSample : Bool = false
    var lastUptrackAt : Int = 0
    var lastUptrackId : Int = 0
    var lastUptrackTitle : String?
    var materialType :String?
    var opType : Int = 0
    var originalCoverPath:String?
    var originalStatus : Int = 0
    var playsCounts : Int = 0
    var preferredType : Int = 0
    var provider : String?
    var recommendReason : Int = 0
    var refundSupportType : Int = 0
    var serialState : Int = 0
    var status : Int = 0
    var subscribeCount : Int = 0
    var subscribeStatus : Int = 0
    var subscribesCounts : Int = 0
    var tags : String?
    var title : String?
    var trackId : Int = 0
    var tracks  : Int = 0
    var type  : Int = 0
    var uid  : Int = 0
    var vipFreeType  : Int = 0
    var isVipFree  :Bool = false
    var activityLabel  : Int = 0
    var popularity : String?
    var positionChange :Int  = 0
    var albumScore : String?
    var albumSubscript : String?
    var createdAt : CLong?
    var updatedAt : CLong?
    var priceTypeEnum : Int = 0
    
}


//主播榜单
struct HFRankOnLineModel: HandyJSON {
    var maxPageId : Int = 0
    var totalCount: Int = 0
    var pageId: Int = 0
    var pageSize: Int = 0
 
    var list : [HFRankOnLineDataModel]?

}
struct HFRankOnLineDataModel : HandyJSON {
    var uid : Int = 0
    var nickname : String?
    var logoPic : String?
    var anchorGrade : Int = 0
    var followersCounts: Int  = 0
    var personDescribe : String?
    var followStatus : Int = 0
    var iting :String?
    var verifyType : Int = 0
    var score: String?
    var positionChange : Int = 0
    var verified : Bool = false
    var vlogoType : Int = 0
}
