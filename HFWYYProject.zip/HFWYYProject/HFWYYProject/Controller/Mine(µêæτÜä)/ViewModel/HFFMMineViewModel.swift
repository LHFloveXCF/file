//
//  HFFMMineViewModel.swift
//  HFWYYProject
//
//  Created by Chen on 2021/3/4.
//  Copyright © 2021 CH. All rights reserved.
//

import UIKit
import SwiftyJSON
import HandyJSON



class HFFMMineViewModel: NSObject {
    var mineModel: HFFMMine_Model?
}


extension HFFMMineViewModel {
    func refrshMineDataSource(successBlock:@escaping() -> Void) {
        HFFMMineProvider.request(.messageList) { (result) in

            if case let .success(response) = result {
                let data = try? response.mapJSON()
                let json = JSON(data as Any)
//                解析数据
                print(json.description)

                if let mappedObject = JSONDeserializer<HFFMMine_Model>.deserializeFrom(json: json.description){
                    print(mappedObject.msg as Any)
                    self.mineModel = mappedObject
                 }
 
                successBlock()
            }
        }
    }
}
