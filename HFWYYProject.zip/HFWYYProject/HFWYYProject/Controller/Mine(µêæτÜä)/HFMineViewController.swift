//
//  HFMineViewController.swift
//  HFWYYProject
//
//  Created by Chen on 2021/3/3.
//  Copyright © 2021 CH. All rights reserved.
//

import UIKit

 

class HFMineViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.view.backgroundColor = UIColor.colorWithHexString("#EAEAEA")
        self.view.addSubview(mainCollectionView)
        
        
        mineViewModel.refrshMineDataSource { 
            self.mainCollectionView.reloadData()
        }
    }
     
    lazy var mineViewModel: HFFMMineViewModel = {
        return HFFMMineViewModel()
    }()
    
    lazy var mainCollectionView: UICollectionView = {
        let flowLayout = UICollectionViewFlowLayout()
        let itemWidth : CGFloat =  (HFFMScreen_Width -  15 * 5) / 4
        flowLayout.itemSize = CGSize(width: itemWidth, height: 60)
        flowLayout.minimumLineSpacing =  30
        flowLayout.sectionInset = UIEdgeInsets(top: 15, left: 15, bottom: 15, right: 15)
        let collectionView = UICollectionView.init(frame: CGRect(x: 0, y: 0, width: HFFMScreen_Width, height: HFFMScreen_Height), collectionViewLayout: flowLayout)
        collectionView.delegate = self
        collectionView.dataSource = self
        collectionView.register(HFFMMineCollectionViewCell.self, forCellWithReuseIdentifier: "HFFMMineCollectionViewCell")
        collectionView.register(HFFMMineCreateCollectionViewCell.self, forCellWithReuseIdentifier: "HFFMMineCreateCollectionViewCell")
        collectionView.register(HFFMMineHeaderView.self, forSupplementaryViewOfKind: UICollectionView.elementKindSectionHeader, withReuseIdentifier: "HFFMMineHeaderView")
        collectionView.register(HFFMMineNormalReusableView.self, forSupplementaryViewOfKind: UICollectionView.elementKindSectionHeader, withReuseIdentifier: "HFFMMineNormalReusableView")

        collectionView.register(HFFMMineFooterReusableView.self, forSupplementaryViewOfKind: UICollectionView.elementKindSectionFooter, withReuseIdentifier: "HFFMMineFooterReusableView")
        collectionView.register(HFFMNormalFooterReusableView.self, forSupplementaryViewOfKind: UICollectionView.elementKindSectionFooter, withReuseIdentifier: "HFFMNormalFooterReusableView")
        collectionView.backgroundColor =  .white
        
        return collectionView
    }()

}

extension HFMineViewController : UICollectionViewDelegateFlowLayout{
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, referenceSizeForHeaderInSection section: Int) -> CGSize {
        if section == 0 {
             return CGSize(width: HFFMScreen_Width, height: 200)
        }else{
            return CGSize(width: HFFMScreen_Width, height: 50)
        }
    }
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, referenceSizeForFooterInSection section: Int) -> CGSize {
        if section == 0 {
             return CGSize(width: HFFMScreen_Width, height: 60)
        }else{
            return CGSize(width: HFFMScreen_Width , height: 8)
        }
    }
}
extension HFMineViewController : UICollectionViewDelegate{
    
}

extension HFMineViewController : UICollectionViewDataSource{
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 6
    }
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        if section == 0 {
            return 4
        }
        return 5
    }
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        if indexPath.section == 0 {
              let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "HFFMMineCreateCollectionViewCell", for: indexPath) as! HFFMMineCreateCollectionViewCell
            return cell
        }else{
            let  cell  = collectionView.dequeueReusableCell(withReuseIdentifier: "HFFMMineCollectionViewCell", for: indexPath) as! HFFMMineCollectionViewCell
            return cell
        }
    }
    
    func collectionView(_ collectionView: UICollectionView, viewForSupplementaryElementOfKind kind: String, at indexPath: IndexPath) -> UICollectionReusableView {
        let  view  = UICollectionReusableView()
        
        
        if  kind == UICollectionView.elementKindSectionFooter{
            if indexPath.section == 0 {
                let  footerView : HFFMMineFooterReusableView = collectionView.dequeueReusableSupplementaryView(ofKind: kind, withReuseIdentifier: "HFFMMineFooterReusableView", for: indexPath) as! HFFMMineFooterReusableView
                return footerView
            }else{
                let footerVier : HFFMNormalFooterReusableView = collectionView.dequeueReusableSupplementaryView(ofKind: kind, withReuseIdentifier: "HFFMNormalFooterReusableView", for: indexPath) as! HFFMNormalFooterReusableView
                return footerVier
            }
            
        }
        
        
        if kind == UICollectionView.elementKindSectionHeader{
            if indexPath.section == 0 {
                let  headerView : HFFMMineHeaderView = collectionView.dequeueReusableSupplementaryView(ofKind: kind, withReuseIdentifier: "HFFMMineHeaderView", for: indexPath) as! HFFMMineHeaderView
                return headerView
            }else{
                let  headerView : HFFMMineNormalReusableView = collectionView.dequeueReusableSupplementaryView(ofKind: kind, withReuseIdentifier: "HFFMMineNormalReusableView", for: indexPath) as! HFFMMineNormalReusableView
                return headerView
            }
        }
        
        return view
        
    }
}
