//
//  HFFMMineMessageViewController.swift
//  HFWYYProject
//
//  Created by Chen on 2021/3/4.
//  Copyright © 2021 CH. All rights reserved.
//

import UIKit

class HFFMMineMessageViewController: HFFMBaseViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        self.title = "消息中心"

    }


}
