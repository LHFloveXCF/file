//
//  HFFMMineAPI.swift
//  HFWYYProject
//
//  Created by Chen on 2021/3/3.
//  Copyright © 2021 CH. All rights reserved.
//

import Foundation
import Moya
import SwiftyJSON


let HFFMMineProvider = MoyaProvider<HFFMMineAPI>()


enum HFFMMineAPI {
    case messageList
}

extension HFFMMineAPI : TargetType{
    var baseURL: URL {
        return URL(string: "http://m.ximalaya.com")!
    }
    
    var path: String {
        switch self {
        case .messageList: return "/business-vip-presale-support-web/my/page/vip/access/ts-1614843832729"
        }
    }
    
    var method: Moya.Method {
        return .get
    }
    
    var sampleData: Data {
        return "".data(using: String.Encoding.utf8)!
    }
    
    var task: Task {
        let parmeters:[String:Any] = [:]
        
        return .requestParameters(parameters: parmeters, encoding: URLEncoding.default)
    }
    
    var headers: [String : String]? {
        return nil
    }
    
    
}
