//
//  HFFMMine_Model.swift
//  HFWYYProject
//
//  Created by Chen on 2021/3/4.
//  Copyright © 2021 CH. All rights reserved.
//

import UIKit
import HandyJSON

 
struct HFFMMine_Model :HandyJSON{
    var msg : String?
    var ret : Int = 0
    var data : HFFMMine_Data_Model?
    
}

struct HFFMMine_Data_Model : HandyJSON {
    var backGroundUrl: String?
    var jumpUrl :String?
    var text :String?
}
