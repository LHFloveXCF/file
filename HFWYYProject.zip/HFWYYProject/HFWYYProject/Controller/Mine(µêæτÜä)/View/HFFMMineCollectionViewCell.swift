//
//  HFFMMineCollectionViewCell.swift
//  HFWYYProject
//
//  Created by Chen on 2021/3/4.
//  Copyright © 2021 CH. All rights reserved.
//

import UIKit

class HFFMMineCollectionViewCell: UICollectionViewCell {
    
    override init(frame: CGRect) {
        super.init(frame: frame )
        
        self.backgroundColor = .white
        
        contentView.addSubview(pictureView)
        contentView.addSubview(contentLabel)
        
    }
    
    
    override func layoutSubviews() {
        super.layoutSubviews()
        pictureView.snp.makeConstraints { (make) in
            make.top.equalTo(self).offset(0)
            make.centerX.equalTo(self.snp_centerX)
            make.size.equalTo(CGSize(width: 30, height: 30))
        }
        
        contentLabel.snp.makeConstraints { (make) in
            make.centerX.equalTo(self.snp_centerX)
            make.top.equalTo(pictureView.snp_bottom).offset(8)
            make.height.equalTo(17)
        }
    }
    lazy var pictureView: UIImageView = {
        let imageView =  UIImageView()
        imageView.backgroundColor = .red
        imageView.contentMode = .scaleAspectFill
        return imageView
    }()
    
    lazy var contentLabel : UILabel = {
        let label = UILabel.init(titleString: "我的钱包", textColorString: "#B5B5B5", fontNumber: 15, textAlignments: .center, numberLines: 1)
        return label
    }()
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}
