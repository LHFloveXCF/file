//
//  HFFMMineHeaderView.swift
//  HFWYYProject
//
//  Created by Chen on 2021/3/3.
//  Copyright © 2021 CH. All rights reserved.
//

import UIKit

class HFFMMineHeaderView: UICollectionReusableView {

    override init(frame: CGRect) {
        super.init(frame: frame)
        
        self.backgroundColor = .white
        
        self.setupSubView()
    }


    func setupSubView() {
         
        //模式
        //消息
        //扫一扫
        //设置
        self.addSubview(simpleModelButton)
        self.addSubview(messageButton)
        self.addSubview(sweepButton)
        self.addSubview(settingButton)
        
        self.addSubview(headImageView)
        self.addSubview(loginButton)
        self.addSubview(newUserLabel)
        self.addSubview(VIPMemberButton)
        
        let bottomView = self.likeAndFocusView()
        self.addSubview(bottomView)
        bottomView.backgroundColor = .green
        bottomView.snp.makeConstraints { (make) in
            make.left.equalTo(self).offset(20)
            make.top.equalTo(headImageView.snp.bottom).offset(20)
            make.height.equalTo(40)
            make.width.equalTo(HFFMScreen_Width - 20 * 2)
        }
    }
    
 
    override func layoutSubviews() {
        super.layoutSubviews()
        simpleModelButton.snp.makeConstraints { (make ) in
            make.top.equalTo(self).offset(20)
            make.left.equalTo(self).offset(20)
            make.size.equalTo(CGSize(width: 80, height: 20))
        }
        settingButton.snp.makeConstraints { (make) in
            make.right.equalTo(self.snp_right).offset(-20)
            make.centerY.equalTo(simpleModelButton.snp_centerY)
            make.size.equalTo(CGSize(width: 20, height: 20))
        }
        sweepButton.snp.makeConstraints { (make) in
            make.right.equalTo(settingButton.snp_left).offset(-20)
            make.centerY.equalTo(simpleModelButton.snp_centerY)
            make.size.equalTo(CGSize(width: 20, height: 20))
        }
        messageButton.snp.makeConstraints { (make) in
            make.right.equalTo(sweepButton.snp_left).offset(-20)
            make.centerY.equalTo(simpleModelButton.snp_centerY)
            make.size.equalTo(CGSize(width: 20, height: 20))
        }
        
        headImageView.snp.makeConstraints { (make) in
            make.left.equalTo(self).offset(15)
            make.top.equalTo(simpleModelButton.snp_bottom).offset(20)
            make.size.equalTo(CGSize(width: 50, height: 50))
        }
        
        loginButton.snp.makeConstraints { (make ) in
            make.left.equalTo(headImageView.snp_right).offset(15)
            make.top.equalTo(headImageView.snp_top).offset(0)
            make.height.equalTo(20)
        }
        newUserLabel.snp.makeConstraints { (make ) in
            make.top.equalTo(loginButton.snp_bottom).offset(10)
            make.left.equalTo(headImageView.snp_right).offset(15)
            make.height.equalTo(15)
        }
//        VIPMemberButton.snp.makeConstraints { (make ) in
//            make.left.equalTo(self).offset(15)
//            make.top.equalTo(self.snp_bottom).offset(-10)
//            make.size.equalTo(CGSize(width: HFFMScreen_Width - 30, height: 40))
//        }
    }
    
    lazy var headImageView: UIImageView = {
        let imageView = UIImageView()
        imageView.backgroundColor = .red
        imageView.layer.cornerRadius = 25
        imageView.layer.masksToBounds = true
        return imageView
    }()
    
    lazy var loginButton: UIButton = {
        let button = UIButton.init(type: .custom)
        button.setTitle("立即登录", for: .normal)
        button.setTitleColor(.black, for: .normal)
        button.addTarget(self, action: #selector(loginButtonClick(btn:)), for: .touchUpInside)
        return button
    }()
    
    lazy var newUserLabel: UILabel = {
        let label = UILabel()
        label.text = "新用户登录可领取vip权益"
        label.font = UIFont.systemFont(ofSize: 13)
        label.textColor = HFFMThemeColor
        return label
    }()
    
    
    lazy var VIPMemberButton: UIButton = {
        let button = UIButton.init(type: .custom)
        button.backgroundColor = .red
        button.addTarget(self, action: #selector(VIPMemberButtonClick(btn:)), for: .touchUpInside)
        return button
    }()
    
    lazy var simpleModelButton: UIButton = {
        let button = UIButton.init(type: .custom)
        button.layer.borderColor = UIColor.darkGray.cgColor
        button.layer.borderWidth = 1
        button.setTitle("简约模式", for: .normal)
        button.setImage(UIImage(named: "modelArrow"), for: .normal)
        button.layer.cornerRadius  = 10
        button.layer.masksToBounds = true
        button.setTitleColor(.black, for: .normal)
        button.hf_layoutButtonEdgInsets(.HFButtonEdgeInsetsStyleRight, spaceNumber: 3)
        button.titleLabel?.font = UIFont.systemFont(ofSize: 12)
        return button
    }()
    
    lazy var messageButton: UIButton = {
        let button = UIButton.init(type: .custom)
        button.backgroundColor = .red
        button.imageView?.contentMode = .scaleAspectFill
        button.setImage(UIImage.init(named: "mine_messgae"), for: .normal)
        return button
    }()
    lazy var sweepButton: UIButton = {
        let button = UIButton.init(type: .custom)
        button.backgroundColor = .red
        button.setImage(UIImage.init(named: ""), for: .normal)
        return button
    }()
    
    lazy var settingButton: UIButton = {
        let button = UIButton.init(type: .custom)
        button.backgroundColor = .red
        button.setImage(UIImage.init(named: ""), for: .normal)
        return button
    }()
    
    @objc func  loginButtonClick(btn : UIButton){
        
    }
    
    @objc func VIPMemberButtonClick(btn: UIButton){
        
    }
    
    
    func likeAndFocusView() -> UIView {
        let  view  = UIView()
        
        //粉丝Label
        let fansLabel =  UILabel.init(titleString:  "0\n 粉丝", textColorString: "#C7C7C7", fontNumber: 15, textAlignments: .center, numberLines: 0)
        fansLabel.changeLineSpace(space: 2)
        view.addSubview(fansLabel)
        
        fansLabel.snp.makeConstraints { (make) in
            make.left.equalTo(view).offset(10)
            make.top.equalTo(view).offset(0)
            make.height.equalTo(30)
        }
        
        
        //关注 foucs
        let foucsLabel =  UILabel.init(titleString:  "0\n关注", textColorString: "#C7C7C7", fontNumber: 13, textAlignments: .center, numberLines: 0)
        foucsLabel.changeLineSpace(space: 10)
        view.addSubview(foucsLabel)
        foucsLabel.snp.makeConstraints { (make) in
            make.left.equalTo(fansLabel.snp_right).offset(30)
            make.top.equalTo(view).offset(0)
            make.height.equalTo(40)
        }
        
        
        //喜欢 like
        let likeLabel =  UILabel.init(titleString:  "0\n喜欢", textColorString: "#C7C7C7", fontNumber: 13, textAlignments: .center, numberLines: 0)
        foucsLabel.changeLineSpace(space: 10)
        view.addSubview(likeLabel)
        likeLabel.font = UIFont.systemFont(ofSize: 13)
        likeLabel.snp.makeConstraints { (make) in
            make.left.equalTo(foucsLabel.snp_right).offset(30)
            make.top.equalTo(view).offset(0)
            make.height.equalTo(30)
        }
        
        return view
    }
    
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    
    
}
