//
//  HFFMMineNormalReusableView.swift
//  HFWYYProject
//
//  Created by Chen on 2021/3/4.
//  Copyright © 2021 CH. All rights reserved.
//

import UIKit

class HFFMMineNormalReusableView: UICollectionReusableView {
    override init(frame: CGRect) {
        super.init(frame: frame)
        self.addSubview(titleLabel)
    }
    override func layoutSubviews() {
        super.layoutSubviews()
        self.titleLabel.snp.makeConstraints { (make ) in
            make.left.top.equalTo(self).offset(20)
            make.height.equalTo(20)
        }
    }
    
    lazy var titleLabel : UILabel = {
        let label = UILabel.init(titleString: "我的服务", textColorString: "#404040", fontNumber: 15, textAlignments: .left, numberLines: 1)
        return label
    }()
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    
}
