//
//  HFFMNormalFooterReusableView.swift
//  HFWYYProject
//
//  Created by Chen on 2021/3/4.
//  Copyright © 2021 CH. All rights reserved.
//

import UIKit

class HFFMNormalFooterReusableView: UICollectionReusableView {
        
    override init(frame: CGRect) {
        super.init(frame: frame )
        let  view  = UIView.init(frame: CGRect(x: 0, y: 0, width: HFFMScreen_Width, height: 8))
        view.backgroundColor = UIColor.darkGray
        self.addSubview(view)
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
}
