//
//  HFFMMineFooterReusableView.swift
//  HFWYYProject
//
//  Created by Chen on 2021/3/4.
//  Copyright © 2021 CH. All rights reserved.
//

import UIKit

class HFFMMineFooterReusableView: UICollectionReusableView {
 
    override init(frame: CGRect) {
        super.init(frame: frame)
        self.addSubview(lineView)
        self.addSubview(clickButton)
        self.addSubview(spaceLineView)
    }
    
    override func layoutSubviews() {
        super.layoutSubviews()
        
        lineView.snp.makeConstraints { (make) in
            make.left.right.equalTo(self).offset(0)
            make.top.equalTo(10)
            make.height.equalTo(1)
        }
        
        clickButton.snp.makeConstraints { ( make ) in
            make.left.equalTo(self).offset(20)
            make.top.equalTo(lineView.snp_bottom).offset(5)
            make.size.equalTo(CGSize(width: HFFMScreen_Width - 20 * 2, height: 40))
        }
        spaceLineView.snp_makeConstraints { ( make ) in
            make.left.right.equalTo(self).offset(0)
            make.top.equalTo(clickButton.snp_bottom).offset(0)
            make.height.equalTo(8)
        }
    }
    
    lazy var lineView: UIView = {
         let view  = UIView()
        view.backgroundColor = UIColor.colorWithHexString("#DEDEDE")
        return view
    }()
    
    lazy var clickButton : UIButton = {
        let button = UIButton.init(type: .custom)
        button.setTitle("创作活动少年说", for: .normal)
        button.titleLabel?.font = UIFont.systemFont(ofSize: 14)
        button.backgroundColor = .green
        return button
    }()
    
    lazy var spaceLineView: UIView = {
        let view = UIView()
        view.backgroundColor = UIColor.darkGray
        return view
    }()
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}
